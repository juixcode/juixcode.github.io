#	COMMANDS
# Enable triggers every tick
scoreboard players enable @a sethome
scoreboard players enable @a delhome
scoreboard players enable @a home
scoreboard players enable @a system

#   PLAYER ID ASSIGNMENT
execute as @a unless score @s vhg_id matches 1.. run function vhg_data:assign_id

# Initialize trigger scores to -1 if they don't have them (offset trick to detect trigger without value)
execute as @a unless score @s sethome = @s sethome run scoreboard players set @s sethome -1
execute as @a unless score @s delhome = @s delhome run scoreboard players set @s delhome -1
execute as @a unless score @s home = @s home run scoreboard players set @s home -1
execute as @a unless score @s system = @s system run scoreboard players set @s system -1

# Trigger detection (0.. matches activations)
execute as @a[scores={home=0..}] run function vhg_data:trigger_home
execute as @a[scores={delhome=0..}] run function vhg_data:trigger_delhome
execute as @a[scores={sethome=0..}] run function vhg_data:trigger_sethome
execute as @a[scores={system=0..99999}] run function vhg_data:trigger_system

#   MIGRATION (Legacy entities to Storage)
execute as @a[tag=!vhg_migrated] run function vhg_data:migration/detect

#   TELEPORT SYSTEM (DELAY & DMG CANCEL)
execute as @a[scores={teleporting=0..}] run function vhg_data:teleporting
scoreboard players reset @a[scores={vhg_dmg_taken=1..}] vhg_dmg_taken