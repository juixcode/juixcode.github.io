#
#	DEFAULT
#

scoreboard objectives add keepXP_installation_test dummy
execute if score world keepXP_installation_test matches 1.. run tellraw @a {"text":"Keep XP On Death Reloaded","color":"green"}
execute unless score world keepXP_installation_test matches 1.. run function kxp_data:setup