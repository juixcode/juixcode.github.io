# Logic to handle the system trigger for Keep XP On Death
# Range: 100000 - 199999

# Copy trigger score
scoreboard players operation #system_val kxp_constants = @s system

# Reset trigger
scoreboard players set @s system -1

# === 100000-100002: XP Recovery mode selection ===
execute if score #system_val kxp_constants matches 100000 run scoreboard players set world kxp_gamerule_keep_xp 1
execute if score #system_val kxp_constants matches 100001 run scoreboard players set world kxp_gamerule_keep_xp 2
execute if score #system_val kxp_constants matches 100002 run scoreboard players set world kxp_gamerule_keep_xp 3

# === 100010-100012: Milestone interval ===
execute if score #system_val kxp_constants matches 100010 run scoreboard players set world kxp_config_milestone 3
execute if score #system_val kxp_constants matches 100011 run scoreboard players set world kxp_config_milestone 5
execute if score #system_val kxp_constants matches 100012 run scoreboard players set world kxp_config_milestone 10

# === 100020-100021: Percentage -/+ (step 10, range 10-100) ===
execute if score #system_val kxp_constants matches 100020 if score world kxp_config_percentage matches 20.. run scoreboard players remove world kxp_config_percentage 10
execute if score #system_val kxp_constants matches 100021 if score world kxp_config_percentage matches ..90 run scoreboard players add world kxp_config_percentage 10

# === 100030-100031: Fixed loss -/+ (range 1-10) ===
execute if score #system_val kxp_constants matches 100030 if score world kxp_config_fixed matches 2.. run scoreboard players remove world kxp_config_fixed 1
execute if score #system_val kxp_constants matches 100031 if score world kxp_config_fixed matches ..9 run scoreboard players add world kxp_config_fixed 1

# === 100100: Toggle on/off ===
execute if score #system_val kxp_constants matches 100100 run scoreboard players set world kxp_gamerule_keep_xp 1
execute if score #system_val kxp_constants matches 100110 run scoreboard players set world kxp_gamerule_keep_xp 0
execute if score #system_val kxp_constants matches 100120 run function kxp_data:enable_keep_inventory
execute if score #system_val kxp_constants matches 100130 run function kxp_data:disable_keep_inventory

# === 100101-100103: Fast config presets ===
# Preset: 3-Level Milestones
execute if score #system_val kxp_constants matches 100101 run scoreboard players set world kxp_gamerule_keep_xp 1
execute if score #system_val kxp_constants matches 100101 run scoreboard players set world kxp_config_milestone 3
# Preset: Full XP Recovery (100% percentage)
execute if score #system_val kxp_constants matches 100102 run scoreboard players set world kxp_gamerule_keep_xp 2
execute if score #system_val kxp_constants matches 100102 run scoreboard players set world kxp_config_percentage 100
# Preset: -3 Levels per death
execute if score #system_val kxp_constants matches 100103 run scoreboard players set world kxp_gamerule_keep_xp 3
execute if score #system_val kxp_constants matches 100103 run scoreboard players set world kxp_config_fixed 3

# === 100200-100201: XP Summoning mode ===
execute if score #system_val kxp_constants matches 100200 run scoreboard players set world kxp_config_drop_mode 1
execute if score #system_val kxp_constants matches 100201 run scoreboard players set world kxp_config_drop_mode 2

# Disable keep inventory when enabling the pack via mode selection or presets
execute if score #system_val kxp_constants matches 100000..100002 run function kxp_data:disable_keep_inventory
execute if score #system_val kxp_constants matches 100100 run function kxp_data:disable_keep_inventory

# Re-display the config panel after any action
function datapack:keep_xp_on_death_datapack/config
