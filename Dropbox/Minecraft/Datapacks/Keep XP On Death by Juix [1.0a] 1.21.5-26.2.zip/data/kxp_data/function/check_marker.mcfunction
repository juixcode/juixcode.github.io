# Copy this marker's ID to a temporary constant
scoreboard players operation #check_id kxp_constants = @s kxp_id

# If the player with the matching ID is within 5 blocks of the marker, mark it as loaded
execute as @a[distance=..5] if score @s kxp_id = #check_id kxp_constants run scoreboard players set @s kxp_has_marker_loaded 1

# If the matching player was found nearby, keep the marker alive by returning
execute as @a[distance=..5] if score @s kxp_id = #check_id kxp_constants run return 1

# Otherwise, this marker is orphaned or out of sync, so we destroy it
kill @s
