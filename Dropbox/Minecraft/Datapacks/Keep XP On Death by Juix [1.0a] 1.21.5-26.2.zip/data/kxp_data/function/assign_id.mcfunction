# Assign global ID to the player
scoreboard players operation @s kxp_id = #global kxp_id
scoreboard players add #global kxp_id 1

# Summon and link their personal marker at their current position
execute at @s run function kxp_data:summon_marker
