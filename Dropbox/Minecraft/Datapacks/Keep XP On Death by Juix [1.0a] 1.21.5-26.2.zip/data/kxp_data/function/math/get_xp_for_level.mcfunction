# Helper function: Calculate total XP required to reach a level
# Input: #math_lvl kxp_constants
# Output: #math_xp kxp_constants

# Range 1: L <= 16
# Formula: XP = L^2 + 6*L
execute if score #math_lvl kxp_constants matches ..16 run scoreboard players operation #math_xp kxp_constants = #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches ..16 run scoreboard players operation #math_xp kxp_constants *= #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches ..16 run scoreboard players operation #math_temp kxp_constants = #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches ..16 run scoreboard players set #math_six kxp_constants 6
execute if score #math_lvl kxp_constants matches ..16 run scoreboard players operation #math_temp kxp_constants *= #math_six kxp_constants
execute if score #math_lvl kxp_constants matches ..16 run scoreboard players operation #math_xp kxp_constants += #math_temp kxp_constants

# Range 2: 17 <= L <= 31
# Formula: XP = (5 * L^2 - 81 * L + 720) / 2
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp kxp_constants = #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp kxp_constants *= #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players set #math_five kxp_constants 5
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp kxp_constants *= #math_five kxp_constants

execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp2 kxp_constants = #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players set #math_eighty_one kxp_constants 81
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp2 kxp_constants *= #math_eighty_one kxp_constants

execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp kxp_constants -= #math_temp2 kxp_constants
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players set #math_seven_twenty kxp_constants 720
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_temp kxp_constants += #math_seven_twenty kxp_constants

execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_xp kxp_constants = #math_temp kxp_constants
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players set #math_two kxp_constants 2
execute if score #math_lvl kxp_constants matches 17..31 run scoreboard players operation #math_xp kxp_constants /= #math_two kxp_constants

# Range 3: L >= 32
# Formula: XP = (9 * L^2 - 325 * L + 4440) / 2
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp kxp_constants = #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp kxp_constants *= #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players set #math_nine kxp_constants 9
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp kxp_constants *= #math_nine kxp_constants

execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp2 kxp_constants = #math_lvl kxp_constants
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players set #math_three_twenty_five kxp_constants 325
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp2 kxp_constants *= #math_three_twenty_five kxp_constants

execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp kxp_constants -= #math_temp2 kxp_constants
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players set #math_forty_four_forty kxp_constants 4440
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_temp kxp_constants += #math_forty_four_forty kxp_constants

execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_xp kxp_constants = #math_temp kxp_constants
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players set #math_two kxp_constants 2
execute if score #math_lvl kxp_constants matches 32.. run scoreboard players operation #math_xp kxp_constants /= #math_two kxp_constants
