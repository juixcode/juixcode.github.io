
function kxp_data:setup_modern
function kxp_data:setup_legacy

#
#	DEFAULT
#

scoreboard objectives add system trigger

scoreboard objectives add kxp_death deathCount
scoreboard objectives add kxp_xp xp

scoreboard objectives add kxp_keep_inventory_test dummy
scoreboard objectives add kxp_gamerule_keep_xp dummy
scoreboard objectives add kxp_config_drop_mode dummy

scoreboard objectives add kxp_config_milestone dummy
scoreboard objectives add kxp_config_percentage dummy
scoreboard objectives add kxp_config_fixed dummy

scoreboard objectives add kxp_time_since_death minecraft.custom:minecraft.time_since_death
scoreboard objectives add kxp_has_marker_loaded dummy

# Unique ID mapping for position trackers
scoreboard objectives add kxp_id dummy
execute unless score #global kxp_id matches 1.. run scoreboard players set #global kxp_id 1

# XP tracker
scoreboard objectives add kxp_xp_backup dummy
scoreboard objectives add kxp_xp_backup_temp dummy
scoreboard objectives add kxp_level_backup dummy
scoreboard objectives add kxp_points_backup dummy

# Math constants
scoreboard objectives add kxp_constants dummy
scoreboard players set #two kxp_constants 2

# Default config
execute unless score world kxp_config_milestone matches 1.. run scoreboard players set world kxp_config_milestone 3
execute unless score world kxp_config_percentage matches 1.. run scoreboard players set world kxp_config_percentage 100
execute unless score world kxp_config_fixed matches 1.. run scoreboard players set world kxp_config_fixed 3

execute unless score world kxp_config_drop_mode matches 1.. run scoreboard players set world kxp_config_drop_mode 1

execute unless score world kxp_gamerule_keep_xp matches 0.. as @a run function gamerule:keep_xp_only/all
execute unless score world kxp_gamerule_keep_xp matches 0.. run function gamerule:keep_xp_only/all

scoreboard players set world keepXP_installation_test 1
tellraw @a {"text":"Keep XP On Death Installed","color":"green"}