# Summon a new marker at the player's position with a temporary tag
summon marker ~ ~ ~ {Tags:["kxp_marker","kxp_new_marker"]}

# Assign the player's ID to the newly summoned marker
scoreboard players operation @e[type=marker,tag=kxp_new_marker,limit=1] kxp_id = @s kxp_id

# Remove the temporary tag
tag @e[type=marker,tag=kxp_new_marker] remove kxp_new_marker
