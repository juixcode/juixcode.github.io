# Enable system trigger for all players (must run even when pack is disabled for config panel)
scoreboard players enable @a system

# System trigger detection for Keep XP config (range 100000-199999)
execute as @a[scores={system=100000..199999}] run function kxp_data:trigger_system

# Only run the datapack loop if Keep XP On Death is enabled (1, 2 or 3)
execute if score world kxp_gamerule_keep_xp matches 1.. run function kxp_data:active_tick