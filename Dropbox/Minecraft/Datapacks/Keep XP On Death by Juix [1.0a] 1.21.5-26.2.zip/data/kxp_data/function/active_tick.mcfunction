#   INIT PLAYERS

# 1. Initialize time_since_death score to 1000 if unset (so new players are considered alive)
execute as @a unless score @s kxp_time_since_death matches 0.. run scoreboard players set @s kxp_time_since_death 1000
# 2. Setup ID/Marker for new players
execute as @a unless score @s kxp_id matches 1.. run function kxp_data:assign_id

#   POSITION TRACKING

# 3. Track loaded markers and delete out-of-sync/orphaned ones
scoreboard players set @a kxp_has_marker_loaded 0
execute as @e[type=marker,tag=kxp_marker] at @s run function kxp_data:check_marker
# If a player is alive but their marker is unloaded/missing, summon a new one
execute as @a[scores={kxp_time_since_death=1..,kxp_has_marker_loaded=0}] at @s run function kxp_data:summon_marker

#   AFTER DEATH

# 4. On death: delete the dropped XP orbs immediately at the player's marker (death location)
execute as @a[scores={kxp_death=1..}] run function kxp_data:events/clean_death_xp
# 5. Process respawns (give XP back)
execute as @a[scores={kxp_time_since_death=1}] run function kxp_data:events/give_xp_back
# 6. Teleport markers for alive players (time_since_death >= 1)
execute as @a[scores={kxp_time_since_death=1..}] at @s run execute as @e[type=marker,tag=kxp_marker] if score @s kxp_id = @p kxp_id run tp @s @p
# 7. Backup XP level and progress points for alive players (time_since_death >= 1)
execute as @a[scores={kxp_time_since_death=1..}] store result score @s kxp_level_backup run xp query @s levels
execute as @a[scores={kxp_time_since_death=1..}] store result score @s kxp_points_backup run xp query @s points
# 8. Reset vanilla death score to 0 to keep scoreboard clean
scoreboard players set @a[scores={kxp_death=1..}] kxp_death 0
