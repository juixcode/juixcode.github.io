# Display fixed loss value with +/- buttons using a macro for dynamic value
execute store result storage kxp:temp display_val int 1 run scoreboard players get world kxp_config_fixed
function kxp_data:config/display_fixed_macro with storage kxp:temp
