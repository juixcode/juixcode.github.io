# Display percentage value with +/- buttons using a macro for dynamic value
execute store result storage kxp:temp display_val int 1 run scoreboard players get world kxp_config_percentage
function kxp_data:config/display_percentage_macro with storage kxp:temp
