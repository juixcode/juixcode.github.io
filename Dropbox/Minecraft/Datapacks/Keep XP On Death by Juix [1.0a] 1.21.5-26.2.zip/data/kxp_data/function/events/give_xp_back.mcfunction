# Test current state of keep inventory safely
function kxp_data:query_keep_inventory

# Only restore XP and clean up orbs if vanilla keep_inventory is disabled (0) and drop mode is Given (2)
execute if score world kxp_keep_inventory_test matches 0 if score world kxp_config_drop_mode matches 2 run function kxp_data:events/restore_xp

# If vanilla keep_inventory is enabled (1)
execute if score world kxp_keep_inventory_test matches 1.. run scoreboard players set world kxp_gamerule_keep_xp 0
