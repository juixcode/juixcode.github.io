# 1. Reset player's XP to 0 first to be clean
xp set @s 0 levels
xp set @s 0 points

# 2. Branch based on recovery mode

# === MODE 1: Milestone ===
execute if score world kxp_gamerule_keep_xp matches 1 run function kxp_data:events/restore_milestone

# === MODE 2: Percentage ===
execute if score world kxp_gamerule_keep_xp matches 2 run function kxp_data:events/restore_percentage

# === MODE 3: Fixed Loss ===
execute if score world kxp_gamerule_keep_xp matches 3 run function kxp_data:events/restore_fixed_loss
