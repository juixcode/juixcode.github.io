$xp set @s $(target_levels) levels
$xp set @s $(target_points) points
