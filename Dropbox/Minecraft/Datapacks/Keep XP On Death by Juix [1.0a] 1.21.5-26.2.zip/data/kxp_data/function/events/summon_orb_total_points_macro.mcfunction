$summon experience_orb ~ ~ ~ {Value:$(xp_amount)}
