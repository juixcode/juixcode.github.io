# MODE 2: Percentage Recovery
# Give back (kxp_config_percentage / 100) * kxp_xp_backup XP points

# 1. Calculate the player's total XP at death from the backup levels and points
function kxp_data:events/calculate_total_xp

# 2. Copy backup to temp
scoreboard players operation @s kxp_xp_backup_temp = @s kxp_xp_backup

# 3. Multiply by percentage
scoreboard players operation @s kxp_xp_backup_temp *= world kxp_config_percentage

# 4. Divide by 100
scoreboard players set #hundred kxp_constants 100
scoreboard players operation @s kxp_xp_backup_temp /= #hundred kxp_constants

# 5. Store result in storage
execute store result storage kxp:temp xp_amount int 1 run scoreboard players get @s kxp_xp_backup_temp

# 6. Apply based on drop mode
# If Given (2): reset and apply directly to player
execute if score world kxp_config_drop_mode matches 2 run xp set @s 0 levels
execute if score world kxp_config_drop_mode matches 2 run xp set @s 0 points
execute if score world kxp_config_drop_mode matches 2 run function kxp_data:events/apply_total_points_macro with storage kxp:temp

# If Dropped (1): summon orb at death marker
execute if score world kxp_config_drop_mode matches 1 run function kxp_data:events/summon_orb_at_marker
