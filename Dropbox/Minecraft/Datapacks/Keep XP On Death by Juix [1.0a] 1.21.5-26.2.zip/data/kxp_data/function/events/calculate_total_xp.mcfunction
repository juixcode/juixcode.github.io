# Calculate total XP of player (@s) from kxp_level_backup and kxp_points_backup
# Store result in @s kxp_xp_backup

# Set math input level to player's level backup
scoreboard players operation #math_lvl kxp_constants = @s kxp_level_backup

# Call the helper
function kxp_data:math/get_xp_for_level

# Store result in player's kxp_xp_backup
scoreboard players operation @s kxp_xp_backup = #math_xp kxp_constants

# Add progress points
scoreboard players operation @s kxp_xp_backup += @s kxp_points_backup
