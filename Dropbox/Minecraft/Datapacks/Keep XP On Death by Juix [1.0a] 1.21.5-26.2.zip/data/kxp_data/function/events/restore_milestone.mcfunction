# MODE 1: Milestone Recovery
# Calculate target level: L_target = (L_backup / milestone_interval) * milestone_interval

# 1. Compute target levels
scoreboard players operation #temp kxp_constants = @s kxp_level_backup
scoreboard players operation #temp kxp_constants /= world kxp_config_milestone
scoreboard players operation #temp kxp_constants *= world kxp_config_milestone

# 2. Save target_levels and target_points to storage
execute store result storage kxp:temp target_levels int 1 run scoreboard players get #temp kxp_constants
data modify storage kxp:temp target_points set value 0

# 3. Apply based on drop mode
# If Given (2): reset and apply directly to player
execute if score world kxp_config_drop_mode matches 2 run xp set @s 0 levels
execute if score world kxp_config_drop_mode matches 2 run xp set @s 0 points
execute if score world kxp_config_drop_mode matches 2 run function kxp_data:events/apply_level_points_macro with storage kxp:temp

# If Dropped (1): convert target level to raw XP points and summon orb
execute if score world kxp_config_drop_mode matches 1 run scoreboard players operation #math_lvl kxp_constants = #temp kxp_constants
execute if score world kxp_config_drop_mode matches 1 run function kxp_data:math/get_xp_for_level
execute if score world kxp_config_drop_mode matches 1 run execute store result storage kxp:temp xp_amount int 1 run scoreboard players get #math_xp kxp_constants
execute if score world kxp_config_drop_mode matches 1 run function kxp_data:events/summon_orb_at_marker
