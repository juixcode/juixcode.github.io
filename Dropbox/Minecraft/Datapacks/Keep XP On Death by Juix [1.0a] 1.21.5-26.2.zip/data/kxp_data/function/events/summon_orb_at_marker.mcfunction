# Verify if target XP is greater than 0 and summon the orb
execute store result score #xp_to_drop kxp_constants run data get storage kxp:temp xp_amount
execute if score #xp_to_drop kxp_constants matches 1.. run function kxp_data:events/summon_orb_total_points_macro with storage kxp:temp
