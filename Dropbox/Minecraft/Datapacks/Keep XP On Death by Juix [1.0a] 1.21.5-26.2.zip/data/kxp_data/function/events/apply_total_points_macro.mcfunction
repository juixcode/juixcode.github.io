$xp add @s $(xp_amount) points
