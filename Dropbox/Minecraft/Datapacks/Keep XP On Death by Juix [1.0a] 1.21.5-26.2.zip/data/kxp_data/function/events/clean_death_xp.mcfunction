# Test current state of keep inventory safely
function kxp_data:query_keep_inventory

# Only delete dropped orbs at the player's marker (death location) if vanilla keep_inventory is disabled (0)
execute if score world kxp_keep_inventory_test matches 0 run tag @s add kxp_current
execute if score world kxp_keep_inventory_test matches 0 as @e[type=marker,tag=kxp_marker] if score @s kxp_id = @a[tag=kxp_current,limit=1] kxp_id at @s run kill @e[type=experience_orb,distance=..3]

# If drop mode is "Dropped" (1), calculate and drop the new XP orb at the player's marker on death
execute if score world kxp_keep_inventory_test matches 0 if score world kxp_config_drop_mode matches 1 as @e[type=marker,tag=kxp_marker] if score @s kxp_id = @a[tag=kxp_current,limit=1] kxp_id at @s run execute as @a[tag=kxp_current,limit=1] run function kxp_data:events/restore_xp

tag @s remove kxp_current

# If vanilla keep_inventory is enabled (1)
execute if score world kxp_keep_inventory_test matches 1.. run scoreboard players set world kxp_gamerule_keep_xp 0
