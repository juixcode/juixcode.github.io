# Test current state of keep inventory
scoreboard players set world kxp_keep_inventory_test 0
function kxp_data:tools/query_keep_inventory_modern
execute if score world kxp_keep_inventory_test matches 0 run function kxp_data:tools/query_keep_inventory_legacy