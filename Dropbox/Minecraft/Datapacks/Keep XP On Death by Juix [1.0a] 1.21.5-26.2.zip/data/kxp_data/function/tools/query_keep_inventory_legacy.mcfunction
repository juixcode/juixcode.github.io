execute store result score world kxp_keep_inventory_test run gamerule keepInventory
