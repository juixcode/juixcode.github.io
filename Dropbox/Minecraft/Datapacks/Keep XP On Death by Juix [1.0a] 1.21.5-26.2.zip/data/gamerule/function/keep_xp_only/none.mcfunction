scoreboard players set world kxp_gamerule_keep_xp 0

# Test current state of keep inventory
function kxp_data:query_keep_inventory

# If it was enabled (1), show Enabled
execute if score world kxp_keep_inventory_test matches 1 run tellraw @s [{"text":"Keep Inventory current state : ","color":"gray"},{"text":"Enabled","color":"green"}]

# If it was disabled (0), show Disabled
execute if score world kxp_keep_inventory_test matches 0 run tellraw @s [{"text":"Keep Inventory current state : ","color":"gray"},{"text":"Disabled","color":"red"}]

tellraw @s [{"text":"Keep XP Only : ","color":"gray"},{"text":"Disabled","color":"red"}]