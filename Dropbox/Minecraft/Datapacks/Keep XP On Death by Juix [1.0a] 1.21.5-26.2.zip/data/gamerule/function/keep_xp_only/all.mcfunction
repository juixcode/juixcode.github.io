scoreboard players set world kxp_gamerule_keep_xp 2
scoreboard players set world kxp_config_percentage 100

function kxp_data:tools/disable_keep_inventory

tellraw @s [{"text":"Keep Inventory : ","color":"gray"},{"text":"Disabled","color":"red"}]
tellraw @s [{"text":"Keep XP Only : ","color":"gray"},{"text":"Full XP Recovery","color":"green"}]
execute if score world kxp_config_drop_mode matches 1 run tellraw @s [{"text":"XP Summoning mode : ","color":"gray"},{"text":"Orbs drop","color":"green"}]
execute if score world kxp_config_drop_mode matches 2 run tellraw @s [{"text":"XP Summoning mode : ","color":"gray"},{"text":"Instantly given","color":"green"}]