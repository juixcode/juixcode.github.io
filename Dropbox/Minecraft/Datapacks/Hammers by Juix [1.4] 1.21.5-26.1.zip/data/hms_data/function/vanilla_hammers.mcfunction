# UP DOWN (Plane XZ)
execute as @s[x_rotation=45..90] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:0, dy:-1, dz:0, plane:"xz"}
execute as @s[x_rotation=-90..-45] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:0, dy:1, dz:0, plane:"xz"}

# FRONT BACK (Plane XY) - Moving along Z
execute as @s[x_rotation=-45..45,y_rotation=-45..45] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:0, dy:0, dz:1, plane:"xy"}
execute as @s[x_rotation=-45..45,y_rotation=135..180] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:0, dy:0, dz:-1, plane:"xy"}
execute as @s[x_rotation=-45..45,y_rotation=-180..-135] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:0, dy:0, dz:-1, plane:"xy"}

# LEFT RIGHT (Plane YZ) - Moving along X
execute as @s[x_rotation=-45..45,y_rotation=45..135] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:-1, dy:0, dz:0, plane:"yz"}
execute as @s[x_rotation=-45..45,y_rotation=-135..-45] anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function hms_data:mine/start {dx:1, dy:0, dz:0, plane:"yz"}