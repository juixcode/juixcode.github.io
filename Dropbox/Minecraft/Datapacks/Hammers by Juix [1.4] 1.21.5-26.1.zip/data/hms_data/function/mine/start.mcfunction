# Initialise le minage avec profondeur variable
scoreboard players operation #depth hms_option_depth = world hms_option_depth
$function hms_data:mine/process {dx:$(dx), dy:$(dy), dz:$(dz), plane:"$(plane)"}
