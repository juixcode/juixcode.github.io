execute store result score #xp hms_temp_xp run random value 2..5
execute if score #xp hms_temp_xp matches 1.. run summon experience_orb ~ ~ ~ {Tags:["hms_xp"]}
execute if score #xp hms_temp_xp matches 1.. store result entity @e[type=experience_orb,tag=hms_xp,limit=1] Value short 1 run scoreboard players get #xp hms_temp_xp
tag @e[type=experience_orb,tag=hms_xp] remove hms_xp
