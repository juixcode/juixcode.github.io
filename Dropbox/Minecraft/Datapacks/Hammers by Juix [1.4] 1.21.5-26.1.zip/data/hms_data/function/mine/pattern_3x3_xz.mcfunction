execute positioned ~-1 ~ ~-1 run function hms_data:mine/block
execute positioned ~-1 ~ ~ run function hms_data:mine/block
execute positioned ~-1 ~ ~1 run function hms_data:mine/block
execute positioned ~ ~ ~-1 run function hms_data:mine/block
execute positioned ~ ~ ~1 run function hms_data:mine/block
execute positioned ~1 ~ ~-1 run function hms_data:mine/block
execute positioned ~1 ~ ~ run function hms_data:mine/block
execute positioned ~1 ~ ~1 run function hms_data:mine/block
