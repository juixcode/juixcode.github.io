# Creuse le plan actuel
$function hms_data:mine/plane_$(plane)

# Boucle pour la profondeur (Depth)
scoreboard players remove #depth hms_option_depth 1
$execute if score #depth hms_option_depth matches 1.. positioned ~$(dx) ~$(dy) ~$(dz) run function hms_data:mine/process {dx:$(dx), dy:$(dy), dz:$(dz), plane:"$(plane)"}
