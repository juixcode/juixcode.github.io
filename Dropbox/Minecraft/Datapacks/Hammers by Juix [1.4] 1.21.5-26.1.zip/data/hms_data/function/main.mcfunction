#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#   NETHERITE ADVANCEMENT INIT
execute as @a[tag=!hms_init_player] run function hms_data:init_player

#   SNEAK BYPASS
execute as @a run tag @s remove hms_is_sneaking_bypass
execute as @a[scores={hms_player_sneaking=1..}] if score world juix_option_sneak_bypass matches 1.. run tag @s add hms_is_sneaking_bypass

#   HAMMERS (Optimized Detection)
execute as @a[tag=!hms_holding_hammer] if predicate hms_data:holds_hammer run tag @s add hms_holding_hammer
execute as @a[tag=hms_holding_hammer] unless predicate hms_data:holds_hammer run tag @s remove hms_holding_hammer

execute as @a[tag=hms_holding_hammer,tag=!hms_is_sneaking_bypass] run function hms_data:mined_blocks

execute as @a[scores={hms_mined_blocks=1..},tag=hms_holding_hammer,tag=!hms_is_sneaking_bypass] at @s run function hms_data:vanilla_hammers
scoreboard players reset @a[scores={hms_mined_blocks=1..}] hms_mined_blocks

execute as @a[scores={hms_use_iron_pickaxe=1..}] run scoreboard players reset @s hms_use_iron_pickaxe
execute as @a[scores={hms_use_golden_pickaxe=1..}] run scoreboard players reset @s hms_use_golden_pickaxe
execute as @a[scores={hms_use_diamond_pickaxe=1..}] run scoreboard players reset @s hms_use_diamond_pickaxe
execute as @a[scores={hms_use_netherite_pickaxe=1..}] run scoreboard players reset @s hms_use_netherite_pickaxe

scoreboard players reset @a hms_player_sneaking

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=hms_smithing] run execute if items entity @s container.* minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[100]},minecraft:item_name={"text":"Diamond Hammer","italic":false}] run function hms_data:netherite_tool_name_replace