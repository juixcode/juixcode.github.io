execute as @s[scores={hms_use_iron_pickaxe=1..}] run scoreboard players add @s hms_mined_blocks 1
execute as @s[scores={hms_use_golden_pickaxe=1..}] run scoreboard players add @s hms_mined_blocks 1
execute as @s[scores={hms_use_diamond_pickaxe=1..}] run scoreboard players add @s hms_mined_blocks 1
execute as @s[scores={hms_use_netherite_pickaxe=1..}] run scoreboard players add @s hms_mined_blocks 1