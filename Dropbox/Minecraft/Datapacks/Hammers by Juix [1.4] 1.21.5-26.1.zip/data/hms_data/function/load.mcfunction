
#
#	DEFAULT
#

scoreboard objectives add hammers_installation_test dummy
execute if score world hammers_installation_test matches 3.. run tellraw @a {"text":"Hammers Reloaded","color":"green"}
execute unless score world hammers_installation_test matches 3.. run function hms_data:setup