scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#
#	DEFAULT
#

scoreboard objectives add hms_mined_blocks dummy
scoreboard objectives add hms_use_iron_pickaxe minecraft.used:minecraft.iron_pickaxe
scoreboard objectives add hms_use_golden_pickaxe minecraft.used:minecraft.golden_pickaxe
scoreboard objectives add hms_use_netherite_pickaxe minecraft.used:minecraft.netherite_pickaxe
scoreboard objectives add hms_use_diamond_pickaxe minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add hms_smithing_test dummy

scoreboard objectives add hms_option_size dummy
scoreboard players set world hms_option_size 1

scoreboard objectives add hms_option_depth dummy
scoreboard players set world hms_option_depth 1

scoreboard objectives add juix_option_sneak_bypass dummy
execute unless score world juix_option_sneak_bypass matches 0.. run scoreboard players set world juix_option_sneak_bypass 0

scoreboard objectives add hms_temp_xp dummy

scoreboard objectives add hms_player_sneaking minecraft.custom:minecraft.sneak_time

scoreboard players set world hammers_installation_test 3
tellraw @a {"text":"Hammers Installed","color":"green"}