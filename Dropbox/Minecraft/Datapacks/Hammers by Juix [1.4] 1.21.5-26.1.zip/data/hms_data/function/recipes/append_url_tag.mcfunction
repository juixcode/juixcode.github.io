# Vérifie si Hammers est installé, puis ajoute son tag à l'URL
execute if score world hammers_installation_test matches 1.. run function hms_data:recipes/concat_url_tag with storage juix:recipes
