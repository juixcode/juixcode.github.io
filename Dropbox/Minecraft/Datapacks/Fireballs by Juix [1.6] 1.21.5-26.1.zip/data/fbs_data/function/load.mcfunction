
#
#	DEFAULT
#

scoreboard objectives add fireballs_installation_test dummy
execute if score world fireballs_installation_test matches 2.. run tellraw @a {"text":"Fireballs Reloaded","color":"green"}
execute unless score world fireballs_installation_test matches 2.. run function fbs_data:setup

#   RECIPES WARNING

execute unless data storage juix:warning {loaded:true} run schedule function juix:warning 1t replace
data modify storage juix:warning loaded set value true