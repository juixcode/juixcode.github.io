# Stocker le nombre d’items tenus en main
execute store result score @s fbs_itemCount run data get entity @s SelectedItem.count

# Soustraire 1
scoreboard players remove @s fbs_itemCount 1

# Si le stack est encore ≥ 1, modifier sa quantité directement en place
execute if score @s fbs_itemCount matches 1.. run item modify entity @s weapon.mainhand fbs_data:decrease_count

# Sinon, si le stack tombe à 0, vider la main
execute unless score @s fbs_itemCount matches 1.. run item replace entity @s weapon.mainhand with air