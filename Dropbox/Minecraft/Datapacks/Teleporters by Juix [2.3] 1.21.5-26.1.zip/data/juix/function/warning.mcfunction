tellraw @a ["",{"text":"<Juix> You're using some of my datapacks that add new recipes. Use ","color":"gray"},{"text":"/trigger show_recipes_in_xxx","color":"yellow","click_event":{"action":"suggest_command","command":"/trigger show_recipes_in_"}},{"text":" to display them !","color":"gray"}]

data remove storage juix:warning loaded
