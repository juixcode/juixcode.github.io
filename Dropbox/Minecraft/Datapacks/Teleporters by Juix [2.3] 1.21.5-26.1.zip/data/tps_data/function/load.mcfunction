
#
#	DEFAULT
#

scoreboard objectives add teleporters_installation_test dummy
execute if score world teleporters_installation_test matches 5.. run tellraw @a {"text":"Teleporters Reloaded","color":"green"}
execute unless score world teleporters_installation_test matches 5.. run function tps_data:setup

#   RECIPES WARNING

execute unless data storage juix:warning {loaded:true} run schedule function juix:warning 1t replace
data modify storage juix:warning loaded set value true