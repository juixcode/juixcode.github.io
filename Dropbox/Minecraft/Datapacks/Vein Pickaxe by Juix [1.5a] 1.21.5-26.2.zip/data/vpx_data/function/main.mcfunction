#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#   NETHERITE ADVANCEMENT INIT
execute as @a[tag=!vpx_init_player] run function vpx_data:init_player

#   SNEAK BYPASS
execute as @a run tag @s remove vpx_is_sneaking_bypass
execute as @a[scores={vpx_player_sneaking=1..}] if score world juix_option_sneak_bypass matches 1.. run tag @s add vpx_is_sneaking_bypass

#   VEIN PICKAXES
execute as @a[tag=!vpx_holding_vein_pickaxe] if predicate vpx_data:holds_pickaxe run tag @s add vpx_holding_vein_pickaxe
execute as @a[tag=vpx_holding_vein_pickaxe] unless predicate vpx_data:holds_pickaxe run tag @s remove vpx_holding_vein_pickaxe

execute as @a[tag=vpx_holding_vein_pickaxe,tag=!vpx_is_sneaking_bypass] run function vpx_data:mined_blocks

execute as @a[scores={vpx_mined_blocks=1..},tag=vpx_holding_vein_pickaxe,tag=!vpx_is_sneaking_bypass] at @s anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function vpx_data:set_initial_position
scoreboard players reset @a[scores={vpx_mined_blocks=1..}] vpx_mined_blocks

execute as @a[scores={vpx_use_diamond_pickaxe=1..}] run scoreboard players reset @s vpx_use_diamond_pickaxe
execute as @a[scores={vpx_use_netherite_pickaxe=1..}] run scoreboard players reset @s vpx_use_netherite_pickaxe

scoreboard players reset @a vpx_player_sneaking

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=vpx_smithing] if items entity @s container.* minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run function vpx_data:netherite_tool_name_replace
