advancement revoke @s only vpx_data:netherite_vein_pickaxe_adv

execute as @s store result score @s vpx_smithing_test run clear @s minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] 0
execute as @s[scores={vpx_smithing_test=1..}] run tag @s add vpx_smithing
execute as @s[tag=vpx_smithing] run function vpx_data:netherite_tool_name_replace