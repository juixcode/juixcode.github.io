execute if items entity @s hotbar.0 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.0 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.1 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.1 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.2 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.2 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.3 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.3 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.4 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.4 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.5 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.5 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.6 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.6 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.7 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.7 vpx_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.8 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s hotbar.8 vpx_data:netherite_pickaxe_modifier

execute if items entity @s inventory.0 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.0 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.1 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.1 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.2 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.2 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.3 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.3 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.4 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.4 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.5 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.5 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.6 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.6 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.7 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.7 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.8 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.8 vpx_data:netherite_pickaxe_modifier

execute if items entity @s inventory.9 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.9 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.10 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.10 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.11 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.11 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.12 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.12 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.13 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.13 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.14 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.14 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.15 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.15 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.16 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.16 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.17 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.17 vpx_data:netherite_pickaxe_modifier

execute if items entity @s inventory.18 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.18 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.19 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.19 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.20 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.20 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.21 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.21 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.22 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.22 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.23 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.23 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.24 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.24 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.25 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.25 vpx_data:netherite_pickaxe_modifier
execute if items entity @s inventory.26 minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s inventory.26 vpx_data:netherite_pickaxe_modifier

execute if items entity @s weapon.offhand minecraft:netherite_pickaxe[minecraft:custom_data~{vpx_diamond_vein_pickaxe:true}] run item modify entity @s weapon.offhand vpx_data:netherite_pickaxe_modifier

tag @s remove vpx_smithing