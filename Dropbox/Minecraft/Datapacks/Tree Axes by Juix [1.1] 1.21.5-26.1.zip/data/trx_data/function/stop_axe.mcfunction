effect clear @s minecraft:mining_fatigue
function trx_data:unset_restricted_tool
