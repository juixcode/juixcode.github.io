#
#   VEIN DETECTION
#

#   BOTTOM LAYER
tp @s ~ ~-1 ~
execute at @s run function trx_data:mine/block
tp @s ~-1 ~-1 ~
execute at @s run function trx_data:mine/block
tp @s ~ ~-1 ~-1
execute at @s run function trx_data:mine/block
tp @s ~1 ~-1 ~
execute at @s run function trx_data:mine/block
tp @s ~ ~-1 ~1
execute at @s run function trx_data:mine/block

#   MIDDLE LAYER
tp @s ~-1 ~ ~
execute at @s run function trx_data:mine/block
tp @s ~ ~ ~-1
execute at @s run function trx_data:mine/block
tp @s ~1 ~ ~
execute at @s run function trx_data:mine/block
tp @s ~ ~ ~1
execute at @s run function trx_data:mine/block
tp @s ~-1 ~ ~-1
execute at @s run function trx_data:mine/block
tp @s ~1 ~ ~1
execute at @s run function trx_data:mine/block
tp @s ~-1 ~ ~1
execute at @s run function trx_data:mine/block
tp @s ~1 ~ ~-1
execute at @s run function trx_data:mine/block

#   TOP LAYER
tp @s ~ ~1 ~
execute at @s run function trx_data:mine/block
tp @s ~-1 ~1 ~
execute at @s run function trx_data:mine/block
tp @s ~ ~1 ~-1
execute at @s run function trx_data:mine/block
tp @s ~1 ~1 ~
execute at @s run function trx_data:mine/block
tp @s ~ ~1 ~1
execute at @s run function trx_data:mine/block

kill @s