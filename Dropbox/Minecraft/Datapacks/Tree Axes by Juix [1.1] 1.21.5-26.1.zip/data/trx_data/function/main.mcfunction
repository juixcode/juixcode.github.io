#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=8}] run function trx_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function trx_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function trx_data:recipes/show_links

#   NETHERITE ADVANCEMENT INIT
execute as @a[tag=!trx_init_player] run function trx_data:init_player

#   RESTRICTED TOOL PROTECTION - FOR MAGNETS COMPATIBILITY
execute as @a[tag=!vein_axe] if items entity @s weapon.mainhand netherite_axe[custom_model_data={floats:[101]}] run function trx_data:set_restricted_tool
execute as @a[tag=!vein_axe] if items entity @s weapon.mainhand diamond_axe[custom_model_data={floats:[101]}] run function trx_data:set_restricted_tool
execute as @a[tag=!vein_axe] if items entity @s weapon.mainhand golden_axe[custom_model_data={floats:[101]}] run function trx_data:set_restricted_tool
execute as @a[tag=!vein_axe] if items entity @s weapon.mainhand iron_axe[custom_model_data={floats:[101]}] run function trx_data:set_restricted_tool

execute as @a[tag=vein_axe] unless items entity @s weapon.mainhand diamond_axe[custom_model_data={floats:[101]}] unless items entity @s weapon.mainhand netherite_axe[custom_model_data={floats:[101]}] unless items entity @s weapon.mainhand golden_axe[custom_model_data={floats:[101]}] unless items entity @s weapon.mainhand iron_axe[custom_model_data={floats:[101]}] run function trx_data:stop_axe

execute as @a[tag=vein_axe] unless entity @s[nbt={active_effects:[{id:"minecraft:mining_fatigue"}]}] run effect give @s minecraft:mining_fatigue 999999 0 true

execute as @a[scores={juix_restricted_tool=1..}] run tag @s add juix_restricted_tool
execute as @a unless entity @s[scores={juix_restricted_tool=1..}] run tag @s remove juix_restricted_tool

#   TREE AXE

execute as @a[scores={trx_use_netherite_axe=1..},tag=vein_axe] at @s run summon minecraft:marker ~ ~ ~ {Tags:["vein_axe_detection","trx_initial_marker"]}
execute as @a[scores={trx_use_diamond_axe=1..},tag=vein_axe] at @s run summon minecraft:marker ~ ~ ~ {Tags:["vein_axe_detection","trx_initial_marker"]}
execute as @a[scores={trx_use_golden_axe=1..},tag=vein_axe] at @s run summon minecraft:marker ~ ~ ~ {Tags:["vein_axe_detection","trx_initial_marker"]}
execute as @a[scores={trx_use_iron_axe=1..},tag=vein_axe] at @s run summon minecraft:marker ~ ~ ~ {Tags:["vein_axe_detection","trx_initial_marker"]}

execute as @a[scores={trx_use_netherite_axe=1..},tag=vein_axe] at @s run execute as @e[tag=trx_initial_marker,sort=nearest,limit=1] at @s run tp @s @e[distance=..6,sort=nearest,limit=1,type=item,tag=!vein_axe_mined]
execute as @a[scores={trx_use_diamond_axe=1..},tag=vein_axe] at @s run execute as @e[tag=trx_initial_marker,sort=nearest,limit=1] at @s run tp @s @e[distance=..6,sort=nearest,limit=1,type=item,tag=!vein_axe_mined]
execute as @a[scores={trx_use_golden_axe=1..},tag=vein_axe] at @s run execute as @e[tag=trx_initial_marker,sort=nearest,limit=1] at @s run tp @s @e[distance=..6,sort=nearest,limit=1,type=item,tag=!vein_axe_mined]
execute as @a[scores={trx_use_iron_axe=1..},tag=vein_axe] at @s run execute as @e[tag=trx_initial_marker,sort=nearest,limit=1] at @s run tp @s @e[distance=..6,sort=nearest,limit=1,type=item,tag=!vein_axe_mined]
execute as @e[tag=trx_initial_marker,sort=nearest,limit=1] at @s align xyz run tp @s ~0.5 ~ ~0.5

execute as @e[tag=trx_initial_marker] at @s unless items entity @e[type=item,tag=!vein_axe_mined,distance=..1,limit=1,sort=nearest] contents #trx_data:valid_tree_drops run kill @s
tag @e[tag=trx_initial_marker] remove trx_initial_marker

execute as @e[tag=vein_axe_detection] at @s run function trx_data:vein_axe

scoreboard players reset @a trx_use_iron_axe
scoreboard players reset @a trx_use_golden_axe
scoreboard players reset @a trx_use_diamond_axe
scoreboard players reset @a trx_use_netherite_axe

execute at @a[tag=vein_axe] run tag @e[type=item,tag=!vein_axe_mined,distance=..6] add vein_axe_mined
execute as @e[tag=vein_axe_mined] run tag @s add juix_teleportable_item

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=trx_smithing] if items entity @s container.* minecraft:netherite_axe[minecraft:custom_model_data={floats:[101]},minecraft:item_name={"text":"Diamond Tree Axe","italic":false}] run function trx_data:netherite_tool_name_replace