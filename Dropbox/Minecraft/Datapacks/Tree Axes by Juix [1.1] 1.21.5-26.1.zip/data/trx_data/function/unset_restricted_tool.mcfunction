scoreboard players remove @s juix_restricted_tool 1
tag @s remove vein_axe