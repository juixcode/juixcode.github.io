recipe take @s minecraft:netherite_axe_smithing
tag @s add trx_init_player