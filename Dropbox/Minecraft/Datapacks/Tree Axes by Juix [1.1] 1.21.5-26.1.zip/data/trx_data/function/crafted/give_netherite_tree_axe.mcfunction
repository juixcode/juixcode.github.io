recipe take @s minecraft:netherite_axe_smithing
advancement revoke @s only trx_data:netherite_tree_axe_adv

execute as @s store result score @s trx_smithing_test run clear @s minecraft:netherite_axe[minecraft:custom_model_data={floats:[101]},minecraft:item_name={"text":"Diamond Tree Axe","italic":false}] 0
execute as @s[scores={trx_smithing_test=1..}] run tag @s add trx_smithing