scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

scoreboard objectives add juix_restricted_tool dummy

scoreboard objectives add trx_leaf_count dummy
scoreboard objectives add vein_axes_mined_blocks dummy
scoreboard objectives add trx_smithing_test dummy

scoreboard objectives add trx_use_iron_axe minecraft.used:minecraft.iron_axe
scoreboard objectives add trx_use_golden_axe minecraft.used:minecraft.golden_axe
scoreboard objectives add trx_use_diamond_axe minecraft.used:minecraft.diamond_axe
scoreboard objectives add trx_use_netherite_axe minecraft.used:minecraft.netherite_axe

scoreboard objectives add trx_option_leaves_breaking dummy
scoreboard players set world trx_option_leaves_breaking 1

scoreboard players set world tree_axes_installation_test 1
tellraw @a {"text":"Tree Axes Installed","color":"green"}