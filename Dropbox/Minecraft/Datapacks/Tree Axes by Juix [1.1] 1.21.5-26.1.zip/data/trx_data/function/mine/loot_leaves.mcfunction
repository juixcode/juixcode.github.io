execute as @p[tag=vein_axe] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air

playsound minecraft:block.leaf_litter.break block @a ~ ~ ~ 1 1

summon minecraft:marker ~ ~ ~ {Tags:["vein_axe_detection","leaves_breaking"]}

#   LEAF COUNTING
scoreboard players operation @e[tag=leaves_breaking,sort=nearest,limit=1] trx_leaf_count = @s trx_leaf_count
scoreboard players add @e[tag=leaves_breaking,sort=nearest,limit=1] trx_leaf_count 1
tag @e[tag=leaves_breaking,sort=nearest,limit=1] remove leaves_breaking