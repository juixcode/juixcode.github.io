execute as @p[tag=vein_axe] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air

playsound minecraft:block.stone.break block @a ~ ~ ~ 1 1

summon minecraft:marker ~ ~ ~ {Tags:["vein_axe_detection"]}