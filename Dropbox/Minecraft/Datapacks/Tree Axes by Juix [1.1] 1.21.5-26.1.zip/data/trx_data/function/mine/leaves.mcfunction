#   ORES

execute if block ~ ~ ~ #minecraft:leaves run function trx_data:mine/loot_leaves