scoreboard players reset @s juix_restricted_tool
scoreboard players add @s juix_restricted_tool 1
tag @s add vein_axe