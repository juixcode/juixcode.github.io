scoreboard players add world trx_option_leaves_breaking 1
execute if score world trx_option_leaves_breaking matches 2.. run scoreboard players set world trx_option_leaves_breaking 0

execute if score world trx_option_leaves_breaking matches 0 run tellraw @s {"text":"Leaves Breaking (when a tree is cut down): Disabled","color":"red"}
execute if score world trx_option_leaves_breaking matches 1 run tellraw @s {"text":"Leaves Breaking (when a tree is cut down): Enabled","color":"green"}