
scoreboard objectives remove vein_axes_mined_blocks
scoreboard objectives remove trx_smithing_test

scoreboard objectives remove trx_use_iron_axe
scoreboard objectives remove trx_use_golden_axe
scoreboard objectives remove trx_use_diamond_axe
scoreboard objectives remove trx_use_netherite_axe

scoreboard objectives remove trx_leaf_count

scoreboard objectives remove tree_axes_installation_test

tellraw @a {"text":"Uninstalled Tree Axes","color":"red"}
datapack disable "file/Tree Axes by Juix [1.1] 1.21.5-26.1"
datapack disable "file/Tree Axes by Juix [1.1] 1.21.5-26.1.zip"