
execute store result score @s beg_motion_x1 run data get entity @p Rotation[0]
execute store result score @s beg_motion_y1 run data get entity @p Rotation[1]
execute store result score @s beg_motion_z1 run data get entity @p Rotation[2]

tag @s add beg_updated