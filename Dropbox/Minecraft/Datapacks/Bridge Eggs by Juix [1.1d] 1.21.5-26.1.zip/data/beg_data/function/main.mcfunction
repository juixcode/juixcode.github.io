#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=3}] run function beg_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function beg_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function beg_data:recipes/show_links

#   BRIDGE EGGS

execute as @e[type=egg,tag=!beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] at @s run function beg_data:items/update

execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] run execute store result entity @s Rotation[0] float 1 run scoreboard players get @s beg_motion_x1
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] run execute store result entity @s Rotation[1] float 1 run scoreboard players get @s beg_motion_y1
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] run execute store result entity @s Rotation[2] float 1 run scoreboard players get @s beg_motion_z1

execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] at @s run playsound minecraft:block.note_block.xylophone block @a ~ ~ ~ 1 1
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_leaves_bridge_egg:1}}}}] at @s positioned ^ ^-1 ^-2 unless entity @a[distance=..2.5] positioned ^ ^ ^2 run fill ^-1 ^ ^-2 ^1 ^ ^-3 minecraft:oak_leaves replace minecraft:air
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_ice_bridge_egg:1}}}}] at @s positioned ^ ^-1 ^-2 unless entity @a[distance=..2.5] positioned ^ ^ ^2 run fill ^-1 ^ ^-2 ^1 ^ ^-3 minecraft:ice replace minecraft:air