scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

scoreboard objectives add beg_motion_x1 dummy
scoreboard objectives add beg_motion_y1 dummy
scoreboard objectives add beg_motion_z1 dummy

scoreboard players set world bridge_eggs_installation_test 1
tellraw @a {"text":"Bridge Eggs Installed","color":"green"}