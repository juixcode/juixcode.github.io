#
#	DEFAULT
#

scoreboard objectives add bridge_eggs_installation_test dummy
execute if score world bridge_eggs_installation_test matches 1.. run tellraw @a {"text":"Bridge Eggs Reloaded","color":"green"}
execute unless score world bridge_eggs_installation_test matches 1.. run function beg_data:setup