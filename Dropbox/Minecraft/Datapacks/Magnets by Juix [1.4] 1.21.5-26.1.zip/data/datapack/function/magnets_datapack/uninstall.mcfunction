
#
#	MGS DATAPACK
#

scoreboard objectives remove magnets_installation_test

tellraw @a {"text":"Uninstalled Magnets","color":"red"}
datapack disable "file/Magnets by Juix [1.4] 1.21.5-26.1"
datapack disable "file/Magnets by Juix [1.4] 1.21.5-26.1.zip"