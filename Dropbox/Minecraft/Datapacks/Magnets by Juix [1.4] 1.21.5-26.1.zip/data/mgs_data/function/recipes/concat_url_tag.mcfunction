$data modify storage juix:recipes url set value "$(url)magnets,"
