#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#	DELAI TICKER
scoreboard players add @e[type=item] mgs_item_age 1
scoreboard players add @e[type=experience_orb] mgs_item_age 1

#	MAGNET
execute as @a if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[100]}] at @s run tp @e[type=item,distance=..4,scores={mgs_item_age=5..}] ~ ~ ~
execute as @a if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[100]}] at @s run tp @e[type=experience_orb,distance=..4,scores={mgs_item_age=5..}] ~ ~ ~

#	SUPER MAGNET
execute as @a if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[101]}] at @s run tp @e[type=item,distance=..8,scores={mgs_item_age=5..}] ~ ~ ~
execute as @a if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[101]}] at @s run tp @e[type=experience_orb,distance=..8,scores={mgs_item_age=5..}] ~ ~ ~