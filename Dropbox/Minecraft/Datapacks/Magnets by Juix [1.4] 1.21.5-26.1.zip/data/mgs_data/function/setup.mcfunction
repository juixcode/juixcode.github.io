scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

scoreboard objectives add mgs_item_age dummy

#
#	DEFAULT
#

scoreboard players set world magnets_installation_test 2
tellraw @a {"text":"Magnets Installed","color":"green"}