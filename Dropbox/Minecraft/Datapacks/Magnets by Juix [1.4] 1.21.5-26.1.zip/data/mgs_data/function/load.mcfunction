
#
#	DEFAULT
#

scoreboard objectives add magnets_installation_test dummy
execute if score world magnets_installation_test matches 2.. run tellraw @a {"text":"Magnets Reloaded","color":"green"}
execute unless score world magnets_installation_test matches 2.. run function mgs_data:setup