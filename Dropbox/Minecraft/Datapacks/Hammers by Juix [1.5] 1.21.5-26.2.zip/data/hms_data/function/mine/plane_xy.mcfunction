function hms_data:mine/block
execute if score world hms_option_size matches 1.. run function hms_data:mine/pattern_3x3_xy
execute if score world hms_option_size matches 2.. run function hms_data:mine/pattern_5x5_xy