advancement revoke @s only hms_data:netherite_hammer_adv

execute as @s store result score @s hms_smithing_test run clear @s minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] 0
execute as @s[scores={hms_smithing_test=1..}] run tag @s add hms_smithing
execute as @s[tag=hms_smithing] run function hms_data:netherite_tool_name_replace