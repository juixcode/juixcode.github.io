
#
#	DEFAULT
#

scoreboard objectives add hammers_installation_test dummy
execute if score world hammers_installation_test matches 3.. run tellraw @a {"text":"Hammers Reloaded","color":"green"}
execute unless score world hammers_installation_test matches 3.. run function hms_data:setup

#   RECIPES WARNING

execute unless data storage juix:warning {loaded:true} run schedule function juix:warning 1t replace
data modify storage juix:warning loaded set value true