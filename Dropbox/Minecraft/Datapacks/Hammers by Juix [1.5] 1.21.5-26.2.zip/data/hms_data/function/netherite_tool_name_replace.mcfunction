execute if items entity @s hotbar.0 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.0 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.1 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.1 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.2 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.2 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.3 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.3 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.4 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.4 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.5 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.5 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.6 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.6 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.7 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.7 hms_data:netherite_pickaxe_modifier
execute if items entity @s hotbar.8 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s hotbar.8 hms_data:netherite_pickaxe_modifier

execute if items entity @s inventory.0 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.0 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.1 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.1 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.2 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.2 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.3 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.3 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.4 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.4 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.5 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.5 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.6 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.6 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.7 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.7 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.8 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.8 hms_data:netherite_pickaxe_modifier

execute if items entity @s inventory.9 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.9 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.10 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.10 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.11 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.11 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.12 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.12 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.13 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.13 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.14 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.14 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.15 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.15 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.16 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.16 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.17 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.17 hms_data:netherite_pickaxe_modifier

execute if items entity @s inventory.18 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.18 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.19 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.19 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.20 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.20 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.21 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.21 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.22 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.22 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.23 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.23 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.24 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.24 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.25 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.25 hms_data:netherite_pickaxe_modifier
execute if items entity @s inventory.26 minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s inventory.26 hms_data:netherite_pickaxe_modifier

execute if items entity @s weapon.offhand minecraft:netherite_pickaxe[minecraft:custom_data~{hms_diamond_hammer:true}] run item modify entity @s weapon.offhand hms_data:netherite_pickaxe_modifier

tag @s remove hms_smithing