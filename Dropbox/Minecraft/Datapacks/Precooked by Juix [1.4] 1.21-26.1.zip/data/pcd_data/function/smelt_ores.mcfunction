execute as @e[type=item] if items entity @s contents minecraft:raw_iron at @s run function pcd_data:cook/iron with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:raw_gold at @s run function pcd_data:cook/gold with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:raw_copper at @s run function pcd_data:cook/copper with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:ancient_debris at @s run function pcd_data:cook/netherite with entity @s Item