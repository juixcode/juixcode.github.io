
#
#	DEFAULT
#

scoreboard objectives add pcd_option_food_cooking dummy
scoreboard players set world pcd_option_food_cooking 1

scoreboard objectives add pcd_option_ores_smelting dummy
scoreboard players set world pcd_option_ores_smelting 1

scoreboard players set world precooked_installation_test 2
tellraw @a {"text":"Precooked Installed","color":"green"}