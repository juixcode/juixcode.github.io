
#
#	DEFAULT
#

scoreboard objectives add precooked_installation_test dummy
execute if score world precooked_installation_test matches 2.. run tellraw @a {"text":"Precooked Reloaded","color":"green"}
execute unless score world precooked_installation_test matches 2.. run function pcd_data:setup