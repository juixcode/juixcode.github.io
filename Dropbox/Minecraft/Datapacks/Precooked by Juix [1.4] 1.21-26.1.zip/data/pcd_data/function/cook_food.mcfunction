execute as @e[type=item] if items entity @s contents minecraft:beef at @s run function pcd_data:cook/beef with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:mutton at @s run function pcd_data:cook/mutton with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:porkchop at @s run function pcd_data:cook/porkchop with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:chicken at @s run function pcd_data:cook/chicken with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:salmon at @s run function pcd_data:cook/salmon with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:cod at @s run function pcd_data:cook/cod with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:rabbit at @s run function pcd_data:cook/rabbit with entity @s Item
execute as @e[type=item] if items entity @s contents minecraft:kelp at @s run function pcd_data:cook/kelp with entity @s Item