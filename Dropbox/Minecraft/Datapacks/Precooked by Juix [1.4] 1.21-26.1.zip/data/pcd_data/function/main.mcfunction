#   ORES
execute if score world pcd_option_ores_smelting matches 1 run function pcd_data:smelt_ores

#   FOOD
execute if score world pcd_option_food_cooking matches 1 run function pcd_data:cook_food