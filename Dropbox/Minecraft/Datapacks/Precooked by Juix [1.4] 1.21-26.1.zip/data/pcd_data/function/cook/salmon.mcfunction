$summon item ~ ~ ~ {Item:{id:"minecraft:cooked_salmon", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s