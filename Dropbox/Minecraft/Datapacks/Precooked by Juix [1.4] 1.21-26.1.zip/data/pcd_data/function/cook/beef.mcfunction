$summon item ~ ~ ~ {Item:{id:"minecraft:cooked_beef", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s