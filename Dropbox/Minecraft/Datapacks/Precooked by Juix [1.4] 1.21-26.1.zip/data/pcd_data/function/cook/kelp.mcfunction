$summon item ~ ~ ~ {Item:{id:"minecraft:dried_kelp", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s