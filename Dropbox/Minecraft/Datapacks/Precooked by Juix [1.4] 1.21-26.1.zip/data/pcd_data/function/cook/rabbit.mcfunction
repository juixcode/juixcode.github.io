$summon item ~ ~ ~ {Item:{id:"minecraft:cooked_rabbit", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s