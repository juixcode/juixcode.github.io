$summon item ~ ~ ~ {Item:{id:"minecraft:netherite_scrap", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s