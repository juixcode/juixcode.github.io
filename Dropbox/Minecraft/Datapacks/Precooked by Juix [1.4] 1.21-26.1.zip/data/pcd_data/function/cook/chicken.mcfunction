$summon item ~ ~ ~ {Item:{id:"minecraft:cooked_chicken", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s