$summon item ~ ~ ~ {Item:{id:"minecraft:cooked_porkchop", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s