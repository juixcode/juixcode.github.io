$summon item ~ ~ ~ {Item:{id:"minecraft:gold_ingot", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s