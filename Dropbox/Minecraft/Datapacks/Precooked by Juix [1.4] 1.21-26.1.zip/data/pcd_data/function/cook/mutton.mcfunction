$summon item ~ ~ ~ {Item:{id:"minecraft:cooked_mutton", count:$(count)b}}
$summon experience_orb ~ ~ ~ {Value:$(count)}

kill @s