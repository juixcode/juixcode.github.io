scoreboard players add world pcd_option_ores_smelting 1
execute if score world pcd_option_ores_smelting matches 2.. run scoreboard players set world pcd_option_ores_smelting 0

execute if score world pcd_option_ores_smelting matches 0 run tellraw @s {"text":"Ores auto-smelting : Disabled","color":"red"}
execute if score world pcd_option_ores_smelting matches 1 run tellraw @s {"text":"Ores auto-smelting : Enabled","color":"green"}