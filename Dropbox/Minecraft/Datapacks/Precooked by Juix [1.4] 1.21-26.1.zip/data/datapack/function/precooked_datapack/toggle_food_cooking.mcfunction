scoreboard players add world pcd_option_food_cooking 1
execute if score world pcd_option_food_cooking matches 2.. run scoreboard players set world pcd_option_food_cooking 0

execute if score world pcd_option_food_cooking matches 0 run tellraw @s {"text":"Food auto-cooking : Disabled","color":"red"}
execute if score world pcd_option_food_cooking matches 1 run tellraw @s {"text":"Food auto-cooking : Enabled","color":"green"}