
scoreboard objectives remove precooked_installation_test

scoreboard objectives remove pcd_option_food_cooking
scoreboard objectives remove pcd_option_ores_smelting

tellraw @a {"text":"Uninstalled Precooked","color":"red"}
datapack disable "file/Precooked by Juix [1.4] 1.21-26.1"
datapack disable "file/Precooked by Juix [1.4] 1.21-26.1.zip"