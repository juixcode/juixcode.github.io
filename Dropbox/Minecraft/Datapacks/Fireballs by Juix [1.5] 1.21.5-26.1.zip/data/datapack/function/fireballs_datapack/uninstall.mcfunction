
scoreboard objectives remove fbs_item_clicked
scoreboard objectives remove fbs_itemCount

scoreboard objectives remove fbs_motion_x1
scoreboard objectives remove fbs_motion_y1
scoreboard objectives remove fbs_motion_z1
scoreboard objectives remove fbs_motion_x2
scoreboard objectives remove fbs_motion_y2
scoreboard objectives remove fbs_motion_z2

scoreboard objectives remove fbs_option_power

scoreboard objectives remove fireballs_installation_test

tellraw @a {"text":"Uninstalled Fireballs","color":"red"}
datapack disable "file/Fireballs by Juix [1.5] 1.21.5-26.1"
datapack disable "file/Fireballs by Juix [1.5] 1.21.5-26.1.zip"