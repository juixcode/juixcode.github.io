# V�rifie si le pack est install�, puis ajoute son tag � l'URL
execute if score world fireballs_installation_test matches 1.. run function fbs_data:recipes/concat_url_tag with storage juix:recipes
