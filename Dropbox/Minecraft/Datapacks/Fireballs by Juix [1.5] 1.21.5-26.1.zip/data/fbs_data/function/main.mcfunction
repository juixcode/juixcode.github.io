#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#   FIREBALLS

execute as @a[scores={fbs_item_clicked=1..}] run function fbs_data:item_clicked
execute if score world fbs_option_power matches -2..0 run execute as @e[type=marker,tag=fbs_detect_explosion] at @s unless entity @e[type=fireball,distance=..1] run function fbs_data:items/explosion_without_damages