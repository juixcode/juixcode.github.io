
scoreboard objectives remove vein_pickaxes_mined_blocks
scoreboard objectives remove vpx_mined_blocks
scoreboard objectives remove vpx_smithing_test
scoreboard objectives remove vpx_temp_xp

scoreboard objectives remove vpx_use_diamond_pickaxe
scoreboard objectives remove vpx_use_netherite_pickaxe

scoreboard objectives remove vein_pickaxe_installation_test

tellraw @a {"text":"Uninstalled Vein Pickaxe","color":"red"}
datapack disable "file/Vein Pickaxe by Juix [1.5] 1.21.5-26.2"
datapack disable "file/Vein Pickaxe by Juix [1.5] 1.21.5-26.2.zip"