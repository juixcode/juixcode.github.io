execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[110]}] run function fbs_data:items/launch_fireball
execute if items entity @s[gamemode=!creative] weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[110]}] run function fbs_data:item_count_decrease

execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[111]}] run function fbs_data:items/launch_super_fireball
execute if items entity @s[gamemode=!creative] weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[111]}] run function fbs_data:item_count_decrease

execute if items entity @s weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[112]}] run function fbs_data:items/launch_mega_fireball
execute if items entity @s[gamemode=!creative] weapon.mainhand minecraft:carrot_on_a_stick[minecraft:custom_model_data={floats:[112]}] run function fbs_data:item_count_decrease

scoreboard players reset @s fbs_item_clicked