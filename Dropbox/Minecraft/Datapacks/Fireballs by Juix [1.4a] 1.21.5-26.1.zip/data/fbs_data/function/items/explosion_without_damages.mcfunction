execute if entity @s[tag=fbs_detect_explosion_fb1] run particle minecraft:explosion ~ ~ ~ 1.5 1.5 1.5 1 10
execute if entity @s[tag=fbs_detect_explosion_fb1] run particle minecraft:poof ~ ~ ~ 1 1 1 0.2 10
execute unless score world fbs_option_power matches -2 if entity @s[tag=fbs_detect_explosion_fb1] run fill ~ ~-1 ~ ~ ~1 ~ fire replace air
execute unless score world fbs_option_power matches 0 if entity @s[tag=fbs_detect_explosion_fb1] run execute as @e[distance=..3,type=!marker] run damage @s 6 minecraft:explosion at ~ ~ ~

execute if entity @s[tag=fbs_detect_explosion_fb2] run particle minecraft:explosion_emitter ~ ~ ~ 1 1 1 1 1
execute if entity @s[tag=fbs_detect_explosion_fb2] run particle minecraft:poof ~ ~ ~ 2 2 2 0.2 20
execute unless score world fbs_option_power matches -2 if entity @s[tag=fbs_detect_explosion_fb2] run fill ~-1 ~-1 ~ ~1 ~1 ~ fire replace air
execute unless score world fbs_option_power matches -2 if entity @s[tag=fbs_detect_explosion_fb2] run fill ~ ~-1 ~-1 ~ ~1 ~1 fire replace air
execute unless score world fbs_option_power matches 0 if entity @s[tag=fbs_detect_explosion_fb2] run execute as @e[distance=..6,type=!marker] run damage @s 12 minecraft:explosion at ~ ~ ~

execute if entity @s[tag=fbs_detect_explosion_fb3] run particle minecraft:explosion_emitter ~ ~ ~ 2 2 2 1 3
execute if entity @s[tag=fbs_detect_explosion_fb3] run particle minecraft:poof ~ ~ ~ 4 4 4 0.2 30
execute unless score world fbs_option_power matches -2 if entity @s[tag=fbs_detect_explosion_fb3] run fill ~-1 ~-1 ~-1 ~1 ~1 ~1 fire replace air
execute unless score world fbs_option_power matches 0 if entity @s[tag=fbs_detect_explosion_fb3] run execute as @e[distance=..10,type=!marker] run damage @s 25 minecraft:explosion at ~ ~ ~

kill @s