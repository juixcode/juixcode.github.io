execute at @s run playsound minecraft:entity.ender_dragon.shoot player @a ~ ~ ~ 1 1.2

execute if score world fbs_option_power matches ..0 run execute at @s run summon minecraft:fireball ^ ^ ^1 {Tags:["fbs_fireball"],Invulnerable:true,PersistenceRequired:true,NoBasePlate:true,Small:true,ExplosionPower:0,Passengers:[{id:"minecraft:marker",Tags:["fbs_detect_explosion","fbs_detect_explosion_fb3"]}]}
execute if score world fbs_option_power matches 1 run execute at @s run summon minecraft:fireball ^ ^ ^1 {Tags:["fbs_fireball"],Invulnerable:true,PersistenceRequired:true,NoBasePlate:true,Small:true,ExplosionPower:5}
execute if score world fbs_option_power matches 2 run execute at @s run summon minecraft:fireball ^ ^ ^1 {Tags:["fbs_fireball"],Invulnerable:true,PersistenceRequired:true,NoBasePlate:true,Small:true,ExplosionPower:10}

execute at @s as @e[tag=fbs_fireball,limit=1,sort=nearest] at @s run tp @s ~ ~1 ~
execute at @s as @e[tag=fbs_fireball,limit=1,sort=nearest] at @s rotated as @p run function fbs_data:items/fireball_motion
