
#
#	DEFAULT
#

scoreboard objectives add fireballs_installation_test dummy
execute if score world fireballs_installation_test matches 2.. run tellraw @a {"text":"Fireballs Reloaded","color":"green"}
execute unless score world fireballs_installation_test matches 2.. run function fbs_data:setup