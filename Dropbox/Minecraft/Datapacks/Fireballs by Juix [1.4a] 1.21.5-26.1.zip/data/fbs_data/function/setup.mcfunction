scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

scoreboard objectives add fbs_itemCount dummy
setblock 0 -64 0 minecraft:barrel
forceload add 0 0

scoreboard objectives add fbs_item_clicked minecraft.used:minecraft.carrot_on_a_stick

scoreboard objectives add fbs_option_power dummy
scoreboard players set world fbs_option_power 1

scoreboard objectives add fbs_motion_x1 dummy
scoreboard objectives add fbs_motion_y1 dummy
scoreboard objectives add fbs_motion_z1 dummy
scoreboard objectives add fbs_motion_x2 dummy
scoreboard objectives add fbs_motion_y2 dummy
scoreboard objectives add fbs_motion_z2 dummy

scoreboard players set world fireballs_installation_test 2
tellraw @a {"text":"Fireballs Installed","color":"green"}