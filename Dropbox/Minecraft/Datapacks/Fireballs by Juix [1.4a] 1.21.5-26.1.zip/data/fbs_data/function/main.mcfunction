#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=2}] run function fbs_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function fbs_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function fbs_data:recipes/show_links

#   FIREBALLS

execute as @a[scores={fbs_item_clicked=1..}] run function fbs_data:item_clicked
execute if score world fbs_option_power matches -2..0 run execute as @e[type=marker,tag=fbs_detect_explosion] at @s unless entity @e[type=fireball,distance=..1] run function fbs_data:items/explosion_without_damages