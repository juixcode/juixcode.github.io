scoreboard players reset @s juix_recipes_tellraw_id
scoreboard players reset @s show_recipes
scoreboard players reset @s show_recipes_weblinks