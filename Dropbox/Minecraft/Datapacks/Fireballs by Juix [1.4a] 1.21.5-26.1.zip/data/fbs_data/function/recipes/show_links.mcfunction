tellraw @s ["",{"text":"\u2b25 [","color":"dark_gray"},{"text":"Fireballs Documentation","color":"green","click_event":{"action":"open_url","url":"https://modrinth.com/datapack/fireballs-by-juix"}},{"text":"]","color":"dark_gray"}]

execute unless entity @s[scores={juix_recipes_tellraw_id=1..}] run scoreboard players set @s juix_recipes_tellraw_id 2