#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#   NETHERITE ADVANCEMENT INIT
execute as @a[tag=!xrs_init_player] run function xrs_data:init_player

#   SNEAK BYPASS
execute as @a run tag @s remove xrs_is_sneaking_bypass
execute as @a[scores={xrs_player_sneaking=1..}] if score world juix_option_sneak_bypass matches 1.. run tag @s add xrs_is_sneaking_bypass

#   EXCAVATORS (Optimized Detection)
execute as @a[tag=!xrs_holding_excavator] if predicate xrs_data:holds_excavator run tag @s add xrs_holding_excavator
execute as @a[tag=xrs_holding_excavator] unless predicate xrs_data:holds_excavator run tag @s remove xrs_holding_excavator

execute as @a[tag=xrs_holding_excavator,tag=!xrs_is_sneaking_bypass] run function xrs_data:mined_blocks

execute as @a[scores={xrs_mined_blocks=1..},tag=xrs_holding_excavator,tag=!xrs_is_sneaking_bypass] at @s run function xrs_data:vanilla_excavators
scoreboard players reset @a[scores={xrs_mined_blocks=1..}] xrs_mined_blocks

execute as @a[scores={xrs_use_iron_shovel=1..}] run scoreboard players reset @s xrs_use_iron_shovel
execute as @a[scores={xrs_use_golden_shovel=1..}] run scoreboard players reset @s xrs_use_golden_shovel
execute as @a[scores={xrs_use_diamond_shovel=1..}] run scoreboard players reset @s xrs_use_diamond_shovel
execute as @a[scores={xrs_use_netherite_shovel=1..}] run scoreboard players reset @s xrs_use_netherite_shovel

scoreboard players reset @a xrs_player_sneaking

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=xrs_smithing] run execute if items entity @s container.* minecraft:netherite_shovel[minecraft:custom_model_data={floats:[100]},minecraft:item_name={"text":"Diamond Excavator","italic":false}] run function xrs_data:netherite_tool_name_replace
