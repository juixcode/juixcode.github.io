recipe take @s minecraft:netherite_shovel_smithing
tag @s add xrs_init_player