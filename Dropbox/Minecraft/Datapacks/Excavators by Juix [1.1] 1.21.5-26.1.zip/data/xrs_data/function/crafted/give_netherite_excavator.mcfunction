recipe take @s minecraft:netherite_shovel_smithing
advancement revoke @s only xrs_data:netherite_excavator_adv

execute as @s store result score @s xrs_smithing_test run clear @s minecraft:netherite_shovel[minecraft:custom_model_data={floats:[100]},minecraft:item_name={"text":"Diamond Excavator","italic":false}] 0
execute as @s[scores={xrs_smithing_test=1..}] run tag @s add xrs_smithing