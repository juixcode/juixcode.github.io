scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#
#	DEFAULT
#

scoreboard objectives add xrs_mined_blocks dummy
scoreboard objectives add xrs_use_iron_shovel minecraft.used:minecraft.iron_shovel
scoreboard objectives add xrs_use_golden_shovel minecraft.used:minecraft.golden_shovel
scoreboard objectives add xrs_use_netherite_shovel minecraft.used:minecraft.netherite_shovel
scoreboard objectives add xrs_use_diamond_shovel minecraft.used:minecraft.diamond_shovel
scoreboard objectives add xrs_smithing_test dummy

scoreboard objectives add xrs_option_size dummy
scoreboard players set world xrs_option_size 1

scoreboard objectives add xrs_option_depth dummy
scoreboard players set world xrs_option_depth 1

scoreboard objectives add juix_option_sneak_bypass dummy
execute unless score world juix_option_sneak_bypass matches 0.. run scoreboard players set world juix_option_sneak_bypass 0

scoreboard objectives add xrs_player_sneaking minecraft.custom:minecraft.sneak_time

scoreboard players set world excavators_installation_test 1
tellraw @a {"text":"Excavators Installed","color":"green"}