# Vérifie si Excavators est installé, puis ajoute son tag à l'URL
execute if score world excavators_installation_test matches 1.. run function xrs_data:recipes/concat_url_tag with storage juix:recipes
