# Initialise le minage avec profondeur variable
scoreboard players operation #depth xrs_option_depth = world xrs_option_depth
$function xrs_data:mine/process {dx:$(dx), dy:$(dy), dz:$(dz), plane:"$(plane)"}
