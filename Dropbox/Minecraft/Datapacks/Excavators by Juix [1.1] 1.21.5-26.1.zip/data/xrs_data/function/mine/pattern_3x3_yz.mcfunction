execute positioned ~ ~-1 ~-1 run function xrs_data:mine/block
execute positioned ~ ~-1 ~ run function xrs_data:mine/block
execute positioned ~ ~-1 ~1 run function xrs_data:mine/block
execute positioned ~ ~ ~-1 run function xrs_data:mine/block
execute positioned ~ ~ ~1 run function xrs_data:mine/block
execute positioned ~ ~1 ~-1 run function xrs_data:mine/block
execute positioned ~ ~1 ~ run function xrs_data:mine/block
execute positioned ~ ~1 ~1 run function xrs_data:mine/block
