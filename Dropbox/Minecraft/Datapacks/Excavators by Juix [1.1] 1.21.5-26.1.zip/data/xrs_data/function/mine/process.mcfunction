# Creuse le plan actuel
$function xrs_data:mine/plane_$(plane)

# Boucle pour la profondeur (Depth)
scoreboard players remove #depth xrs_option_depth 1
$execute if score #depth xrs_option_depth matches 1.. positioned ~$(dx) ~$(dy) ~$(dz) run function xrs_data:mine/process {dx:$(dx), dy:$(dy), dz:$(dz), plane:"$(plane)"}
