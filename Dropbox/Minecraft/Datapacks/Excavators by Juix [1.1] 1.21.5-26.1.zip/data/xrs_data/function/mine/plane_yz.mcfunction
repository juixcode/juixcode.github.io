function xrs_data:mine/block
execute if score world xrs_option_size matches 1.. run function xrs_data:mine/pattern_3x3_yz
execute if score world xrs_option_size matches 2.. run function xrs_data:mine/pattern_5x5_yz
