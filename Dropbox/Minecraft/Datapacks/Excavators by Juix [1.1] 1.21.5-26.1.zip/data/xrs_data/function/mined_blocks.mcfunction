execute as @s[scores={xrs_use_iron_shovel=1..}] run scoreboard players add @s xrs_mined_blocks 1
execute as @s[scores={xrs_use_golden_shovel=1..}] run scoreboard players add @s xrs_mined_blocks 1
execute as @s[scores={xrs_use_diamond_shovel=1..}] run scoreboard players add @s xrs_mined_blocks 1
execute as @s[scores={xrs_use_netherite_shovel=1..}] run scoreboard players add @s xrs_mined_blocks 1