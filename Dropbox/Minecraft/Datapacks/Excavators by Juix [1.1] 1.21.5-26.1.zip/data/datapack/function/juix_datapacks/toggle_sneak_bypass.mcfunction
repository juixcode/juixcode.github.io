scoreboard players add world juix_option_sneak_bypass 1
execute if score world juix_option_sneak_bypass matches 2.. run scoreboard players set world juix_option_sneak_bypass 0

execute if score world juix_option_sneak_bypass matches 0 run tellraw @s {"text":"Sneak bypass : Disabled","color":"red"}
execute if score world juix_option_sneak_bypass matches 1 run tellraw @s {"text":"Sneak bypass : Enabled (Sneaking disables special tool effects)","color":"green"}