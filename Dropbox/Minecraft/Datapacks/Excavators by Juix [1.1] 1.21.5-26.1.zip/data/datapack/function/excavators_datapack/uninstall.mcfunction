
scoreboard objectives remove xrs_mined_blocks
scoreboard objectives remove xrs_use_iron_shovel
scoreboard objectives remove xrs_use_golden_shovel
scoreboard objectives remove xrs_use_diamond_shovel
scoreboard objectives remove xrs_use_netherite_shovel
scoreboard objectives remove xrs_smithing_test

scoreboard objectives remove excavators_installation_test

tellraw @a {"text":"Uninstalled Excavators","color":"red"}
datapack disable "file/Excavators by Juix [1.1] 1.21.5-26.1"
datapack disable "file/Excavators by Juix [1.1] 1.21.5-26.1.zip"