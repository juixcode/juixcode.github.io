scoreboard players add world xrs_option_depth 1

execute if score world xrs_option_depth matches 4.. run scoreboard players add world xrs_option_size 1
execute if score world xrs_option_depth matches 4.. run scoreboard players set world xrs_option_depth 1

execute if score world xrs_option_size matches 3.. run scoreboard players set world xrs_option_size 1

execute if score world xrs_option_size matches 1 if score world xrs_option_depth matches 1 run tellraw @s ["",{"text":"Mining size : ","color":"gray"},{"text":"3x3","color":"green"},{"text":" \u2502 Mining depth : ","color":"gray"},{"text":"x1","color":"green"}]
execute if score world xrs_option_size matches 1 if score world xrs_option_depth matches 2 run tellraw @s ["",{"text":"Mining size : ","color":"gray"},{"text":"3x3","color":"green"},{"text":" \u2502 Mining depth : ","color":"gray"},{"text":"x2","color":"green"}]
execute if score world xrs_option_size matches 1 if score world xrs_option_depth matches 3 run tellraw @s ["",{"text":"Mining size : ","color":"gray"},{"text":"3x3","color":"green"},{"text":" \u2502 Mining depth : ","color":"gray"},{"text":"x3","color":"green"}]
execute if score world xrs_option_size matches 2 if score world xrs_option_depth matches 1 run tellraw @s ["",{"text":"Mining size : ","color":"gray"},{"text":"5x5","color":"green"},{"text":" \u2502 Mining depth : ","color":"gray"},{"text":"x1","color":"green"}]
execute if score world xrs_option_size matches 2 if score world xrs_option_depth matches 2 run tellraw @s ["",{"text":"Mining size : ","color":"gray"},{"text":"5x5","color":"green"},{"text":" \u2502 Mining depth : ","color":"gray"},{"text":"x2","color":"green"}]
execute if score world xrs_option_size matches 2 if score world xrs_option_depth matches 3 run tellraw @s ["",{"text":"Mining size : ","color":"gray"},{"text":"5x5","color":"green"},{"text":" \u2502 Mining depth : ","color":"gray"},{"text":"x3","color":"green"}]