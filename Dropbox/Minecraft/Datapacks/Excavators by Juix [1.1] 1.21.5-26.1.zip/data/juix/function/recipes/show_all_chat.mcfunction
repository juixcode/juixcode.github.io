# Coordinateur : affiche TOUTES les recettes chat + le lien browser
function #juix:show_chat_recipes
function juix:recipes/show_browser
