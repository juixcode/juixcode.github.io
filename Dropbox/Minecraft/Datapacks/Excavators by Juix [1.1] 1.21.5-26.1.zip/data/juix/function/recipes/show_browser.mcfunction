# Coordinateur : construit l'URL dynamique et l'envoie au joueur
data modify storage juix:recipes url set value "https://juixcode.github.io/recipes/#"
function #juix:build_recipe_url
function juix:recipes/send_url with storage juix:recipes
