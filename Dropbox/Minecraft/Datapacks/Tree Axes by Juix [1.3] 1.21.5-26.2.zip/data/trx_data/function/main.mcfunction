#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#   NETHERITE ADVANCEMENT INIT
execute as @a[tag=!trx_init_player] run function trx_data:init_player

#   SNEAK BYPASS
execute as @a run tag @s remove trx_is_sneaking_bypass
execute as @a[scores={trx_player_sneaking=1..}] if score world juix_option_sneak_bypass matches 1.. run tag @s add trx_is_sneaking_bypass

#   TREE AXES
execute as @a[tag=!trx_holding_tree_axe] if predicate trx_data:holds_axe run tag @s add trx_holding_tree_axe
execute as @a[tag=trx_holding_tree_axe] unless predicate trx_data:holds_axe run tag @s remove trx_holding_tree_axe

execute as @a[tag=trx_holding_tree_axe,tag=!trx_is_sneaking_bypass] run function trx_data:mined_blocks

execute as @a[scores={trx_mined_blocks=1..},tag=trx_holding_tree_axe,tag=!trx_is_sneaking_bypass] at @s anchored eyes positioned ^ ^ ^1.5 at @n[type=item,nbt={Age:0s},distance=..5.0] run function trx_data:set_initial_position
scoreboard players reset @a[scores={trx_mined_blocks=1..}] trx_mined_blocks

execute as @a[scores={trx_use_iron_axe=1..}] run scoreboard players reset @s trx_use_iron_axe
execute as @a[scores={trx_use_golden_axe=1..}] run scoreboard players reset @s trx_use_golden_axe
execute as @a[scores={trx_use_diamond_axe=1..}] run scoreboard players reset @s trx_use_diamond_axe
execute as @a[scores={trx_use_netherite_axe=1..}] run scoreboard players reset @s trx_use_netherite_axe

scoreboard players reset @a trx_player_sneaking

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=trx_smithing] if items entity @s container.* minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run function trx_data:netherite_tool_name_replace