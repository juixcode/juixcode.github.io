advancement revoke @s only trx_data:netherite_tree_axe_adv

execute as @s store result score @s trx_smithing_test run clear @s minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] 0
execute as @s[scores={trx_smithing_test=1..}] run tag @s add trx_smithing
execute as @s[tag=trx_smithing] run function trx_data:netherite_tool_name_replace