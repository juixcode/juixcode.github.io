execute if items entity @s hotbar.0 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.0 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.1 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.1 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.2 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.2 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.3 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.3 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.4 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.4 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.5 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.5 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.6 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.6 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.7 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.7 trx_data:netherite_axe_modifier
execute if items entity @s hotbar.8 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s hotbar.8 trx_data:netherite_axe_modifier

execute if items entity @s inventory.0 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.0 trx_data:netherite_axe_modifier
execute if items entity @s inventory.1 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.1 trx_data:netherite_axe_modifier
execute if items entity @s inventory.2 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.2 trx_data:netherite_axe_modifier
execute if items entity @s inventory.3 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.3 trx_data:netherite_axe_modifier
execute if items entity @s inventory.4 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.4 trx_data:netherite_axe_modifier
execute if items entity @s inventory.5 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.5 trx_data:netherite_axe_modifier
execute if items entity @s inventory.6 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.6 trx_data:netherite_axe_modifier
execute if items entity @s inventory.7 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.7 trx_data:netherite_axe_modifier
execute if items entity @s inventory.8 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.8 trx_data:netherite_axe_modifier

execute if items entity @s inventory.9 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.9 trx_data:netherite_axe_modifier
execute if items entity @s inventory.10 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.10 trx_data:netherite_axe_modifier
execute if items entity @s inventory.11 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.11 trx_data:netherite_axe_modifier
execute if items entity @s inventory.12 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.12 trx_data:netherite_axe_modifier
execute if items entity @s inventory.13 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.13 trx_data:netherite_axe_modifier
execute if items entity @s inventory.14 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.14 trx_data:netherite_axe_modifier
execute if items entity @s inventory.15 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.15 trx_data:netherite_axe_modifier
execute if items entity @s inventory.16 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.16 trx_data:netherite_axe_modifier
execute if items entity @s inventory.17 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.17 trx_data:netherite_axe_modifier

execute if items entity @s inventory.18 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.18 trx_data:netherite_axe_modifier
execute if items entity @s inventory.19 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.19 trx_data:netherite_axe_modifier
execute if items entity @s inventory.20 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.20 trx_data:netherite_axe_modifier
execute if items entity @s inventory.21 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.21 trx_data:netherite_axe_modifier
execute if items entity @s inventory.22 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.22 trx_data:netherite_axe_modifier
execute if items entity @s inventory.23 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.23 trx_data:netherite_axe_modifier
execute if items entity @s inventory.24 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.24 trx_data:netherite_axe_modifier
execute if items entity @s inventory.25 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.25 trx_data:netherite_axe_modifier
execute if items entity @s inventory.26 minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s inventory.26 trx_data:netherite_axe_modifier

execute if items entity @s weapon.offhand minecraft:netherite_axe[minecraft:custom_data~{trx_diamond_tree_axe:true}] run item modify entity @s weapon.offhand trx_data:netherite_axe_modifier

tag @s remove trx_smithing