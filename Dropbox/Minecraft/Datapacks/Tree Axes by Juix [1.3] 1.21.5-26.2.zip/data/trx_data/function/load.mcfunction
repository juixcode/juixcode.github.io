
#
#	DEFAULT
#

scoreboard objectives add tree_axes_installation_test dummy
execute if score world tree_axes_installation_test matches 2.. run tellraw @a {"text":"Tree Axes Reloaded","color":"green"}
execute unless score world tree_axes_installation_test matches 2.. run function trx_data:setup

#   RECIPES WARNING

execute unless data storage juix:warning {loaded:true} run schedule function juix:warning 1t replace
data modify storage juix:warning loaded set value true