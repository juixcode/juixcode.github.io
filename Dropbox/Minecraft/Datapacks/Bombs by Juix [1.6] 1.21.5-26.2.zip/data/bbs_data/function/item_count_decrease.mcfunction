# Stocker le nombre d’items tenus en main
execute store result score @s bbs_itemCount run data get entity @s SelectedItem.count

# Soustraire 1
scoreboard players remove @s bbs_itemCount 1

# Si le stack est encore ≥ 1, modifier sa quantité directement en place
execute if score @s bbs_itemCount matches 1.. run item modify entity @s weapon.mainhand bbs_data:decrease_count

# Sinon, si le stack tombe à 0, vider la main
execute unless score @s bbs_itemCount matches 1.. run item replace entity @s weapon.mainhand with air