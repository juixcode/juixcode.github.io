#
#	DEFAULT
#

scoreboard objectives add bombs_installation_test dummy
execute if score world bombs_installation_test matches 2.. run tellraw @a {"text":"Bombs Reloaded","color":"green"}
execute unless score world bombs_installation_test matches 2.. run function bbs_data:setup

#   RECIPES WARNING

execute unless data storage juix:warning {loaded:true} run schedule function juix:warning 1t replace
data modify storage juix:warning loaded set value true