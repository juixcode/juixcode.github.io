#
# UNINSTALL - Fast Eating
# Supprime tous les scoreboards, advancements, forceload, et désactive le datapack
#

# Supprimer les objectifs de scoreboard
scoreboard objectives remove fse_option_eating_time
scoreboard objectives remove fse_tick_counter
scoreboard objectives remove fast_eating_installation_test

# Révoquer les advancements de tous les joueurs
advancement revoke @a only fse_data:open_container
advancement revoke @a only fse_data:inventory_changed

# Message de confirmation
tellraw @a {"text":"Uninstalled Fast Eating","color":"red"}

# Désactiver le datapack
datapack disable "file/Fast Eating [1.1b] 1.21.2-26.2"
datapack disable "file/Fast Eating [1.1b] 1.21.2-26.2.zip"