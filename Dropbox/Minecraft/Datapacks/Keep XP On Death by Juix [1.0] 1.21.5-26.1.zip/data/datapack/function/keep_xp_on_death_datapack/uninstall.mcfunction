
#
#	DATAPACK
#

scoreboard objectives remove kxp_gamerule_keep_xp
scoreboard objectives remove keepXP_installation_test
scoreboard objectives remove kxp_death
scoreboard objectives remove kxp_xp
scoreboard objectives remove kxp_xp_backup
scoreboard objectives remove kxp_xp_backup_temp
scoreboard objectives remove kxp_id
scoreboard objectives remove kxp_constants
scoreboard objectives remove kxp_keep_inventory_test
scoreboard objectives remove kxp_time_since_death
scoreboard objectives remove kxp_has_marker_loaded
scoreboard objectives remove kxp_config_milestone
scoreboard objectives remove kxp_config_percentage
scoreboard objectives remove kxp_config_fixed
scoreboard objectives remove kxp_level_backup
scoreboard objectives remove kxp_points_backup
scoreboard objectives remove kxp_config_drop_mode

kill @e[type=marker,tag=kxp_marker]

data remove storage kxp:milestones step_3
data remove storage kxp:milestones step_5
data remove storage kxp:milestones step_10
data remove storage kxp:temp xp_amount
data remove storage kxp:temp display_val
data remove storage kxp:temp milestone_list
data remove storage kxp:temp levels_to_remove
data remove storage kxp:temp target_levels
data remove storage kxp:temp target_points

tellraw @a {"text":"Uninstalled KeepXP After Death","color":"red"}
datapack disable "file/Keep XP On Death by Juix [1.0] 1.21.5-26.1"
datapack disable "file/Keep XP On Death by Juix [1.0] 1.21.5-26.1.zip"