scoreboard players add world tps_option_teleportation_cooldown 1
execute if score world tps_option_teleportation_cooldown matches 4.. run scoreboard players set world tps_option_teleportation_cooldown 0

execute if score world tps_option_teleportation_cooldown matches 0 run tellraw @s {"text":"Teleportation delay : 0s (Instant)","color":"green"}
execute if score world tps_option_teleportation_cooldown matches 1 run tellraw @s {"text":"Teleportation delay : 1.5s","color":"green"}
execute if score world tps_option_teleportation_cooldown matches 2 run tellraw @s {"text":"Teleportation delay : 3s","color":"green"}
execute if score world tps_option_teleportation_cooldown matches 3 run tellraw @s {"text":"Teleportation delay : 5s","color":"green"}