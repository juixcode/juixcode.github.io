#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#
#   TELEPORTER PLACING
#

execute as @a if items entity @s weapon.offhand minecraft:armor_stand[custom_model_data={floats:[111]}] run execute store result score @s item_tp_link run data get entity @s equipment.offhand.components."minecraft:custom_data".item_tp_link_score
execute as @a if items entity @s weapon.mainhand minecraft:armor_stand[custom_model_data={floats:[111]}] run execute store result score @s item_tp_link run data get entity @s SelectedItem.components."minecraft:custom_data".item_tp_link_score

execute as @a if items entity @s weapon.offhand minecraft:armor_stand[custom_model_data={floats:[111]}] run execute store result score @s tps_color_id run data get entity @s equipment.offhand.components."minecraft:custom_data".tps_color_id
execute as @a if items entity @s weapon.mainhand minecraft:armor_stand[custom_model_data={floats:[111]}] run execute store result score @s tps_color_id run data get entity @s SelectedItem.components."minecraft:custom_data".tps_color_id
execute as @e[type=armor_stand,tag=tps_teleporter,tag=!updated] at @s run function tps_data:tp_place

#
#   TELEPORTER USING
#

execute as @e[tag=tps_teleporter,tag=active] at @s positioned ~ ~-1.8 ~ run tag @a[distance=..1] add tps_in_portal
execute as @a[tag=tps_in_portal] run scoreboard players add @s item_tp_cooldown 1

execute if score world tps_option_include_villagers matches 1 as @e[tag=tps_teleporter,tag=active] at @s positioned ~ ~-1.8 ~ run tag @e[type=villager,distance=..1] add tps_in_portal
execute as @e[type=villager,tag=tps_in_portal] run scoreboard players add @s item_tp_cooldown 1

execute if score world tps_option_teleportation_cooldown matches 0 run title @a[scores={item_tp_cooldown=1}] actionbar {"text":"Teleporting...","color":"white"}
execute if score world tps_option_teleportation_cooldown matches 1 run title @a[scores={item_tp_cooldown=1}] actionbar {"text":"Teleporting in 1.5s...","color":"white"}
execute if score world tps_option_teleportation_cooldown matches 2 run title @a[scores={item_tp_cooldown=1}] actionbar {"text":"Teleporting in 3s...","color":"white"}
execute if score world tps_option_teleportation_cooldown matches 3 run title @a[scores={item_tp_cooldown=1}] actionbar {"text":"Teleporting in 5s...","color":"white"}
execute at @a[scores={item_tp_cooldown=1}] run playsound minecraft:block.note_block.chime neutral @a ~ ~ ~ 1 1

execute if score world tps_option_teleportation_cooldown matches 0 as @e[scores={item_tp_cooldown=3}] at @s run function tps_data:tp_use
execute if score world tps_option_teleportation_cooldown matches 1 as @e[scores={item_tp_cooldown=30}] at @s run function tps_data:tp_use
execute if score world tps_option_teleportation_cooldown matches 2 as @e[scores={item_tp_cooldown=60}] at @s run function tps_data:tp_use
execute if score world tps_option_teleportation_cooldown matches 3 as @e[scores={item_tp_cooldown=100}] at @s run function tps_data:tp_use

execute as @a[scores={item_tp_cooldown=1..},tag=!tps_in_portal] run scoreboard players reset @s item_tp_cooldown
execute as @e[type=villager,scores={item_tp_cooldown=1..},tag=!tps_in_portal] run scoreboard players reset @s item_tp_cooldown

tag @e[tag=tps_in_portal] remove tps_in_portal

#   TELEPORTER INTERACTION
execute as @e[type=interaction,tag=tps_teleporter_click] if data entity @s attack at @s run function tps_data:events/left_click
execute as @e[type=interaction,tag=tps_teleporter_click] if data entity @s interaction at @s run function tps_data:events/right_click

scoreboard players remove @a[scores={tps_left_click_cooldown=1..}] tps_left_click_cooldown 1
scoreboard players remove @a[scores={tps_right_click_cooldown=1..}] tps_right_click_cooldown 1

#
#   GLOBAL
#

#   DISPLAY
execute if score world tps_option_particles_generating matches 1 run execute at @e[tag=tps_teleporter,tag=active] run particle minecraft:enchant ~ ~-1 ~ 0.1 0.5 0.1 0.2 3 normal
execute if score world tps_option_particles_generating matches 1 run execute at @e[tag=tps_teleporter] run particle minecraft:dust{color:[0.000,1.000,0.6000],scale:1} ~ ~-1 ~ 0.2 0.5 0.2 2 1 normal

scoreboard players reset @a[scores={tps_placing=1..}] tps_placing