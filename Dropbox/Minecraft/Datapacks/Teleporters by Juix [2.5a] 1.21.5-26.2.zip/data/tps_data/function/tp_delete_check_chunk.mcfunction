#
#   TP DELETE CHECK CHUNK (MACRO)
#

$execute positioned $(chunk_x) -64 $(chunk_z) unless entity @e[tag=tps_teleporter,dx=15,dy=383,dz=15] run forceload remove ~ ~
