# Stocker le nombre d’items tenus en main
execute store result score @s tps_itemCount run data get entity @s SelectedItem.count

# Soustraire 1
scoreboard players remove @s tps_itemCount 1

# Si le stack est encore ≥ 1, modifier sa quantité via un stockage temporaire et le remettre en main
execute if score @s tps_itemCount matches 1.. run item modify entity @s weapon.mainhand tps_data:decrease_count

# Sinon, si le stack tombe à 0, vider la main
execute unless score @s tps_itemCount matches 1.. run item replace entity @s weapon.mainhand with air