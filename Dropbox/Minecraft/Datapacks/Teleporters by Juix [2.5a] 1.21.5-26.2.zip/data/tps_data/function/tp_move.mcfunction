#
#   TP MOVE
#

title @s actionbar {"text":"Teleporter (Point #2) acquired","color":"green"}
execute at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,limit=1,sort=nearest] run playsound minecraft:block.beacon.deactivate neutral @a ~ ~ ~ 0.5 2

#   STORE DATA FOR THE 2ND POINT
execute store result storage tps_data:data item_tp_link_score int 1 run execute at @s positioned ~ ~1.8 ~ run scoreboard players get @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,sort=nearest,limit=1] item_tp_link

#   GIVE ITEM BACK
data remove storage tps_data:data current_name
data modify storage tps_data:data current_name set from entity @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,limit=1,sort=nearest] CustomName
function tps_data:name/extract_text with storage tps_data:data
execute as @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,limit=1,sort=nearest] run scoreboard players operation #temp tps_color_id = @s tps_color_id
execute unless score #temp tps_color_id matches 1..14 run scoreboard players set #temp tps_color_id 8

execute store result storage tps_data:data tps_color_id int 1 run scoreboard players get #temp tps_color_id

data remove storage tps_data:data tps_color
execute if score #temp tps_color_id matches 1 run data modify storage tps_data:data tps_color set value "white"
execute if score #temp tps_color_id matches 2 run data modify storage tps_data:data tps_color set value "gray"
execute if score #temp tps_color_id matches 3 run data modify storage tps_data:data tps_color set value "dark_gray"
execute if score #temp tps_color_id matches 4 run data modify storage tps_data:data tps_color set value "black"
execute if score #temp tps_color_id matches 5 run data modify storage tps_data:data tps_color set value "red"
execute if score #temp tps_color_id matches 6 run data modify storage tps_data:data tps_color set value "gold"
execute if score #temp tps_color_id matches 7 run data modify storage tps_data:data tps_color set value "yellow"
execute if score #temp tps_color_id matches 8 run data modify storage tps_data:data tps_color set value "green"
execute if score #temp tps_color_id matches 9 run data modify storage tps_data:data tps_color set value "dark_green"
execute if score #temp tps_color_id matches 10 run data modify storage tps_data:data tps_color set value "dark_aqua"
execute if score #temp tps_color_id matches 11 run data modify storage tps_data:data tps_color set value "aqua"
execute if score #temp tps_color_id matches 12 run data modify storage tps_data:data tps_color set value "blue"
execute if score #temp tps_color_id matches 13 run data modify storage tps_data:data tps_color set value "dark_purple"
execute if score #temp tps_color_id matches 14 run data modify storage tps_data:data tps_color set value "light_purple"

execute if items entity @s weapon.mainhand * at @s run function tps_data:item/summon_teleporter_point2_renamed with storage tps_data:data
execute unless items entity @s weapon.mainhand * at @s run function tps_data:item/give_teleporter_point2_renamed with storage tps_data:data

#   UPDATE THE FIRST POINT (DISABLE & SET NAME COLOR TO RED)
execute at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,tag=!tps_teleporter_acquisition,limit=1,sort=nearest] if score @s item_tp_link = @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,sort=nearest,limit=1] item_tp_link run tag @s remove active
execute at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,tag=!tps_teleporter_acquisition,limit=1,sort=nearest] if score @s item_tp_link = @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,sort=nearest,limit=1] item_tp_link run data remove storage tps_data:data current_name
execute at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,tag=!tps_teleporter_acquisition,limit=1,sort=nearest] if score @s item_tp_link = @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,sort=nearest,limit=1] item_tp_link run data modify storage tps_data:data current_name set from entity @s CustomName
execute at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,tag=!tps_teleporter_acquisition,limit=1,sort=nearest] if score @s item_tp_link = @e[tag=tps_teleporter,tag=tps_teleporter_acquisition,sort=nearest,limit=1] item_tp_link run function tps_data:name/update_color with storage tps_data:data

#   DELETE THE 2nd POINT
execute as @e[tag=tps_teleporter,tag=tps_teleporter_acquisition] at @s positioned ~ ~ ~ run function tps_data:tp_delete

scoreboard players set @s tps_right_click_cooldown 0