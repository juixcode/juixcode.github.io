#
#   TP DELETE
#

# Store chunk coordinates before killing the entity
execute at @s align xz run summon marker ~ ~ ~ {Tags:["tps_temp_marker"]}
execute store result score #x tps_infinite_value run data get entity @e[tag=tps_temp_marker,limit=1] Pos[0]
execute store result score #z tps_infinite_value run data get entity @e[tag=tps_temp_marker,limit=1] Pos[2]
kill @e[tag=tps_temp_marker]

scoreboard players set #c16 tps_infinite_value 16

scoreboard players operation #x_mod tps_infinite_value = #x tps_infinite_value
scoreboard players operation #x_mod tps_infinite_value %= #c16 tps_infinite_value
execute if score #x_mod tps_infinite_value matches ..-1 run scoreboard players add #x_mod tps_infinite_value 16
scoreboard players operation #x tps_infinite_value -= #x_mod tps_infinite_value

scoreboard players operation #z_mod tps_infinite_value = #z tps_infinite_value
scoreboard players operation #z_mod tps_infinite_value %= #c16 tps_infinite_value
execute if score #z_mod tps_infinite_value matches ..-1 run scoreboard players add #z_mod tps_infinite_value 16
scoreboard players operation #z tps_infinite_value -= #z_mod tps_infinite_value

execute store result storage tps_data:data chunk_x int 1 run scoreboard players get #x tps_infinite_value
execute store result storage tps_data:data chunk_z int 1 run scoreboard players get #z tps_infinite_value

# Deletion
playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1 1

execute at @s positioned ~ ~-1.8 ~ run kill @e[tag=tps_teleporter_click,sort=nearest,limit=1]
kill @s
execute at @s positioned ~-0.4 ~-2.2 ~-0.4 run kill @e[tag=tps_block_display,sort=nearest,limit=1]
function tps_data:tp_delete_check_chunk with storage tps_data:data