scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#
#   MIGRATION
#

#   v1.4 : Introducing the renaming feature
execute if score world teleporters_installation_test matches 1..2 run tag @e[type=armor_stand,tag=tps_teleporter,name=Linked] add active
#   v2.0 : Introducing double right & left clicks
execute if score world teleporters_installation_test matches 1..3 run function tps_data:version_migration/pnj_to_interaction
#   v2.3 : Migrating teleporters_data entity to a fake player
execute if score world teleporters_installation_test matches 1..4 as @e[type=armor_stand,tag=teleporters_data,limit=1] run scoreboard players operation #teleporters_data tps_infinite_value = @s tps_infinite_value
execute if score world teleporters_installation_test matches 1..4 run kill @e[type=armor_stand,tag=teleporters_data]

scoreboard objectives add tps_itemCount dummy

#
#	DEFAULT
#

scoreboard objectives add tps_left_click_cooldown dummy
scoreboard objectives add tps_right_click_cooldown dummy

scoreboard objectives add tps_placing minecraft.used:minecraft.armor_stand
scoreboard objectives add tps_infinite_value dummy

scoreboard objectives add item_tp_cooldown dummy
scoreboard objectives add item_tp_test dummy
scoreboard objectives add item_tp_link dummy

scoreboard objectives add tps_option_include_villagers dummy
scoreboard players set world tps_option_include_villagers 0

scoreboard objectives add tps_option_floating_names_visibility dummy
scoreboard players set world tps_option_floating_names_visibility 1

scoreboard objectives add tps_option_particles_generating dummy
scoreboard players set world tps_option_particles_generating 1

scoreboard objectives add tps_option_teleportation_cooldown dummy
scoreboard players set world tps_option_teleportation_cooldown 1

scoreboard objectives add tps_color_id dummy

scoreboard players set world teleporters_installation_test 6
tellraw @a {"text":"Teleporters Installed","color":"green"}