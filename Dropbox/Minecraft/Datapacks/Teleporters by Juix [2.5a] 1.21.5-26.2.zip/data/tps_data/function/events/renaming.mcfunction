#   TP RENAMING
execute as @e[tag=tps_teleporter_click,tag=right_clicked,sort=nearest,limit=1,distance=..8] at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,sort=nearest,limit=1,distance=..8] run tag @s add event_renamed

#   Remplacement direct du nom par le nom de l'item
data remove storage tps_data:data extracted_name
data modify storage tps_data:data extracted_name set from entity @s SelectedItem.components."minecraft:custom_name"
execute as @e[tag=tps_teleporter,tag=event_renamed,sort=nearest,limit=1] run scoreboard players operation #temp tps_color_id = @s tps_color_id
execute unless score #temp tps_color_id matches 1..14 run scoreboard players set #temp tps_color_id 8

data remove storage tps_data:data tps_color

execute if score #temp tps_color_id matches 1 run data modify storage tps_data:data tps_color set value "white"
execute if score #temp tps_color_id matches 2 run data modify storage tps_data:data tps_color set value "gray"
execute if score #temp tps_color_id matches 3 run data modify storage tps_data:data tps_color set value "dark_gray"
execute if score #temp tps_color_id matches 4 run data modify storage tps_data:data tps_color set value "black"
execute if score #temp tps_color_id matches 5 run data modify storage tps_data:data tps_color set value "red"
execute if score #temp tps_color_id matches 6 run data modify storage tps_data:data tps_color set value "gold"
execute if score #temp tps_color_id matches 7 run data modify storage tps_data:data tps_color set value "yellow"
execute if score #temp tps_color_id matches 8 run data modify storage tps_data:data tps_color set value "green"
execute if score #temp tps_color_id matches 9 run data modify storage tps_data:data tps_color set value "dark_green"
execute if score #temp tps_color_id matches 10 run data modify storage tps_data:data tps_color set value "dark_aqua"
execute if score #temp tps_color_id matches 11 run data modify storage tps_data:data tps_color set value "aqua"
execute if score #temp tps_color_id matches 12 run data modify storage tps_data:data tps_color set value "blue"
execute if score #temp tps_color_id matches 13 run data modify storage tps_data:data tps_color set value "dark_purple"
execute if score #temp tps_color_id matches 14 run data modify storage tps_data:data tps_color set value "light_purple"

execute as @e[tag=tps_teleporter,tag=event_renamed,sort=nearest,limit=1] run function tps_data:name/apply_color with storage tps_data:data

tag @e[tag=tps_teleporter,tag=event_renamed] remove event_renamed
execute as @s[gamemode=!creative] run function tps_data:item_count_decrease