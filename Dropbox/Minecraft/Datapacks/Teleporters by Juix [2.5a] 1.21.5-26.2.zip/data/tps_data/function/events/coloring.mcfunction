#   TP COLORING
execute as @e[tag=tps_teleporter_click,tag=right_clicked,sort=nearest,limit=1,distance=..8] at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,sort=nearest,limit=1,distance=..8] run tag @s add event_colored

#   Check dye and set color ID in storage & scoreboard
data remove storage tps_data:data dye_color
execute if items entity @s weapon.mainhand minecraft:white_dye run data modify storage tps_data:data dye_color set value "white"
execute if items entity @s weapon.mainhand minecraft:white_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 1

execute if items entity @s weapon.mainhand minecraft:light_gray_dye run data modify storage tps_data:data dye_color set value "gray"
execute if items entity @s weapon.mainhand minecraft:light_gray_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 2

execute if items entity @s weapon.mainhand minecraft:gray_dye run data modify storage tps_data:data dye_color set value "dark_gray"
execute if items entity @s weapon.mainhand minecraft:gray_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 3

execute if items entity @s weapon.mainhand minecraft:black_dye run data modify storage tps_data:data dye_color set value "black"
execute if items entity @s weapon.mainhand minecraft:black_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 4

execute if items entity @s weapon.mainhand minecraft:red_dye run data modify storage tps_data:data dye_color set value "red"
execute if items entity @s weapon.mainhand minecraft:red_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 5

execute if items entity @s weapon.mainhand minecraft:orange_dye run data modify storage tps_data:data dye_color set value "gold"
execute if items entity @s weapon.mainhand minecraft:orange_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 6

execute if items entity @s weapon.mainhand minecraft:yellow_dye run data modify storage tps_data:data dye_color set value "yellow"
execute if items entity @s weapon.mainhand minecraft:yellow_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 7

execute if items entity @s weapon.mainhand minecraft:lime_dye run data modify storage tps_data:data dye_color set value "green"
execute if items entity @s weapon.mainhand minecraft:lime_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 8

execute if items entity @s weapon.mainhand minecraft:green_dye run data modify storage tps_data:data dye_color set value "dark_green"
execute if items entity @s weapon.mainhand minecraft:green_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 9

execute if items entity @s weapon.mainhand minecraft:cyan_dye run data modify storage tps_data:data dye_color set value "dark_aqua"
execute if items entity @s weapon.mainhand minecraft:cyan_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 10

execute if items entity @s weapon.mainhand minecraft:light_blue_dye run data modify storage tps_data:data dye_color set value "aqua"
execute if items entity @s weapon.mainhand minecraft:light_blue_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 11

execute if items entity @s weapon.mainhand minecraft:blue_dye run data modify storage tps_data:data dye_color set value "blue"
execute if items entity @s weapon.mainhand minecraft:blue_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 12

execute if items entity @s weapon.mainhand minecraft:purple_dye run data modify storage tps_data:data dye_color set value "dark_purple"
execute if items entity @s weapon.mainhand minecraft:purple_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 13

execute if items entity @s weapon.mainhand minecraft:magenta_dye run data modify storage tps_data:data dye_color set value "light_purple"
execute if items entity @s weapon.mainhand minecraft:magenta_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 14

execute if items entity @s weapon.mainhand minecraft:pink_dye run data modify storage tps_data:data dye_color set value "light_purple"
execute if items entity @s weapon.mainhand minecraft:pink_dye run scoreboard players set @e[tag=tps_teleporter,tag=event_colored,limit=1] tps_color_id 14

#   If the dye is compatible
execute if data storage tps_data:data dye_color as @e[tag=tps_teleporter,tag=event_colored,limit=1] run function tps_data:name/update_color
execute if data storage tps_data:data dye_color at @e[tag=tps_teleporter,tag=event_colored,limit=1] run playsound minecraft:item.dye.use master @a ~ ~ ~ 0.5 1
execute if entity @e[tag=tps_teleporter,tag=event_colored] if data storage tps_data:data dye_color as @s[gamemode=!creative] run function tps_data:item_count_decrease

#   Clean up
tag @e[tag=tps_teleporter,tag=event_colored] remove event_colored
data remove storage tps_data:data dye_color
