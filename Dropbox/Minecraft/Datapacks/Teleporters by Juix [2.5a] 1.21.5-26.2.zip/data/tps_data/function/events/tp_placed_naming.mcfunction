#   UPDATE CUSTOM NAME COLOR TO GREEN
execute unless entity @s[name='Not Linked'] run data remove storage tps_data:data current_name
execute unless entity @s[name='Not Linked'] run data modify storage tps_data:data current_name set from entity @s CustomName
execute unless entity @s[name='Not Linked'] run function tps_data:name/update_color with storage tps_data:data

#   SET GENERIC NAME
execute if entity @s[name='Not Linked'] run execute store result storage tps_data:data item_tp_link_score int 1 run scoreboard players get @s item_tp_link
execute if entity @s[name='Not Linked'] run scoreboard players operation #temp tps_color_id = @s tps_color_id
execute if entity @s[name='Not Linked'] unless score #temp tps_color_id matches 1..14 run scoreboard players set #temp tps_color_id 8

data remove storage tps_data:data tps_color
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 1 run data modify storage tps_data:data tps_color set value "white"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 2 run data modify storage tps_data:data tps_color set value "gray"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 3 run data modify storage tps_data:data tps_color set value "dark_gray"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 4 run data modify storage tps_data:data tps_color set value "black"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 5 run data modify storage tps_data:data tps_color set value "red"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 6 run data modify storage tps_data:data tps_color set value "gold"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 7 run data modify storage tps_data:data tps_color set value "yellow"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 8 run data modify storage tps_data:data tps_color set value "green"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 9 run data modify storage tps_data:data tps_color set value "dark_green"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 10 run data modify storage tps_data:data tps_color set value "dark_aqua"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 11 run data modify storage tps_data:data tps_color set value "aqua"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 12 run data modify storage tps_data:data tps_color set value "blue"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 13 run data modify storage tps_data:data tps_color set value "dark_purple"
execute if entity @s[name='Not Linked'] if score #temp tps_color_id matches 14 run data modify storage tps_data:data tps_color set value "light_purple"

execute if entity @s[name='Not Linked'] run function tps_data:name/set_tunnel with storage tps_data:data
