execute unless score @s tps_color_id matches 1..14 run scoreboard players set @s tps_color_id 8

data remove storage tps_data:data tps_color

execute if score @s tps_color_id matches 1 run data modify storage tps_data:data tps_color set value "white"
execute if score @s tps_color_id matches 2 run data modify storage tps_data:data tps_color set value "gray"
execute if score @s tps_color_id matches 3 run data modify storage tps_data:data tps_color set value "dark_gray"
execute if score @s tps_color_id matches 4 run data modify storage tps_data:data tps_color set value "black"
execute if score @s tps_color_id matches 5 run data modify storage tps_data:data tps_color set value "red"
execute if score @s tps_color_id matches 6 run data modify storage tps_data:data tps_color set value "gold"
execute if score @s tps_color_id matches 7 run data modify storage tps_data:data tps_color set value "yellow"
execute if score @s tps_color_id matches 8 run data modify storage tps_data:data tps_color set value "green"
execute if score @s tps_color_id matches 9 run data modify storage tps_data:data tps_color set value "dark_green"
execute if score @s tps_color_id matches 10 run data modify storage tps_data:data tps_color set value "dark_aqua"
execute if score @s tps_color_id matches 11 run data modify storage tps_data:data tps_color set value "aqua"
execute if score @s tps_color_id matches 12 run data modify storage tps_data:data tps_color set value "blue"
execute if score @s tps_color_id matches 13 run data modify storage tps_data:data tps_color set value "dark_purple"
execute if score @s tps_color_id matches 14 run data modify storage tps_data:data tps_color set value "light_purple"

data remove storage tps_data:data current_name
data modify storage tps_data:data current_name set from entity @s CustomName
function tps_data:name/extract_text with storage tps_data:data
function tps_data:name/apply_color with storage tps_data:data