tp @e[tag=tps_player_selected,limit=1] ~ ~-1.8 ~ ~ ~
particle minecraft:end_rod ~ ~-1 ~ 0.2 0.5 0.2 0.1 25 normal
playsound minecraft:entity.enderman.teleport neutral @a ~ ~-1.8 ~ 1 1

execute if score world tps_option_teleportation_cooldown matches 0 run scoreboard players set @e[tag=tps_player_selected,limit=1] item_tp_cooldown 4
execute if score world tps_option_teleportation_cooldown matches 1 run scoreboard players set @e[tag=tps_player_selected,limit=1] item_tp_cooldown 31
execute if score world tps_option_teleportation_cooldown matches 2 run scoreboard players set @e[tag=tps_player_selected,limit=1] item_tp_cooldown 61
execute if score world tps_option_teleportation_cooldown matches 3 run scoreboard players set @e[tag=tps_player_selected,limit=1] item_tp_cooldown 101