# Dedicated function to delete a home efficiently
tag @s add vhg_active_player
scoreboard players operation #current_action vhg_target_key = @s home_key

execute as @e[tag=home_point] if score @s home_key = #current_action vhg_target_key at @s run tag @s add delhome_point
execute as @e[tag=delhome_point] at @s run title @a[tag=vhg_active_player] actionbar {"text":"Your home has been successfully deleted","color":"red"}
execute as @e[tag=delhome_point] at @s run forceload remove ~ ~
execute as @e[tag=delhome_point] at @s run kill @s
scoreboard players reset @s home_key
tag @s remove vhg_active_player
