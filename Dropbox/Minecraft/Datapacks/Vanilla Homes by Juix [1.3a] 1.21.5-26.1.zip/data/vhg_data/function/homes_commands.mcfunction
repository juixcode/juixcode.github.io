#   /home
execute as @a[scores={home=1..,home_key=0}] run tellraw @s ["",{"text":"You don't have any home !","color":"red"},{"text":"\n"},{"text":"/trigger sethome","color":"yellow","click_event":{"action":"suggest_command","command":"/trigger sethome"}}]

execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 0 run scoreboard players set @s teleporting 0
execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 1 run scoreboard players set @s teleporting 60
execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 2 run scoreboard players set @s teleporting 100
execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 3 run scoreboard players set @s teleporting 200

execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 0 run title @s actionbar {"text":"You are back home","color":"green"}
execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 1 run title @s actionbar {"text":"You'll be back home in 3s","color":"green"}
execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 2 run title @s actionbar {"text":"You'll be back home in 5s","color":"green"}
execute as @a[scores={home=1..,home_key=1..}] if score world vhg_config_delay matches 3 run title @s actionbar {"text":"You'll be back home in 10s","color":"green"}

scoreboard players reset @a[scores={home=1..}] home

#   /delhome
execute as @a[scores={delhome=1..,home_key=0}] run tellraw @s ["",{"text":"You don't have any home !","color":"red"},{"text":"\n"},{"text":"/trigger sethome","color":"yellow","click_event":{"action":"suggest_command","command":"/trigger sethome"}}]

execute as @a[scores={delhome=1..,home_key=1..}] run function vhg_data:delhome_process

scoreboard players reset @a[scores={delhome=1..}] delhome



#   /sethome
execute as @a[scores={sethome=1,home_key=1..}] run tellraw @s ["",{"text":"You already have a home","color":"red"},{"text":"\n"},{"text":"/trigger delhome","color":"yellow","click_event":{"action":"suggest_command","command":"/trigger delhome"}}]

execute as @a[scores={sethome=1,home_key=0}] at @s run function vhg_data:sethome_process

scoreboard players reset @a[scores={sethome=1..}] sethome