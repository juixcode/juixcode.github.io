# Dedicated function to safely find and teleport to a home
tag @s add vhg_active_player
scoreboard players operation #current_action vhg_target_key = @s home_key

execute as @e[tag=home_point] if score @s home_key = #current_action vhg_target_key at @s run function vhg_data:teleporting_verified

scoreboard players reset @s teleporting
tag @s remove vhg_active_player
