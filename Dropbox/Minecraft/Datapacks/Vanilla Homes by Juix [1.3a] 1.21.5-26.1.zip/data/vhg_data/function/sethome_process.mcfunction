# Dedicated function to set a home securely
title @s actionbar {"text":"Your have successfully set a home","color":"green"}
summon minecraft:armor_stand ~ ~ ~ {Tags:["home_point","vhg_migrated","vhg_new_home"],NoGravity:1b,Invisible:1b,Marker:1b,PersistenceRequired:1b}
execute at @s run tp @e[tag=vhg_new_home,limit=1] ~ ~ ~ ~ ~
scoreboard players operation @e[tag=vhg_new_home,limit=1] home_key = @s home_key_time
tag @e[tag=vhg_new_home] remove vhg_new_home
forceload add ~ ~
scoreboard players operation @s home_key = @s home_key_time
