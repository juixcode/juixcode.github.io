scoreboard players set world vhg_config_dmgcancel 1
execute as @s run function datapack:vanilla_homes_datapack/config