scoreboard players set world vhg_config_delay 0
execute as @s run function datapack:vanilla_homes_datapack/config