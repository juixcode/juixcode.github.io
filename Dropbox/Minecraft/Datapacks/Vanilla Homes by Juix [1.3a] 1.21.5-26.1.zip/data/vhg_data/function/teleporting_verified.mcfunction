execute at @a[tag=vhg_active_player] run particle minecraft:end_rod ~ ~0.8 ~ 0.2 0.5 0.2 0.1 25 normal
execute at @a[tag=vhg_active_player] run playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ 1 1

tp @a[tag=vhg_active_player] ~ ~ ~ ~ ~
particle minecraft:end_rod ~ ~0.8 ~ 0.2 0.5 0.2 0.1 25 normal
playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ 1 1