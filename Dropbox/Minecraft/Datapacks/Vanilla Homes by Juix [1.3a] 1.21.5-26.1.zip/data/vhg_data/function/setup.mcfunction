
#
#	SCORES
#

scoreboard objectives add sethome trigger
scoreboard objectives add delhome trigger
scoreboard objectives add home trigger

scoreboard objectives add home_key dummy
scoreboard objectives add home_key_time dummy

scoreboard objectives add vhg_config_delay dummy
scoreboard objectives add vhg_config_dmgcancel dummy
scoreboard objectives add vhg_dmg_taken minecraft.custom:minecraft.damage_taken
scoreboard objectives add teleporting dummy
scoreboard objectives add vhg_target_key dummy

scoreboard players set world vhg_config_delay 0
scoreboard players set world vhg_config_dmgcancel 1

scoreboard players set world vhg_installation_test 2
tellraw @a {"text":"Vanilla Homes Installed","color":"green"}