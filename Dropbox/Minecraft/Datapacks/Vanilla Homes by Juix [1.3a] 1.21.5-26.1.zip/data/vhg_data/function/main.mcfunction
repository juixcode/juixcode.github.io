#	COMMANDS
scoreboard players enable @a sethome
scoreboard players enable @a delhome
scoreboard players enable @a home

execute as @a[scores={home=1..}] run function vhg_data:homes_commands
execute as @a[scores={delhome=1..}] run function vhg_data:homes_commands
execute as @a[scores={sethome=1..}] run function vhg_data:homes_commands

#   KEY PAIRING GENERATOR
execute as @a run execute unless entity @s[scores={home_key=1..}] run scoreboard players set @s home_key 0
scoreboard players add @a home_key_time 1

execute as @a[scores={teleporting=0..}] run function vhg_data:teleporting
scoreboard players reset @a[scores={vhg_dmg_taken=1..}] vhg_dmg_taken