
#
#	DEFAULT
#

scoreboard objectives add vhg_installation_test dummy
execute if score world vhg_installation_test matches 2.. run tellraw @a {"text":"Vanilla Homes Reloaded","color":"green"}
execute unless score world vhg_installation_test matches 2.. run function vhg_data:setup