execute as @a[scores={teleporting=..0}] run function vhg_data:teleport_process

#   DAMAGE CANCEL
execute if score world vhg_config_dmgcancel matches 0 run title @s[scores={vhg_dmg_taken=1..,teleporting=1..}] actionbar {"text":"Teleportation cancelled !","color":"red"}
execute if score world vhg_config_dmgcancel matches 0 run execute as @s[scores={vhg_dmg_taken=1..,teleporting=1..}] at @s run playsound minecraft:block.note_block.bass neutral @s ~ ~ ~ 1 0.5
execute if score world vhg_config_dmgcancel matches 0 run scoreboard players reset @s[scores={vhg_dmg_taken=1..,teleporting=1..}] teleporting

scoreboard players remove @s[scores={teleporting=1..}] teleporting 1