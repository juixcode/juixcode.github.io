
scoreboard objectives remove sethome
scoreboard objectives remove delhome
scoreboard objectives remove home

scoreboard objectives remove home_key
scoreboard objectives remove home_key_time

scoreboard objectives remove vhg_config_delay
scoreboard objectives remove vhg_config_dmgcancel
scoreboard objectives remove vhg_dmg_taken
scoreboard objectives remove teleporting
scoreboard objectives remove vhg_target_key

scoreboard objectives remove vhg_installation_test

tellraw @a {"text":"Uninstalled Vanilla Homes","color":"red"}

datapack disable "file/Vanilla Homes by Juix [1.3a] 1.21.5-26.1"
datapack disable "file/Vanilla Homes by Juix [1.3a] 1.21.5-26.1.zip"