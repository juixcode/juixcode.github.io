execute as @e[type=villager,tag=tps_teleporter_click] at @s run summon interaction ~ ~ ~ {Tags:["tps_teleporter_click"],width:1.0f,height:2.0f,response:true}
execute as @e[type=villager,tag=tps_teleporter_click] at @s run summon minecraft:block_display ~-0.4 ~ ~-0.4 {Tags:["tps_block_display"],block_state:{Name:"minecraft:end_portal_frame"}}
execute as @e[type=villager,tag=tps_teleporter_click] at @s positioned ~-0.4 ~ ~-0.4 run data merge entity @e[type=block_display,limit=1,sort=nearest,tag=tps_block_display] {transformation:{scale:[0.8f,0.8f,0.8f],translation:[0.0f,-0.4f,0.0f]}}

execute as @e[type=villager,tag=tps_teleporter_click] run kill @s
execute as @e[type=armor_stand,tag=tps_block_display] run kill @s

team remove tps_no_collision
scoreboard objectives remove tps_sneaking
scoreboard objectives remove tps_pnj_click