# Stocker le nombre d’items tenus en main
execute store result score @s tps_itemCount run data get entity @s SelectedItem.count

# Soustraire 1
scoreboard players remove @s tps_itemCount 1

# Si le stack est encore ≥ 1, le placer dans un stockage temporaire dans la bonne quantité, puis le remettre en main
execute if score @s tps_itemCount matches 1.. run item replace block 0 -64 0 container.1 from entity @s weapon.mainhand
execute if score @s tps_itemCount matches 1.. run execute store result block 0 -64 0 Items[1].count byte 1 run scoreboard players get @s tps_itemCount
execute if score @s tps_itemCount matches 1.. run item replace entity @s weapon.mainhand from block 0 -64 0 container.1

# Sinon, si le stack tombe à 0, vider la main
execute unless score @s tps_itemCount matches 1.. run item replace entity @s weapon.mainhand with air