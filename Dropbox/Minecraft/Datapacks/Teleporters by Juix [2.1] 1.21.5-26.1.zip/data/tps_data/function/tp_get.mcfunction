#
#   TP GET
#

title @s actionbar {"text":"Teleporter successfully removed","color":"green"}
execute as @e[tag=tps_teleporter,tag=tps_teleporter_deletion,limit=1,sort=nearest] run playsound minecraft:block.beacon.deactivate neutral @a ~ ~ ~ 0.5 2

#   GIVE ITEM BACK
execute if items entity @s weapon.mainhand * at @s run function tps_data:item/summon_teleporter_point1
execute unless items entity @s weapon.mainhand * at @s run function tps_data:item/give_teleporter_point1

#   DELETE THE PAIR
execute if entity @e[tag=tps_teleporter_deletion] run execute as @e[tag=tps_teleporter,tag=!tps_teleporter_deletion] if score @s item_tp_link = @e[tag=tps_teleporter_deletion,limit=1] item_tp_link at @s positioned ~ ~ ~ run function tps_data:tp_delete
execute as @e[tag=tps_teleporter,tag=tps_teleporter_deletion] at @s positioned ~ ~ ~ run function tps_data:tp_delete

scoreboard players set @s tps_left_click_cooldown 0