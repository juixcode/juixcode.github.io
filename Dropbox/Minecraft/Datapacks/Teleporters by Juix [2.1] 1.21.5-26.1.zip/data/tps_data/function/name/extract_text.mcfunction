# 1. Conversion String -> NBT
data remove storage tps_data:data nbt_object
$data modify storage tps_data:data nbt_object set value $(current_name)

# 2. Extraction du texte seul
data remove storage tps_data:data extracted_name
data modify storage tps_data:data extracted_name set from storage tps_data:data nbt_object.text