function tps_data:name/extract_text with storage tps_data:data
function tps_data:name/apply_color with storage tps_data:data