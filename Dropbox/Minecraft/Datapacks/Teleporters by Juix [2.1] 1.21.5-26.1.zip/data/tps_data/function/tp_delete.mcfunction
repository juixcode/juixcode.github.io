#
#   TP DELETE
#

playsound minecraft:block.glass.break neutral @a ~ ~ ~ 1 1

execute at @s positioned ~ ~-1.8 ~ run kill @e[tag=tps_teleporter_click,sort=nearest,limit=1]
kill @s
execute at @s positioned ~-0.4 ~-2.2 ~-0.4 run kill @e[tag=tps_block_display,sort=nearest,limit=1]
execute positioned ~-16 -64 ~-16 unless entity @e[tag=tps_teleporter,dx=32,dy=382,dz=32] positioned ~16 -64 ~16 run forceload remove ~ ~

#   COMPATIBILITY
forceload add 0 0