
#
#	DEFAULT
#

scoreboard objectives add teleporters_installation_test dummy
execute if score world teleporters_installation_test matches 4.. run tellraw @a {"text":"Teleporters Reloaded","color":"green"}
execute unless score world teleporters_installation_test matches 4.. run function tps_data:setup