execute as @a[scores={tps_placing=1..}] run tag @s add has_placed_a_teleporter

#
#   1ST POINT PLACED
#

#   STORING LINK-ID IN THE 1ST POINT (ENTITY)
execute unless entity @s[tag=tps_teleporter_2nd] run scoreboard players add @e[type=armor_stand,tag=teleporters_data,limit=1] tps_infinite_value 1
execute unless entity @s[tag=tps_teleporter_2nd] run scoreboard players operation @s item_tp_link = @e[tag=teleporters_data,limit=1] tps_infinite_value

#   STORING LINK-ID IN THE 2ND POINT (ITEM)
execute unless entity @s[tag=tps_teleporter_2nd] run execute store result storage tps_data:data item_tp_link_score int 1 run scoreboard players get @s item_tp_link

#   GIVE 2ND POINT
execute unless entity @s[tag=tps_teleporter_2nd] as @p[tag=has_placed_a_teleporter] if items entity @s[gamemode=creative] weapon.mainhand minecraft:armor_stand[custom_model_data={floats:[110]}] run function tps_data:item/give_teleporter_point2 with storage tps_data:data
execute unless entity @s[tag=tps_teleporter_2nd] as @p[tag=has_placed_a_teleporter] unless items entity @s[gamemode=creative] weapon.mainhand minecraft:armor_stand[custom_model_data={floats:[110]}] if items entity @s weapon.offhand minecraft:armor_stand[custom_model_data={floats:[110]}] run function tps_data:item/give_teleporter_point2_offhand with storage tps_data:data

execute unless entity @s[tag=tps_teleporter_2nd] as @p[tag=has_placed_a_teleporter] if items entity @s[gamemode=!creative] weapon.mainhand * unless items entity @s weapon.offhand * run function tps_data:item/give_teleporter_point2_offhand with storage tps_data:data
execute unless entity @s[tag=tps_teleporter_2nd] as @p[tag=has_placed_a_teleporter] unless items entity @s[gamemode=!creative] weapon.mainhand * run function tps_data:item/give_teleporter_point2 with storage tps_data:data

#   SUCCESS/ERROR MESSAGE
execute unless entity @s[tag=tps_teleporter_2nd] run title @p[tag=has_placed_a_teleporter] actionbar {"text":"Teleportation point placed","color":"green"}

#
#   2ND POINT PLACED
#

execute if entity @s[tag=tps_teleporter_2nd] as @p[tag=has_placed_a_teleporter] unless items entity @s weapon.mainhand minecraft:armor_stand[custom_model_data={floats:[111]}] if items entity @s weapon.offhand minecraft:armor_stand[custom_model_data={floats:[111]}] run item replace entity @s[gamemode=creative] weapon.offhand with air
execute if entity @s[tag=tps_teleporter_2nd] as @p[tag=has_placed_a_teleporter] if items entity @s weapon.mainhand minecraft:armor_stand[custom_model_data={floats:[111]}] run item replace entity @s[gamemode=creative] weapon.mainhand with air
execute if entity @s[tag=tps_teleporter_2nd] at @s run playsound minecraft:block.beacon.activate neutral @a ~ ~ ~ 0.5 2

#   SUCCESS/ERROR MESSAGE
execute if entity @s[tag=tps_teleporter_2nd] as @e[tag=tps_teleporter,tag=!tps_teleporter_2nd] if score @s item_tp_link = @p[tag=has_placed_a_teleporter] item_tp_link run tag @e[tag=tps_teleporter_2nd,tag=!updated] add verified
execute if entity @s[tag=tps_teleporter_2nd,tag=verified] run title @p[tag=has_placed_a_teleporter] actionbar {"text":"Teleporter completed","color":"green"}
execute if entity @s[tag=tps_teleporter_2nd,tag=!verified] run title @p[tag=has_placed_a_teleporter] actionbar {"text":"Error : 1st point has not been placed","color":"red"}

#   STORING LINK-ID IN THE 2ND POINT (ENTITY)
execute if entity @s[tag=tps_teleporter_2nd] run scoreboard players operation @s item_tp_link = @p[tag=has_placed_a_teleporter] item_tp_link

# SNAP ROTATION
execute as @s[y_rotation=-45..45] run tp @s ~ ~ ~ 0 0
execute as @s[y_rotation=45..135] run tp @s ~ ~ ~ 90 0
execute as @s[y_rotation=135..-135] run tp @s ~ ~ ~ 180 0
execute as @s[y_rotation=-135..-45] run tp @s ~ ~ ~ -90 0

#
#   TELEPORTER SUMMONING
#

execute if entity @s run summon minecraft:block_display ~-0.4 ~ ~-0.4 {Tags:["tps_block_display"],block_state:{Name:"minecraft:end_portal_frame"}}
execute positioned ~-0.4 ~ ~-0.4 as @e[type=block_display,limit=1,sort=nearest,tag=tps_block_display] at @s run tp @s ~ ~ ~ ~ 0
execute if entity @s positioned ~-0.4 ~ ~-0.4 run data merge entity @e[type=block_display,limit=1,sort=nearest,tag=tps_block_display] {transformation:{scale:[0.8f,0.8f,0.8f],translation:[0.0f,-0.4f,0.0f]}}
execute if entity @s run summon interaction ~ ~ ~ {Tags:["tps_teleporter_click"],width:1.0f,height:2.0f,response:true}
execute as @e[type=interaction,limit=1,sort=nearest,tag=tps_teleporter_click] at @s run tp @s ~ ~ ~ ~ 0
execute if entity @s run forceload add ~ ~
execute if entity @s if score world tps_option_floating_names_visibility matches 0 run data merge entity @s {CustomNameVisible:0b}
execute if entity @s[tag=tps_teleporter_2nd,tag=verified] as @e[tag=tps_teleporter] if score @s item_tp_link = @p[tag=has_placed_a_teleporter] item_tp_link run tag @s add active

#   UPDATE CUSTOM NAME COLOR TO GREEN
execute if entity @s[tag=tps_teleporter_2nd,tag=verified] as @e[tag=tps_teleporter] if score @s item_tp_link = @p[tag=has_placed_a_teleporter] item_tp_link run function tps_data:events/tp_placed_naming

execute if entity @s[tag=tps_teleporter_2nd,tag=!verified] run function tps_data:tp_delete
tag @s remove verified
tag @s remove tps_teleporter_2nd

tp @s ~ ~1.8 ~
tag @s add updated
tag @a[tag=has_placed_a_teleporter] remove has_placed_a_teleporter