tp @e[tag=tps_player_selected,limit=1] ~ ~-1.8 ~ ~ ~
particle minecraft:end_rod ~ ~-1 ~ 0.2 0.5 0.2 0.1 25 normal
playsound minecraft:entity.enderman.teleport neutral @a ~ ~-1.8 ~ 1 1

scoreboard players set @e[tag=tps_player_selected,limit=1] item_tp_cooldown 61