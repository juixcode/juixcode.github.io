#   UPDATE CUSTOM NAME COLOR TO GREEN
execute unless entity @s[name='Not Linked'] run data remove storage tps_data:data current_name
execute unless entity @s[name='Not Linked'] run data modify storage tps_data:data current_name set from entity @s CustomName
execute unless entity @s[name='Not Linked'] run function tps_data:name/update_color with storage tps_data:data

#   SET GENERIC NAME
execute if entity @s[name='Not Linked'] run execute store result storage tps_data:data item_tp_link_score int 1 run scoreboard players get @s item_tp_link
execute if entity @s[name='Not Linked'] run function tps_data:name/set_tunnel with storage tps_data:data
