tag @s add right_clicked
execute at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,sort=nearest,limit=1] if entity @s[tag=active] run tag @e[tag=tps_teleporter_click,tag=right_clicked,sort=nearest,limit=1] add active
execute on target unless items entity @s weapon.mainhand name_tag[custom_name] run scoreboard players add @s tps_right_click_cooldown 20

#   Renaming
execute if score world tps_option_floating_names_visibility matches 1 on target if items entity @s weapon.mainhand name_tag[custom_name] run function tps_data:events/renaming
execute unless score world tps_option_floating_names_visibility matches 1 on target if items entity @s weapon.mainhand name_tag[custom_name] run title @s actionbar {"text":"Teleporters names are disabled","color":"red"}
execute unless score world tps_option_floating_names_visibility matches 1 on target if items entity @s weapon.mainhand name_tag[custom_name] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.5 1

#   Error : Teleporter is the first point
execute if entity @s[tag=!active] on target unless items entity @s weapon.mainhand name_tag[custom_name] run title @s actionbar {"text":"Please place the second point first","color":"red"}

#   First click
execute if entity @s[tag=active] on target unless items entity @s weapon.mainhand name_tag[custom_name] if score @s tps_right_click_cooldown matches 20..25 run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 1.5
execute if entity @s[tag=active] on target unless items entity @s weapon.mainhand name_tag[custom_name] if score @s tps_right_click_cooldown matches 20..25 run title @s actionbar {"text":"Double Right click on the teleporter to move it","color":"yellow"}
execute if entity @s[tag=active] on target unless items entity @s weapon.mainhand name_tag[custom_name] if score @s tps_right_click_cooldown matches 20..25 run scoreboard players set @s tps_right_click_cooldown 20

#   Second click
execute if entity @s[tag=active] on target unless items entity @s weapon.mainhand name_tag[custom_name] if score @s tps_right_click_cooldown matches 26..40 at @s as @e[tag=right_clicked,tag=tps_teleporter_click,limit=1,sort=nearest,distance=..6] at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,limit=1,sort=nearest,distance=..6] run tag @s add tps_teleporter_acquisition
execute if entity @s[tag=active] on target unless items entity @s weapon.mainhand name_tag[custom_name] if score @s tps_right_click_cooldown matches 26..40 at @s run function tps_data:tp_move

tag @s remove right_clicked
tag @s remove active
data remove entity @s interaction