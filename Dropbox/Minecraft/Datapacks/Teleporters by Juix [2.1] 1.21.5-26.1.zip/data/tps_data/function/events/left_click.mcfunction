tag @s add left_clicked
execute on attacker run scoreboard players add @s tps_left_click_cooldown 20

#   First click
execute on attacker if score @s tps_left_click_cooldown matches 20..25 run playsound minecraft:ui.button.click master @s ~ ~ ~ 0.5 1.5
execute on attacker if score @s tps_left_click_cooldown matches 20..25 run title @s actionbar {"text":"Double Left click on the teleporter to remove the pair","color":"yellow"}
execute on attacker if score @s tps_left_click_cooldown matches 20..25 run scoreboard players set @s tps_left_click_cooldown 20

#   Second click - DELETE TELEPORTER
execute on attacker if score @s tps_left_click_cooldown matches 26..40 at @s as @e[tag=left_clicked,tag=tps_teleporter_click,limit=1,sort=nearest,distance=..6] at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,limit=1,sort=nearest,distance=..6] run tag @s add tps_teleporter_deletion
execute on attacker if score @s tps_left_click_cooldown matches 26..40 at @s run function tps_data:tp_get

tag @s remove left_clicked
data remove entity @s attack