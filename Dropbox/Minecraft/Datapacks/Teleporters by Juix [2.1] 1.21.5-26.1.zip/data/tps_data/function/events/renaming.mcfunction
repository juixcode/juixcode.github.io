#   TP RENAMING
execute as @e[tag=tps_teleporter_click,tag=right_clicked,sort=nearest,limit=1,distance=..8] at @s positioned ~ ~1.8 ~ as @e[tag=tps_teleporter,sort=nearest,limit=1,distance=..8] run tag @s add event_renamed

#   Remplacement direct du nom par le nom de l'item
data remove storage tps_data:data extracted_name
data modify storage tps_data:data extracted_name set from entity @s SelectedItem.components."minecraft:custom_name"
execute as @e[tag=tps_teleporter,tag=event_renamed,sort=nearest,limit=1] run function tps_data:name/apply_color with storage tps_data:data

tag @e[tag=tps_teleporter,tag=event_renamed] remove event_renamed
execute as @s[gamemode=!creative] run function tps_data:item_count_decrease