tag @s add tps_player_selected
execute at @s positioned ~ ~1.8 ~ run tag @e[tag=tps_teleporter,tag=active,sort=nearest,limit=1] add tps_teleporter_selected

scoreboard players operation @s item_tp_test = @e[tag=tps_teleporter_selected,limit=1,sort=nearest] item_tp_link
execute as @e[tag=tps_teleporter,tag=active,tag=!tps_teleporter_selected] at @s if score @s item_tp_link = @e[tag=tps_player_selected,limit=1] item_tp_test run function tps_data:tp_use_teleporting
particle minecraft:end_rod ~ ~0.8 ~ 0.2 0.5 0.2 0.1 25 normal
playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ 1 1

tag @s remove tps_player_selected
tag @e[tag=tps_teleporter_selected] remove tps_teleporter_selected