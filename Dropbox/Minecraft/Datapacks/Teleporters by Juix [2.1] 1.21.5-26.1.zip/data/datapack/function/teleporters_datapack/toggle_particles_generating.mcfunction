scoreboard players add world tps_option_particles_generating 1
execute if score world tps_option_particles_generating matches 2.. run scoreboard players set world tps_option_particles_generating 0

execute if score world tps_option_particles_generating matches 0 run tellraw @s {"text":"Teleporters' particles : Disabled","color":"red"}
execute if score world tps_option_particles_generating matches 1 run tellraw @s {"text":"Teleporters' particles : Enabled","color":"green"}