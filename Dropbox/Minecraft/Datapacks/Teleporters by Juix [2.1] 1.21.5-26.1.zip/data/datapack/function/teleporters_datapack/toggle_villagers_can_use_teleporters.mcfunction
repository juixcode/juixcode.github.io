scoreboard players add world tps_option_include_villagers 1
execute if score world tps_option_include_villagers matches 2.. run scoreboard players set world tps_option_include_villagers 0

execute if score world tps_option_include_villagers matches 0 run tellraw @s {"text":"Villagers can use teleporters : Disabled","color":"red"}
execute if score world tps_option_include_villagers matches 1 run tellraw @s {"text":"Villagers can use teleporters : Enabled","color":"green"}