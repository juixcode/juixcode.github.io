scoreboard players add world tps_option_floating_names_visibility 1
execute if score world tps_option_floating_names_visibility matches 2.. run scoreboard players set world tps_option_floating_names_visibility 0

execute if score world tps_option_floating_names_visibility matches 0 run tellraw @s {"text":"Teleporters' floating names : Disabled","color":"red"}
execute if score world tps_option_floating_names_visibility matches 0 run execute as @e[tag=tps_teleporter] run data merge entity @s {CustomNameVisible:0b}

execute if score world tps_option_floating_names_visibility matches 1 run tellraw @s {"text":"Teleporters' floating names : Enabled","color":"green"}
execute if score world tps_option_floating_names_visibility matches 1 run execute as @e[tag=tps_teleporter] run data merge entity @s {CustomNameVisible:1b}