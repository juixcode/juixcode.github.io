
scoreboard objectives remove hms_mined_blocks
scoreboard objectives remove hms_use_iron_pickaxe
scoreboard objectives remove hms_use_golden_pickaxe
scoreboard objectives remove hms_use_diamond_pickaxe
scoreboard objectives remove hms_use_netherite_pickaxe
scoreboard objectives remove hms_smithing_test

scoreboard objectives remove hammers_installation_test

tellraw @a {"text":"Uninstalled Hammers","color":"red"}
datapack disable "file/Hammers by Juix [1.5a] 1.21.5-26.2"
datapack disable "file/Hammers by Juix [1.5a] 1.21.5-26.2.zip"