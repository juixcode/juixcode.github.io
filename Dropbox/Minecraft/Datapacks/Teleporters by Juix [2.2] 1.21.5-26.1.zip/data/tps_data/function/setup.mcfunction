scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#   WORLD
forceload add -1 -1 1 1
execute unless score world teleporters_installation_test matches 1.. run summon minecraft:armor_stand 0 0 0 {Invulnerable:1b,Tags:["teleporters_data"],Invisible:1b,NoGravity:1b,Marker:1b}
execute unless score world teleporters_installation_test matches 4.. run setblock 0 -64 0 minecraft:barrel

#
#   MIGRATION
#

#   v1.4 : Introducing the renaming feature
execute if score world teleporters_installation_test matches 1..2 run tag @e[type=armor_stand,tag=tps_teleporter,name=Linked] add active
#   v2.0 : Introducing double right & left clicks
execute if score world teleporters_installation_test matches 1..3 run function tps_data:version_migration/pnj_to_interaction

#
#	DEFAULT
#

scoreboard objectives add tps_left_click_cooldown dummy
scoreboard objectives add tps_right_click_cooldown dummy

scoreboard objectives add tps_placing minecraft.used:minecraft.armor_stand
scoreboard objectives add tps_infinite_value dummy
scoreboard objectives add tps_itemCount dummy

scoreboard objectives add item_tp_cooldown dummy
scoreboard objectives add item_tp_test dummy
scoreboard objectives add item_tp_link dummy

scoreboard objectives add tps_option_include_villagers dummy
scoreboard players set world tps_option_include_villagers 0

scoreboard objectives add tps_option_floating_names_visibility dummy
scoreboard players set world tps_option_floating_names_visibility 1

scoreboard objectives add tps_option_particles_generating dummy
scoreboard players set world tps_option_particles_generating 1

scoreboard players set world teleporters_installation_test 4
tellraw @a {"text":"Teleporters Installed","color":"green"}