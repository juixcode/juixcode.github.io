
#
#	DATAPACK
#

execute as @e[tag=tps_teleporter] at @s positioned ~ ~ ~ run function tps_data:tp_delete
kill @e[tag=teleporters_data]

scoreboard objectives remove tps_left_click_cooldown
scoreboard objectives remove tps_right_click_cooldown

scoreboard objectives remove tps_placing
scoreboard objectives remove tps_infinite_value
scoreboard objectives remove tps_itemCount

scoreboard objectives remove item_tp_cooldown
scoreboard objectives remove item_tp_test
scoreboard objectives remove item_tp_link

scoreboard objectives remove tps_option_floating_names_visibility
scoreboard objectives remove tps_option_particles_generating
scoreboard objectives remove tps_option_include_villagers
scoreboard objectives remove teleporters_installation_test

tellraw @a {"text":"Uninstalled Teleporters","color":"red"}
datapack disable "file/Teleporters by Juix [2.2] 1.21.5-26.1"
datapack disable "file/Teleporters by Juix [2.2] 1.21.5-26.1.zip"