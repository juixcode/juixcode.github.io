#   /trigger show_recipes

scoreboard players enable @a show_recipes_in_chat
scoreboard players enable @a show_recipes_in_browser

execute as @a[scores={show_recipes_in_chat=1..}] run function juix:recipes/show_all_chat
scoreboard players reset @a[scores={show_recipes_in_chat=1..}] show_recipes_in_chat

execute as @a[scores={show_recipes_in_browser=1..}] run function juix:recipes/show_browser
scoreboard players reset @a[scores={show_recipes_in_browser=1..}] show_recipes_in_browser

#   BRIDGE EGGS

execute as @e[type=egg,tag=!beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] at @s run function beg_data:items/update

execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] run execute store result entity @s Rotation[0] float 1 run scoreboard players get @s beg_motion_x1
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] run execute store result entity @s Rotation[1] float 1 run scoreboard players get @s beg_motion_y1
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] run execute store result entity @s Rotation[2] float 1 run scoreboard players get @s beg_motion_z1

execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_bridge_egg:1}}}}] at @s run playsound minecraft:block.note_block.xylophone block @a ~ ~ ~ 1 1
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_leaves_bridge_egg:1}}}}] at @s positioned ^ ^-1 ^-2 unless entity @a[distance=..2.5] positioned ^ ^ ^2 run fill ^-1 ^ ^-2 ^1 ^ ^-3 minecraft:oak_leaves replace minecraft:air
execute as @e[type=egg,tag=beg_updated,nbt={Item:{components:{"minecraft:custom_data":{beg_ice_bridge_egg:1}}}}] at @s positioned ^ ^-1 ^-2 unless entity @a[distance=..2.5] positioned ^ ^ ^2 run fill ^-1 ^ ^-2 ^1 ^ ^-3 minecraft:ice replace minecraft:air