scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#
#	DEFAULT
#

scoreboard objectives add beg_motion_x1 dummy
scoreboard objectives add beg_motion_y1 dummy
scoreboard objectives add beg_motion_z1 dummy

scoreboard players set world bridge_eggs_installation_test 1
tellraw @a {"text":"Bridge Eggs Installed","color":"green"}