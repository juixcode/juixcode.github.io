
#   ORES

execute if block ~ ~ ~ ancient_debris run function vpx_data:mine/loot_block

execute if block ~ ~ ~ #minecraft:coal_ores run function vpx_data:mine/loot_block_common

execute if block ~ ~ ~ #minecraft:iron_ores run function vpx_data:mine/loot_block

execute if block ~ ~ ~ gold_ore run function vpx_data:mine/loot_block
execute if block ~ ~ ~ deepslate_gold_ore run function vpx_data:mine/loot_block
execute if block ~ ~ ~ nether_gold_ore run function vpx_data:mine/loot_block_common

execute if block ~ ~ ~ #minecraft:copper_ores run function vpx_data:mine/loot_block

execute if block ~ ~ ~ #minecraft:redstone_ores run function vpx_data:mine/loot_block_common

execute if block ~ ~ ~ #minecraft:emerald_ores run function vpx_data:mine/loot_block_mythic

execute if block ~ ~ ~ #minecraft:lapis_ores run function vpx_data:mine/loot_block_rare

execute if block ~ ~ ~ #minecraft:diamond_ores run function vpx_data:mine/loot_block_mythic

execute if block ~ ~ ~ nether_quartz_ore run function vpx_data:mine/loot_block_rare