execute as @p[tag=vein_pickaxe] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air

playsound minecraft:block.stone.break block @a ~ ~ ~ 1 1

summon minecraft:marker ~ ~ ~ {Tags:["vein_pickaxe_detection"]}