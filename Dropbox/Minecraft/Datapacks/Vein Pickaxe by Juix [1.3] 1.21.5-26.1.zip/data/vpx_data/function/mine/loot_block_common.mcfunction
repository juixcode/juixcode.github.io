summon experience_orb ~ ~ ~ {Value:1}
function vpx_data:mine/loot_block