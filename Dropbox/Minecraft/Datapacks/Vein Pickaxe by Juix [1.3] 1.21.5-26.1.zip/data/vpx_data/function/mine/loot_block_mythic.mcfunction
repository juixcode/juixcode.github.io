summon experience_orb ~ ~ ~ {Value:5}
function vpx_data:mine/loot_block