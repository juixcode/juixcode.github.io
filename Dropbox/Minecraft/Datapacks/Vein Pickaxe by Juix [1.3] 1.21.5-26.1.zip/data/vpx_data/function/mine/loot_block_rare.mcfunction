summon experience_orb ~ ~ ~ {Value:4}
function vpx_data:mine/loot_block