scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

scoreboard objectives add juix_restricted_tool dummy

scoreboard objectives add vein_pickaxes_mined_blocks dummy
scoreboard objectives add vpx_smithing_test dummy

scoreboard objectives add vpx_use_diamond_pickaxe minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add vpx_use_netherite_pickaxe minecraft.used:minecraft.netherite_pickaxe

scoreboard players set world vein_pickaxe_installation_test 1
tellraw @a {"text":"Vein Pickaxe Installed","color":"green"}