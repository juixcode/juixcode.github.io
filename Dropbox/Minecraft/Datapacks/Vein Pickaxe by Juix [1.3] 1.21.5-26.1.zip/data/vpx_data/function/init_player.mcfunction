recipe take @s minecraft:netherite_pickaxe_smithing
tag @s add vpx_init_player
