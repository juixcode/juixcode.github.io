#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=5}] run function vpx_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function vpx_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function vpx_data:recipes/show_links

#   RESTRICTED TOOL PROTECTION - FOR MAGNETS COMPATIBILITY
execute as @a[tag=!vpx_init_player] run function vpx_data:init_player

execute as @a[tag=!vein_pickaxe] if items entity @s weapon.mainhand netherite_pickaxe[custom_model_data={floats:[101]}] run function vpx_data:set_restricted_tool
execute as @a[tag=!vein_pickaxe] if items entity @s weapon.mainhand diamond_pickaxe[custom_model_data={floats:[101]}] run function vpx_data:set_restricted_tool
execute as @a[tag=vein_pickaxe] unless items entity @s weapon.mainhand diamond_pickaxe[custom_model_data={floats:[101]}] unless items entity @s weapon.mainhand netherite_pickaxe[custom_model_data={floats:[101]}] run function vpx_data:unset_restricted_tool

execute as @a[scores={juix_restricted_tool=1..}] run tag @s add juix_restricted_tool
execute as @a unless entity @s[scores={juix_restricted_tool=1..}] run tag @s remove juix_restricted_tool

#   VEIN PICKAXE

execute as @a[scores={vpx_use_netherite_pickaxe=1..},tag=vein_pickaxe] at @s run summon minecraft:marker ~ ~ ~ {Tags:["vein_pickaxe_detection","vpx_initial_marker"]}
execute as @a[scores={vpx_use_diamond_pickaxe=1..},tag=vein_pickaxe] at @s run summon minecraft:marker ~ ~ ~ {Tags:["vein_pickaxe_detection","vpx_initial_marker"]}

execute as @a[scores={vpx_use_netherite_pickaxe=1..},tag=vein_pickaxe] at @s run execute as @e[tag=vpx_initial_marker,sort=nearest,limit=1] at @s run tp @s @e[distance=..6,sort=nearest,limit=1,type=item,tag=!vein_pickaxe_mined]
execute as @a[scores={vpx_use_diamond_pickaxe=1..},tag=vein_pickaxe] at @s run execute as @e[tag=vpx_initial_marker,sort=nearest,limit=1] at @s run tp @s @e[distance=..6,sort=nearest,limit=1,type=item,tag=!vein_pickaxe_mined]
execute as @e[tag=vpx_initial_marker,sort=nearest,limit=1] at @s align xyz run tp @s ~0.5 ~ ~0.5

execute as @e[tag=vpx_initial_marker] at @s unless items entity @e[type=item,tag=!vein_pickaxe_mined,distance=..1,limit=1,sort=nearest] contents #vpx_data:valid_vein_drops run kill @s
tag @e[tag=vpx_initial_marker] remove vpx_initial_marker

execute as @e[tag=vein_pickaxe_detection] at @s run function vpx_data:vein_pickaxe

scoreboard players reset @a vpx_use_diamond_pickaxe
scoreboard players reset @a vpx_use_netherite_pickaxe

execute at @a[tag=vein_pickaxe] run tag @e[type=item,tag=!vein_pickaxe_mined,distance=..6] add vein_pickaxe_mined
execute as @e[tag=vein_pickaxe_mined] run tag @s add juix_teleportable_item

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=vpx_smithing] if items entity @s container.* minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[101]},minecraft:item_name={"text":"Diamond Vein Pickaxe","italic":false}] run function vpx_data:netherite_tool_name_replace