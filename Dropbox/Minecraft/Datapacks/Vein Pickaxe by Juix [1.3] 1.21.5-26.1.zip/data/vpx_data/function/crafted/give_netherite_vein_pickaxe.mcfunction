recipe take @s minecraft:netherite_pickaxe_smithing
advancement revoke @s only vpx_data:netherite_vein_pickaxe_adv

execute as @s store result score @s vpx_smithing_test run clear @s minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[101]},minecraft:item_name={"text":"Diamond Vein Pickaxe","italic":false}] 0
execute as @s[scores={vpx_smithing_test=1..}] run tag @s add vpx_smithing