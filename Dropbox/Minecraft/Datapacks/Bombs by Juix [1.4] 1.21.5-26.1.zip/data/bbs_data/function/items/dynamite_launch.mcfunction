execute at @s run playsound minecraft:entity.lingering_potion.throw player @a ~ ~ ~ 1 1
execute at @s run summon minecraft:armor_stand ^ ^1.5 ^0.8 {Tags:["bbs_dynamite"],Invisible:true,Invulnerable:true,NoBasePlate:true,Small:true,DisabledSlots:4144959,equipment:{head:{id:"paper",count:1,components:{"custom_data":{antidrop:1},"minecraft:custom_model_data":{"floats":[110]}}}}}
execute at @s as @e[tag=bbs_dynamite,limit=1,sort=nearest] at @s rotated as @p run function bbs_data:items/dynamite_motion

execute as @s[gamemode=!creative] run function bbs_data:item_count_decrease