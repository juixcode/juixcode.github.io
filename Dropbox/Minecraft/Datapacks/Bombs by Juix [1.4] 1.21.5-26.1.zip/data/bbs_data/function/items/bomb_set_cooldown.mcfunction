playsound minecraft:block.basalt.place neutral @a ~ ~ ~ 1 1

execute if entity @s[tag=bbs_bomb1] run summon armor_stand ~ ~-1.19 ~ {Marker:1b,Invisible:1b,NoBasePlate:1b,Invulnerable:1b,NoGravity:1b,Tags:[bbs_bomb_texture],DisabledSlots:4144959,equipment:{head:{id:"strider_spawn_egg",count:1,components:{"custom_data":{antidrop:1},"minecraft:custom_model_data":{"floats":[101]}}}}}
execute if entity @s[tag=bbs_bomb2] run summon armor_stand ~ ~-1.19 ~ {Marker:1b,Invisible:1b,NoBasePlate:1b,Invulnerable:1b,NoGravity:1b,Tags:[bbs_bomb_texture],DisabledSlots:4144959,equipment:{head:{id:"strider_spawn_egg",count:1,components:{"custom_data":{antidrop:1},"minecraft:custom_model_data":{"floats":[102]}}}}}
execute if entity @s[tag=bbs_bomb3] run summon armor_stand ~ ~-1.19 ~ {Marker:1b,Invisible:1b,NoBasePlate:1b,Invulnerable:1b,NoGravity:1b,Tags:[bbs_bomb_texture],DisabledSlots:4144959,equipment:{head:{id:"strider_spawn_egg",count:1,components:{"custom_data":{antidrop:1},"minecraft:custom_model_data":{"floats":[103]}}}}}
execute if entity @s[tag=bbs_bomb4] run summon armor_stand ~ ~-1.19 ~ {Marker:1b,Invisible:1b,NoBasePlate:1b,Invulnerable:1b,NoGravity:1b,Tags:[bbs_bomb_texture],DisabledSlots:4144959,equipment:{head:{id:"strider_spawn_egg",count:1,components:{"custom_data":{antidrop:1},"minecraft:custom_model_data":{"floats":[104]}}}}}
execute if block ~ ~ ~ air run setblock ~ ~ ~ barrier replace

scoreboard players set @s[tag=bbs_bomb1] bbs_duration_cooldown 6
scoreboard players set @s[tag=bbs_bomb2] bbs_duration_cooldown 8
scoreboard players set @s[tag=bbs_bomb3] bbs_duration_cooldown 11
scoreboard players set @s[tag=bbs_bomb4] bbs_duration_cooldown 6

tag @s add bbs_update
function bbs_data:items/bomb_update_cooldown