scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#
#	DEFAULT
#

scoreboard objectives add bbs_itemCount dummy
setblock 0 -64 0 minecraft:barrel

scoreboard objectives add bbs_item_clicked minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add bbs_bomb_timer dummy
scoreboard objectives add bbs_duration_timer dummy
scoreboard objectives add bbs_duration_cooldown dummy
scoreboard objectives add bbs_effect_duration dummy

scoreboard objectives add bbs_motion_x1 dummy
scoreboard objectives add bbs_motion_y1 dummy
scoreboard objectives add bbs_motion_z1 dummy
scoreboard objectives add bbs_motion_x2 dummy
scoreboard objectives add bbs_motion_y2 dummy
scoreboard objectives add bbs_motion_z2 dummy

scoreboard objectives add bbs_option_power dummy
scoreboard players set world bbs_option_power 1

scoreboard players set world bombs_installation_test 2
tellraw @a {"text":"Bombs Installed","color":"green"}