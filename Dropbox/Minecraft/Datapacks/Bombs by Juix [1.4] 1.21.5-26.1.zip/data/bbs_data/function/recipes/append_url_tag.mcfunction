# V�rifie si le pack est install�, puis ajoute son tag � l'URL
execute if score world bombs_installation_test matches 1.. run function bbs_data:recipes/concat_url_tag with storage juix:recipes
