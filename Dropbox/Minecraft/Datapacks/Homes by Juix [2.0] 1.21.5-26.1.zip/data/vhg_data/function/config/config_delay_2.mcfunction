scoreboard players set world vhg_config_delay 2
execute as @s run function datapack:homes_datapack/config