execute store result score #val vhg_temp run data get storage vhg:config homes_count_limit
scoreboard players add #val vhg_temp 1
execute store result storage vhg:config homes_count_limit int 1 run scoreboard players get #val vhg_temp
execute as @s run function datapack:homes_datapack/config