execute store result score #val vhg_temp run data get storage vhg:config homes_count_limit
scoreboard players remove #val vhg_temp 1
execute if score #val vhg_temp matches ..-1 run scoreboard players set #val vhg_temp 0
execute store result storage vhg:config homes_count_limit int 1 run scoreboard players get #val vhg_temp
execute as @s run function datapack:homes_datapack/config