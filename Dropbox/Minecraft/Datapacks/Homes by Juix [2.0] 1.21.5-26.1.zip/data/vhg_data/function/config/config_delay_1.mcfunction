scoreboard players set world vhg_config_delay 1
execute as @s run function datapack:homes_datapack/config