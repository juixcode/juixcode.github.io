scoreboard players set world vhg_config_dmgcancel 0
execute as @s run function datapack:homes_datapack/config