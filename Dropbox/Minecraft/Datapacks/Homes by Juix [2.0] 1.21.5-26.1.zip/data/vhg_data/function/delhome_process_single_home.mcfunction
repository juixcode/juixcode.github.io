# Macro function to handle trigger delhome when player has exactly 1 home
# Parameters: $(vhg_id), $(del_id)

# If del_id is 0 (no ID specified, e.g. "/trigger delhome")
$execute if score #del_id vhg_temp matches 0 run execute store result score #target_id vhg_temp run data get storage vhg:homes players.p$(vhg_id).homes_list[0].id
execute if score #del_id vhg_temp matches 0 run execute store result storage vhg:homes macro_args.del_id int 1 run scoreboard players get #target_id vhg_temp
execute if score #del_id vhg_temp matches 0 run function vhg_data:storage/delete_home with storage vhg:homes macro_args

# If del_id is 1.. (ID specified, e.g. "/trigger delhome set X")
execute if score #del_id vhg_temp matches 1.. run scoreboard players set #has_home vhg_temp 0
$execute if score #del_id vhg_temp matches 1.. store result score #has_home vhg_temp run data get storage vhg:homes players.p$(vhg_id).homes_map.h$(del_id)

execute if score #del_id vhg_temp matches 1.. if score #has_home vhg_temp matches 0 run tellraw @s {"text":"You don't have a home with this ID !","color":"red"}

execute if score #del_id vhg_temp matches 1.. if score #has_home vhg_temp matches 1.. run function vhg_data:storage/delete_home with storage vhg:homes macro_args
