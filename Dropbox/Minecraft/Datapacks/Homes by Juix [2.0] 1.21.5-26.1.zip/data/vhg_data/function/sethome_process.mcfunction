# Macro function to process home creation
# Parameters: $(vhg_id)

# 1. Check if the player already has homes
scoreboard players set #count vhg_temp 0
$execute store result score #count vhg_temp run data get storage vhg:homes players.p$(vhg_id).count

# Check if player has reached the limit configured in storage
scoreboard players set #limit vhg_temp 0
execute store result score #limit vhg_temp run data get storage vhg:config homes_count_limit
execute unless score #limit vhg_temp matches 0 if score #count vhg_temp >= #limit vhg_temp run tellraw @s {"text":"You have reached your home limit!","color":"red"}
execute unless score #limit vhg_temp matches 0 if score #count vhg_temp >= #limit vhg_temp run return 1


# CASE A: Player has NO homes yet
$execute if score #count vhg_temp matches ..0 run data modify storage vhg:homes players.p$(vhg_id) set value {max_id:1, count:1, homes_list:[], homes_map:{}}
execute if score #count vhg_temp matches ..0 run scoreboard players set #new_id vhg_temp 1

# CASE B: Player ALREADY has homes (>= 1)
# Get current max_id and increment it
$execute if score #count vhg_temp matches 1.. store result score #max_id vhg_temp run data get storage vhg:homes players.p$(vhg_id).max_id
execute if score #count vhg_temp matches 1.. run scoreboard players add #max_id vhg_temp 1
execute if score #count vhg_temp matches 1.. run scoreboard players operation #new_id vhg_temp = #max_id vhg_temp

# Write updated max_id and count back to storage
$execute if score #count vhg_temp matches 1.. store result storage vhg:homes players.p$(vhg_id).max_id int 1 run scoreboard players get #new_id vhg_temp
$execute if score #count vhg_temp matches 1.. store result score #new_count vhg_temp run data get storage vhg:homes players.p$(vhg_id).count
execute if score #count vhg_temp matches 1.. run scoreboard players add #new_count vhg_temp 1
$execute if score #count vhg_temp matches 1.. store result storage vhg:homes players.p$(vhg_id).count int 1 run scoreboard players get #new_count vhg_temp

# 2. Write the new ID into macro args and save home data
execute store result storage vhg:homes macro_args.new_id int 1 run scoreboard players get #new_id vhg_temp
function vhg_data:storage/save_home with storage vhg:homes macro_args

scoreboard players set @s home_key 1
