# OBSOLETE - Replaced by trigger_system.mcfunction
