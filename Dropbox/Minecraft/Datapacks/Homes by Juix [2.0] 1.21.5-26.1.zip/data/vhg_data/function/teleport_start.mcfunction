# Logic to start teleportation countdown based on world delay config
execute if score world vhg_config_delay matches 0 run scoreboard players set @s teleporting 0
execute if score world vhg_config_delay matches 1 run scoreboard players set @s teleporting 60
execute if score world vhg_config_delay matches 2 run scoreboard players set @s teleporting 100
execute if score world vhg_config_delay matches 3 run scoreboard players set @s teleporting 200

# Actionbar messages
execute if score world vhg_config_delay matches 0 run title @s actionbar {"text":"You are back home","color":"green"}
execute if score world vhg_config_delay matches 1 run title @s actionbar {"text":"You'll be back home in 3s","color":"green"}
execute if score world vhg_config_delay matches 2 run title @s actionbar {"text":"You'll be back home in 5s","color":"green"}
execute if score world vhg_config_delay matches 3 run title @s actionbar {"text":"You'll be back home in 10s","color":"green"}
