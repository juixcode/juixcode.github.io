# Logic to handle the unified system trigger
# Decodes the score of `system` to execute specific menu actions

# Copy trigger score
scoreboard players operation #system_val vhg_temp = @s system

# Reset trigger
scoreboard players set @s system -1

# Prepare constants for subtraction
scoreboard players set #c10000 vhg_temp 10000
scoreboard players set #c20000 vhg_temp 20000
scoreboard players set #c30000 vhg_temp 30000
scoreboard players set #c40000 vhg_temp 40000

# Prepare vhg_id
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id

# 1. CYCLE COLOR (10001..19999)
execute if score #system_val vhg_temp matches 10001..19999 run scoreboard players operation #home_id vhg_temp = #system_val vhg_temp
execute if score #system_val vhg_temp matches 10001..19999 run scoreboard players operation #home_id vhg_temp -= #c10000 vhg_temp
execute if score #system_val vhg_temp matches 10001..19999 run execute store result storage vhg:homes macro_args.home_id int 1 run scoreboard players get #home_id vhg_temp
execute if score #system_val vhg_temp matches 10001..19999 run function vhg_data:storage/cycle_color with storage vhg:homes macro_args

# 2. CYCLE TAG (20001..29999)
execute if score #system_val vhg_temp matches 20001..29999 run scoreboard players operation #home_id vhg_temp = #system_val vhg_temp
execute if score #system_val vhg_temp matches 20001..29999 run scoreboard players operation #home_id vhg_temp -= #c20000 vhg_temp
execute if score #system_val vhg_temp matches 20001..29999 run execute store result storage vhg:homes macro_args.home_id int 1 run scoreboard players get #home_id vhg_temp
execute if score #system_val vhg_temp matches 20001..29999 run function vhg_data:storage/cycle_tag with storage vhg:homes macro_args

# 3. DELETE AND SHOW MAIN MENU (30001..39999)
execute if score #system_val vhg_temp matches 30001..39999 run scoreboard players operation #home_id vhg_temp = #system_val vhg_temp
execute if score #system_val vhg_temp matches 30001..39999 run scoreboard players operation #home_id vhg_temp -= #c30000 vhg_temp
execute if score #system_val vhg_temp matches 30001..39999 run execute store result storage vhg:homes macro_args.del_id int 1 run scoreboard players get #home_id vhg_temp
execute if score #system_val vhg_temp matches 30001..39999 run scoreboard players set #show_menu_after_del vhg_temp 1
execute if score #system_val vhg_temp matches 30001..39999 run function vhg_data:storage/delete_home with storage vhg:homes macro_args

# 4. DELETE AND SHOW DELETE MENU (40001..49999)
execute if score #system_val vhg_temp matches 40001..49999 run scoreboard players operation #home_id vhg_temp = #system_val vhg_temp
execute if score #system_val vhg_temp matches 40001..49999 run scoreboard players operation #home_id vhg_temp -= #c40000 vhg_temp
execute if score #system_val vhg_temp matches 40001..49999 run execute store result storage vhg:homes macro_args.del_id int 1 run scoreboard players get #home_id vhg_temp
execute if score #system_val vhg_temp matches 40001..49999 run scoreboard players set #show_menu_after_del vhg_temp 2
execute if score #system_val vhg_temp matches 40001..49999 run function vhg_data:storage/delete_home with storage vhg:homes macro_args

# 5. CONFIGURATION PANEL ACTIONS (50000..50021)
execute if score #system_val vhg_temp matches 50000 run function vhg_data:config/config_delay_0
execute if score #system_val vhg_temp matches 50001 run function vhg_data:config/config_delay_1
execute if score #system_val vhg_temp matches 50002 run function vhg_data:config/config_delay_2
execute if score #system_val vhg_temp matches 50003 run function vhg_data:config/config_delay_3

execute if score #system_val vhg_temp matches 50010 run function vhg_data:config/config_dmgcancel_0
execute if score #system_val vhg_temp matches 50011 run function vhg_data:config/config_dmgcancel_1

execute if score #system_val vhg_temp matches 50020 run function vhg_data:config/config_homescountlimit_decrease
execute if score #system_val vhg_temp matches 50021 run function vhg_data:config/config_homescountlimit_increase

