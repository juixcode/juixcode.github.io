# Macro function to handle trigger home when player has exactly 1 home
# Parameters: $(vhg_id), $(target_id)

# If target_id is 0 (no ID specified, e.g. "/trigger home")
$execute if score #target_id vhg_temp matches 0 run execute store result storage vhg:homes players.p$(vhg_id).target_home_id int 1 run data get storage vhg:homes players.p$(vhg_id).homes_list[0].id
execute if score #target_id vhg_temp matches 0 run function vhg_data:teleport_start

# If target_id is 1.. (ID specified, e.g. "/trigger home set X")
execute if score #target_id vhg_temp matches 1.. run scoreboard players set #has_home vhg_temp 0
$execute if score #target_id vhg_temp matches 1.. store result score #has_home vhg_temp run data get storage vhg:homes players.p$(vhg_id).homes_map.h$(target_id)

execute if score #target_id vhg_temp matches 1.. if score #has_home vhg_temp matches 0 run tellraw @s {"text":"You don't have a home with this ID !","color":"red"}

$execute if score #target_id vhg_temp matches 1.. if score #has_home vhg_temp matches 1.. run data modify storage vhg:homes players.p$(vhg_id).target_home_id set value $(target_id)
execute if score #target_id vhg_temp matches 1.. if score #has_home vhg_temp matches 1.. run function vhg_data:teleport_start
