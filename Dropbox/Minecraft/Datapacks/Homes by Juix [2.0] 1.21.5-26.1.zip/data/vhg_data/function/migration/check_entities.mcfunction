# Look for a home_point matching the player's key
scoreboard players operation #target vhg_temp = @s home_key
execute as @e[tag=home_point] if score @s home_key = #target vhg_temp at @s run function vhg_data:migration/migrate_entity
