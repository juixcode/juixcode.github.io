# Macro to finalize migration to the new multi-homes structure
$data modify storage vhg:homes players.p$(vhg_id) set value {max_id:1, count:1, homes_list:[], homes_map:{}}

# Initialize h1 inside homes_map
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h1 set value {id:1,x:0,y:0,z:0,dim:"",yaw:0f,pitch:0f,tag:"Home",color:"white",tag_idx:0,color_idx:7}

# Round coordinates and move data to h1
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h1.x int 1 run data get storage vhg:homes migration_temp.pos[0]
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h1.y int 1 run data get storage vhg:homes migration_temp.pos[1]
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h1.z int 1 run data get storage vhg:homes migration_temp.pos[2]

$data modify storage vhg:homes players.p$(vhg_id).homes_map.h1.dim set from storage vhg:homes migration_temp.dim
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h1.yaw set from storage vhg:homes migration_temp.rot[0]
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h1.pitch set from storage vhg:homes migration_temp.rot[1]

# Copy the migrated home to homes_list
$data modify storage vhg:homes players.p$(vhg_id).homes_list append from storage vhg:homes players.p$(vhg_id).homes_map.h1

# Reset legacy key to 1 (new boolean style)
scoreboard players set @s home_key 1

tellraw @s {"text":"Your legacy home has been migrated to the new multi-homes storage system!","color":"aqua"}