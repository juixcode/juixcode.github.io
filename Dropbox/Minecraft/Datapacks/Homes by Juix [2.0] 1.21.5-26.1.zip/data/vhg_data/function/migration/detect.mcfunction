# Detect if the player has an old home entity to migrate
tag @s add vhg_active_migration

# Only proceed if they have a home_key (legacy or new)
execute if score @s home_key matches 1.. run function vhg_data:migration/check_entities

# Mark as checked/migrated so we don't scan every tick
tag @s add vhg_migrated
tag @s remove vhg_active_migration
