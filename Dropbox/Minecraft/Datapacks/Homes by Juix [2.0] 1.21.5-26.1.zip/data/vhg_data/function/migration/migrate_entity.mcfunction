# Runs AS the legacy entity
# Copy data to temp storage
data modify storage vhg:homes migration_temp.pos set from entity @s Pos
data modify storage vhg:homes migration_temp.rot set from entity @s Rotation

# Detect Dimension (Markers don't have a Dimension NBT tag)
data modify storage vhg:homes migration_temp.dim set value "minecraft:overworld"
execute if dimension minecraft:the_nether run data modify storage vhg:homes migration_temp.dim set value "minecraft:the_nether"
execute if dimension minecraft:the_end run data modify storage vhg:homes migration_temp.dim set value "minecraft:the_end"


# Tell the player to finalize the migration
execute as @a[tag=vhg_active_migration] run function vhg_data:migration/finalize

# Clean up entity
forceload remove ~ ~
kill @s

