# Runs AS the player
# Prepare macro args
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id

# Call macro to move data from migration_temp to player's path
function vhg_data:migration/finalize_macro with storage vhg:homes macro_args
