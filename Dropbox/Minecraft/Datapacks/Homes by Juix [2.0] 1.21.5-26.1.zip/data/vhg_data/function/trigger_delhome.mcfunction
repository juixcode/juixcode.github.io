#   Logic for /trigger delhome (Multi-home version)
# Copy the trigger score (which contains the ID) to a temp score
scoreboard players operation #del_id vhg_temp = @s delhome

# Reset trigger score to -1 (inactive state)
scoreboard players set @s delhome -1

# Default show_menu_after_del to 0 (no menu redraw for manual delete)
scoreboard players set #show_menu_after_del vhg_temp 0

# Prepare macro arguments
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id
execute store result storage vhg:homes macro_args.del_id int 1 run scoreboard players get #del_id vhg_temp

# Run the process
function vhg_data:delhome_process with storage vhg:homes macro_args
