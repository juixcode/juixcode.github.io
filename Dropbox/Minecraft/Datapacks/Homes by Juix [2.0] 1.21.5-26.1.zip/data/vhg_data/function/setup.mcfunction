
function vhg_data:setup_modern
function vhg_data:setup_legacy

#
#	SCORES
#

scoreboard objectives add sethome trigger
scoreboard objectives add delhome trigger
scoreboard objectives add home trigger

scoreboard objectives add system trigger

scoreboard objectives add home_key dummy
scoreboard objectives add home_key_time dummy

scoreboard objectives add vhg_id dummy
scoreboard objectives add vhg_temp dummy

scoreboard objectives add vhg_config_delay dummy
scoreboard objectives add vhg_config_dmgcancel dummy

scoreboard objectives add vhg_dmg_taken minecraft.custom:minecraft.damage_taken
scoreboard objectives add teleporting dummy
scoreboard objectives add vhg_target_key dummy

scoreboard players set world vhg_config_delay 0
scoreboard players set world vhg_config_dmgcancel 1

# Initialize global ID counter if it doesn't exist
execute unless score #global vhg_id matches 1.. run scoreboard players set #global vhg_id 1

# Initialize default tags, colors and limit in config storage
data modify storage vhg:config tags set value ["Home", "Farm", "Nether", "End", "Base", "Mine", "Village", "Spawn", "Temp"]
data modify storage vhg:config colors set value ["green", "gold", "red", "blue", "aqua", "yellow", "light_purple", "white", "gray"]
execute unless data storage vhg:config homes_count_limit run data modify storage vhg:config homes_count_limit set value 0

# Initialize online players' trigger scores to -1 to avoid auto-triggering on load
scoreboard players set @a sethome -1
scoreboard players set @a delhome -1
scoreboard players set @a home -1
scoreboard players set @a system -1

scoreboard players set world vhg_installation_test 3
tellraw @a {"text":"Homes Installed","color":"green"}
