scoreboard players operation @s vhg_id = #global vhg_id
scoreboard players add #global vhg_id 1

# Initialize triggers for the new player to -1
scoreboard players set @s sethome -1
scoreboard players set @s delhome -1
scoreboard players set @s home -1
scoreboard players set @s system -1
