#   Logic for /trigger home (Multi-home version)
# Copy the trigger score (which contains the ID) to a temp score
scoreboard players operation #target_id vhg_temp = @s home

# Reset trigger score to -1 (inactive state)
scoreboard players set @s home -1

# Prepare macro arguments
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id
execute store result storage vhg:homes macro_args.target_id int 1 run scoreboard players get #target_id vhg_temp

# Run the process
function vhg_data:home_process_trigger with storage vhg:homes macro_args
