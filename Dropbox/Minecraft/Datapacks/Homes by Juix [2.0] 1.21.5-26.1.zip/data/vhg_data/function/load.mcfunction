
#
#	DEFAULT
#

scoreboard objectives add vhg_installation_test dummy
execute if score world vhg_installation_test matches 3.. run tellraw @a {"text":"Homes Reloaded","color":"green"}
execute unless score world vhg_installation_test matches 3.. run function vhg_data:setup