# Macro to print a single home row in chat
# Parameters: $(id), $(tag), $(color)

$tellraw @s ["",{"text":"[","color":"dark_gray"},{"text":"TAG","color":"yellow","click_event":{"action":"run_command","command":"/trigger system set $(tag_sys_val)"},"hover_event":{"action":"show_text","value":"Change this home's tag"}},{"text":"] [","color":"dark_gray"},{"text":"COLOR","color":"light_purple","click_event":{"action":"run_command","command":"/trigger system set $(col_sys_val)"},"hover_event":{"action":"show_text","value":"Change color"}},{"text":"] [","color":"dark_gray"},{"text":"DEL","color":"red","click_event":{"action":"run_command","command":"/trigger system set $(del_sys_val)"},"hover_event":{"action":"show_text","value":"Delete this home"}},{"text":"]         [","color":"dark_gray"},{"text":"TELEPORT","color":"green","click_event":{"action":"run_command","command":"/trigger home set $(id)"},"hover_event":{"action":"show_text","value":"Teleport"}},{"text":"] ","color":"dark_gray"},{"text":"($(id)) $(tag)","color":"$(color)"}]


