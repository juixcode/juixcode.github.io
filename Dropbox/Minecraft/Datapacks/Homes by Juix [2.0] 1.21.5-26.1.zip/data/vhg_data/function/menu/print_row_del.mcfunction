# Macro to print a single home row in deletion menu
# Parameters: $(id), $(tag), $(color)

$tellraw @s ["",{"text":"[","color":"dark_gray"},{"text":"DELETE","color":"red","click_event":{"action":"run_command","command":"/trigger system set $(del_menu_sys_val)"},"hover_event":{"action":"show_text","value":"Delete this home"}},{"text":"] ","color":"dark_gray"},{"text":"($(id)) $(tag)","color":"$(color)"}]