# Recursive loop to print each home row
# Exit recursion if temp_list is empty
execute unless data storage vhg:homes temp_list[0] run return 1

# Calculate system values on the fly
execute store result score #val vhg_temp run data get storage vhg:homes temp_list[0].id
scoreboard players set #c10000 vhg_temp 10000
scoreboard players set #c20000 vhg_temp 20000
scoreboard players set #c30000 vhg_temp 30000

scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c10000 vhg_temp
execute store result storage vhg:homes temp_list[0].col_sys_val int 1 run scoreboard players get #calc vhg_temp

scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c20000 vhg_temp
execute store result storage vhg:homes temp_list[0].tag_sys_val int 1 run scoreboard players get #calc vhg_temp

scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c30000 vhg_temp
execute store result storage vhg:homes temp_list[0].del_sys_val int 1 run scoreboard players get #calc vhg_temp

# Print the first row
function vhg_data:menu/print_row with storage vhg:homes temp_list[0]

# Pop the first element from temp_list
data remove storage vhg:homes temp_list[0]

# Recurse
function vhg_data:menu/print_loop
