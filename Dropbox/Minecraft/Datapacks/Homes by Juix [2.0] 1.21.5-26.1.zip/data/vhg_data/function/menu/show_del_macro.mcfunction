# Macro helper to display the deletion menu
# Parameters: $(vhg_id)

# Clear chat slightly and print header
tellraw @s ["",{"text":"\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"},{"text":"[ ","color":"dark_gray"},{"text":"DELETE A HOME","color":"red","bold":true},{"text":" ]","color":"dark_gray"},{"text":"\n"}]

# Copy list to temp_list
$data modify storage vhg:homes temp_list set from storage vhg:homes players.p$(vhg_id).homes_list

# Call the print loop for deletion
function vhg_data:menu/print_loop_del
