# Logic to display the interactive home deletion menu
# Prepare vhg_id and call macro helper
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id
function vhg_data:menu/show_del_macro with storage vhg:homes macro_args
