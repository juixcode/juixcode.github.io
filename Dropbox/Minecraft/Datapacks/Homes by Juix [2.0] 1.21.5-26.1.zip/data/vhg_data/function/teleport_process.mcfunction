# Dedicated function to safely load home data and teleport (Zero Entity Version)
tag @s add vhg_active_player

# Prepare macro arguments with player's vhg_id
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id

# Call helper macro to copy target_home_id and proceed to TP
function vhg_data:storage/prepare_tp_args with storage vhg:homes macro_args

scoreboard players reset @s teleporting
tag @s remove vhg_active_player
