# Macro function to cycle through predefined colors for a home
# Parameters: $(vhg_id), $(home_id)

# 1. Read current color index from NBT
$execute store result score #color_idx vhg_temp run data get storage vhg:homes players.p$(vhg_id).homes_map.h$(home_id).color_idx

# 2. Increment it
scoreboard players add #color_idx vhg_temp 1

# Predefined list has 9 colors (indices 0-8)
execute if score #color_idx vhg_temp matches 9.. run scoreboard players set #color_idx vhg_temp 0

# 3. Write new color index back to map and list
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(home_id).color_idx int 1 run scoreboard players get #color_idx vhg_temp
$execute store result storage vhg:homes players.p$(vhg_id).homes_list[{id:$(home_id)}].color_idx int 1 run scoreboard players get #color_idx vhg_temp

# 4. Prepare args and apply the actual color name
execute store result storage vhg:homes macro_args.color_idx int 1 run scoreboard players get #color_idx vhg_temp
function vhg_data:storage/apply_color with storage vhg:homes macro_args
