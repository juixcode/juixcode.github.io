# Macro function to delete a specific home
# Parameters: $(vhg_id), $(del_id)

# Remove from map and list
$data remove storage vhg:homes players.p$(vhg_id).homes_map.h$(del_id)
$data remove storage vhg:homes players.p$(vhg_id).homes_list[{id:$(del_id)}]

# Decrement the count
$execute store result score #count vhg_temp run data get storage vhg:homes players.p$(vhg_id).count
scoreboard players remove #count vhg_temp 1
$execute store result storage vhg:homes players.p$(vhg_id).count int 1 run scoreboard players get #count vhg_temp

# If the count is now 0, reset home_key scoreboard of the player
execute if score #count vhg_temp matches 0 run scoreboard players reset @s home_key

$title @s actionbar {"text":"Home #$(del_id) successfully deleted","color":"red"}

# Redraw the menu based on the show_menu_after_del flag if they still have homes left
execute if score #count vhg_temp matches 1.. if score #show_menu_after_del vhg_temp matches 1 run function vhg_data:menu/show
execute if score #count vhg_temp matches 1.. if score #show_menu_after_del vhg_temp matches 2 run function vhg_data:menu/show_del
