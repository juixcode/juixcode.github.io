# Macro function to apply a tag string to a home
# Parameters: $(vhg_id), $(home_id), $(tag_idx)

# Set the tag name from config
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h$(home_id).tag set from storage vhg:config tags[$(tag_idx)]
$data modify storage vhg:homes players.p$(vhg_id).homes_list[{id:$(home_id)}].tag set from storage vhg:config tags[$(tag_idx)]

# Refresh the menu display
function vhg_data:menu/show
