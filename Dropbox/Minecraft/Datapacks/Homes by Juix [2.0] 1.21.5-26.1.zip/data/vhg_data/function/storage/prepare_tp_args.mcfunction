# Macro to copy target_home_id from the player NBT to macro_args
# Parameters: $(vhg_id)

$data modify storage vhg:homes macro_args.target_home_id set from storage vhg:homes players.p$(vhg_id).target_home_id

# Now load and tp
function vhg_data:storage/load_and_tp with storage vhg:homes macro_args
