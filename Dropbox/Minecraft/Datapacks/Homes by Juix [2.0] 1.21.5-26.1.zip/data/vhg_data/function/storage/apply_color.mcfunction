# Macro function to apply a color string to a home
# Parameters: $(vhg_id), $(home_id), $(color_idx)

# Set the color name from config
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h$(home_id).color set from storage vhg:config colors[$(color_idx)]
$data modify storage vhg:homes players.p$(vhg_id).homes_list[{id:$(home_id)}].color set from storage vhg:config colors[$(color_idx)]

# Refresh the menu display
function vhg_data:menu/show
