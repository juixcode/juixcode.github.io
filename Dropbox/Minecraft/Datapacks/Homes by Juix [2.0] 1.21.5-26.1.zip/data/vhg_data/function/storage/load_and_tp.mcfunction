# Load home data for a specific player and target_home_id, then call the TP macro
# Parameters: $(vhg_id), $(target_home_id)

$execute at @s run function vhg_data:storage/tp_macro with storage vhg:homes players.p$(vhg_id).homes_map.h$(target_home_id)
