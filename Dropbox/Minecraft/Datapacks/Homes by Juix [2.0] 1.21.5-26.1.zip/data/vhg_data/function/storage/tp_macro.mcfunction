# Departure Effects
particle minecraft:end_rod ~ ~0.8 ~ 0.2 0.5 0.2 0.1 25 normal
playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ 1 1

# The actual teleport command using macro values
$execute in $(dim) run tp @s $(x) $(y) $(z) $(yaw) $(pitch)

# Arrival Effects (at the new location)
execute at @s run particle minecraft:end_rod ~ ~0.8 ~ 0.2 0.5 0.2 0.1 25 normal
execute at @s run playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ 1 1
