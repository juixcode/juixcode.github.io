# Macro function to save player home to storage (Rounded Coordinates)
# Parameters: $(vhg_id), $(new_id)

# Initialize the new home entry in homes_map
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id) set value {id:$(new_id),x:0,y:0,z:0,dim:"",yaw:0f,pitch:0f,tag:"Home",color:"white",tag_idx:0,color_idx:7}

# Store X, Y, Z as integers (rounds down/truncates)
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).x int 1 run data get entity @s Pos[0]
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).y int 1 run data get entity @s Pos[1]
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).z int 1 run data get entity @s Pos[2]

# Store dimension and rotation
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).dim set from entity @s Dimension
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).yaw set from entity @s Rotation[0]
$data modify storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).pitch set from entity @s Rotation[1]

# Calculate and store the unified system trigger values
scoreboard players set #c10000 vhg_temp 10000
scoreboard players set #c20000 vhg_temp 20000
scoreboard players set #c30000 vhg_temp 30000
scoreboard players set #c40000 vhg_temp 40000

scoreboard players set #val vhg_temp 0
$execute store result score #val vhg_temp run data get storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).id

# col_sys_val
scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c10000 vhg_temp
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).col_sys_val int 1 run scoreboard players get #calc vhg_temp

# tag_sys_val
scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c20000 vhg_temp
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).tag_sys_val int 1 run scoreboard players get #calc vhg_temp

# del_sys_val
scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c30000 vhg_temp
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).del_sys_val int 1 run scoreboard players get #calc vhg_temp

# del_menu_sys_val
scoreboard players operation #calc vhg_temp = #val vhg_temp
scoreboard players operation #calc vhg_temp += #c40000 vhg_temp
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id).del_menu_sys_val int 1 run scoreboard players get #calc vhg_temp

# Copy the saved home from homes_map to homes_list
$data modify storage vhg:homes players.p$(vhg_id).homes_list append from storage vhg:homes players.p$(vhg_id).homes_map.h$(new_id)

$title @s actionbar {"text":"Home #$(new_id) successfully set","color":"green"}

