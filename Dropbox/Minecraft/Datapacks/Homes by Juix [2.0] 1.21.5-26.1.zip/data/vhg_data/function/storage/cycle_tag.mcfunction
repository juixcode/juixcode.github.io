# Macro function to cycle through predefined tags for a home
# Parameters: $(vhg_id), $(home_id)

# 1. Read current tag index from NBT
$execute store result score #tag_idx vhg_temp run data get storage vhg:homes players.p$(vhg_id).homes_map.h$(home_id).tag_idx

# 2. Increment it
scoreboard players add #tag_idx vhg_temp 1

# Predefined list has 9 tags (indices 0-8)
execute if score #tag_idx vhg_temp matches 9.. run scoreboard players set #tag_idx vhg_temp 0

# 3. Write new tag index back to map and list
$execute store result storage vhg:homes players.p$(vhg_id).homes_map.h$(home_id).tag_idx int 1 run scoreboard players get #tag_idx vhg_temp
$execute store result storage vhg:homes players.p$(vhg_id).homes_list[{id:$(home_id)}].tag_idx int 1 run scoreboard players get #tag_idx vhg_temp

# 4. Prepare args and apply the actual tag name
execute store result storage vhg:homes macro_args.tag_idx int 1 run scoreboard players get #tag_idx vhg_temp
function vhg_data:storage/apply_tag with storage vhg:homes macro_args
