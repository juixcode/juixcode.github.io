#   Logic for /trigger sethome (Multi-home version)
# Reset trigger score to -1 (inactive state)
scoreboard players set @s sethome -1

# Prepare macro arguments
execute store result storage vhg:homes macro_args.vhg_id int 1 run scoreboard players get @s vhg_id

# Call sethome_process with vhg_id
function vhg_data:sethome_process with storage vhg:homes macro_args
