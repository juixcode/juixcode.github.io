# Macro function to process home deletion logic
# Parameters: $(vhg_id), $(del_id)

# 1. Get the player's home count (safety initialized to 0)
scoreboard players set #count vhg_temp 0
$execute store result score #count vhg_temp run data get storage vhg:homes players.p$(vhg_id).count

# If the player has no homes (count is 0 or undefined)
execute if score #count vhg_temp matches ..0 run tellraw @s ["",{"text":"You don't have any home !","color":"red"},{"text":"\n"},{"text":"/trigger sethome","color":"yellow","click_event":{"action":"suggest_command","command":"/trigger sethome"}}]

# If the player has exactly 1 home
execute if score #count vhg_temp matches 1 run function vhg_data:delhome_process_single_home with storage vhg:homes macro_args

# If the player has multiple homes (>= 2)
execute if score #count vhg_temp matches 2.. run function vhg_data:delhome_process_multi_homes with storage vhg:homes macro_args
