scoreboard objectives remove sethome
scoreboard objectives remove delhome
scoreboard objectives remove home

scoreboard objectives remove system

scoreboard objectives remove home_key
scoreboard objectives remove home_key_time

scoreboard objectives remove vhg_config_delay
scoreboard objectives remove vhg_config_dmgcancel
scoreboard objectives remove vhg_dmg_taken
scoreboard objectives remove teleporting
scoreboard objectives remove vhg_target_key

scoreboard objectives remove vhg_installation_test

# Clean up player tags
tag @a remove vhg_migrated
tag @a remove vhg_active_migration
tag @a remove vhg_active_player

# Clean up legacy entities
kill @e[tag=home_point]

# Clean up NBT storages
data remove storage vhg:homes players
data remove storage vhg:homes macro_args
data remove storage vhg:homes temp_list
data remove storage vhg:config tags
data remove storage vhg:config colors
data remove storage vhg:config homes_count_limit

tellraw @a {"text":"Uninstalled Homes","color":"red"}
datapack disable "file/Homes by Juix [2.0] 1.21.5-26.1"
datapack disable "file/Homes by Juix [2.0] 1.21.5-26.1.zip"