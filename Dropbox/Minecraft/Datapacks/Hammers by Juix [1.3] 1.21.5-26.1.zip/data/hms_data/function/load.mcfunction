#Created in Minecraft version 1.20.2
#By Juju

#
#	DEFAULT
#

scoreboard objectives add hammers_installation_test dummy
execute if score world hammers_installation_test matches 1.. run tellraw @a {"text":"Hammers Reloaded","color":"green"}
execute unless score world hammers_installation_test matches 1.. run function hms_data:setup