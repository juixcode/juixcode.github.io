# Arrêt du hammer - quand le joueur ne tient plus un hammer
effect clear @s minecraft:mining_fatigue
tag @s remove vh_hammer
