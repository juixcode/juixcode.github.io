recipe take @s minecraft:netherite_pickaxe_smithing
tag @s add hms_init_player