execute if block ~ ~ ~ nether_gold_ore run summon experience_orb ~ ~ ~ {Value:1}

execute if block ~ ~ ~ lapis_ore run summon experience_orb ~ ~ ~ {Value:3}
execute if block ~ ~ ~ deepslate_lapis_ore run summon experience_orb ~ ~ ~ {Value:3}
execute if block ~ ~ ~ nether_quartz_ore run summon experience_orb ~ ~ ~ {Value:4}

execute if block ~ ~ ~ diamond_ore run summon experience_orb ~ ~ ~ {Value:5}
execute if block ~ ~ ~ deepslate_diamond_ore run summon experience_orb ~ ~ ~ {Value:5}
execute if block ~ ~ ~ emerald_ore run summon experience_orb ~ ~ ~ {Value:5}
execute if block ~ ~ ~ deepslate_emerald_ore run summon experience_orb ~ ~ ~ {Value:5}

execute unless block ~ ~ ~ #hms_data:protected_blocks run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
execute unless block ~ ~ ~ #hms_data:protected_blocks run setblock ~ ~ ~ air