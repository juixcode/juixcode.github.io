execute at @e[sort=nearest,limit=1,type=item,distance=..6,tag=!vh_mined] run summon minecraft:marker ~ ~ ~ {Tags:["pos_hammer_d2"]}

execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~-1 ~-1 ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~-1 ~ ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~ ~-1 ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~-1 ~1 ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~1 ~-1 ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~1 ~ ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~ ~1 ~ run function hms_data:mine/block
execute at @e[tag=pos_hammer_d2,sort=nearest,limit=1] run execute positioned ~1 ~1 ~ run function hms_data:mine/block

kill @e[tag=pos_hammer_d2,sort=nearest,limit=1]