#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=4}] run function hms_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function hms_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function hms_data:recipes/show_links

#   NETHERITE ADVANCEMENT INIT
execute as @a[tag=!hms_init_player] run function hms_data:init_player

#   HAMMERS

execute as @a[tag=!vh_hammer] if items entity @s weapon.mainhand netherite_pickaxe[custom_model_data={floats:[100]}] run tag @s add vh_hammer
execute as @a[tag=!vh_hammer] if items entity @s weapon.mainhand diamond_pickaxe[custom_model_data={floats:[100]}] run tag @s add vh_hammer
execute as @a[tag=!vh_hammer] if items entity @s weapon.mainhand golden_pickaxe[custom_model_data={floats:[100]}] run tag @s add vh_hammer
execute as @a[tag=!vh_hammer] if items entity @s weapon.mainhand iron_pickaxe[custom_model_data={floats:[100]}] run tag @s add vh_hammer

execute as @a[tag=vh_hammer] run function hms_data:mined_blocks
execute as @a[tag=vh_hammer] unless items entity @s weapon.mainhand netherite_pickaxe[custom_model_data={floats:[100]}] unless items entity @s weapon.mainhand diamond_pickaxe[custom_model_data={floats:[100]}] unless items entity @s weapon.mainhand golden_pickaxe[custom_model_data={floats:[100]}] unless items entity @s weapon.mainhand iron_pickaxe[custom_model_data={floats:[100]}] run function hms_data:stop_hammer

execute as @a[scores={mined_blocks=1..},tag=vh_hammer] at @s run function hms_data:vanilla_hammers
execute as @a[tag=vh_hammer] at @s run tag @e[type=item,tag=!vh_mined,distance=..6] add vh_mined
scoreboard players reset @a[scores={mined_blocks=1..}] mined_blocks

execute as @a[scores={use_iron_hammer=1..}] run scoreboard players reset @s use_iron_hammer
execute as @a[scores={use_golden_hammer=1..}] run scoreboard players reset @s use_golden_hammer
execute as @a[scores={use_diamond_hammer=1..}] run scoreboard players reset @s use_diamond_hammer
execute as @a[scores={use_netherite_hammer=1..}] run scoreboard players reset @s use_netherite_hammer

#	MINING SPEED

execute as @a[tag=vh_hammer] unless entity @s[nbt={active_effects:[{id:"minecraft:mining_fatigue"}]}] run effect give @s minecraft:mining_fatigue 999999 0 true

#   NETHERITE TOOL NAME REPLACEMENT

execute as @a[tag=hms_smithing] run execute if items entity @s container.* minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[100]},minecraft:item_name={"text":"Diamond Hammer","italic":false}] run function hms_data:netherite_tool_name_replace