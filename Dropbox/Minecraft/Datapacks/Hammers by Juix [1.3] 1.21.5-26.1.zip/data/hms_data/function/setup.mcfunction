scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

scoreboard objectives add mined_blocks dummy
scoreboard objectives add use_iron_hammer minecraft.used:minecraft.iron_pickaxe
scoreboard objectives add use_golden_hammer minecraft.used:minecraft.golden_pickaxe
scoreboard objectives add use_netherite_hammer minecraft.used:minecraft.netherite_pickaxe
scoreboard objectives add use_diamond_hammer minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add hms_smithing_test dummy

scoreboard players set world hammers_installation_test 1
tellraw @a {"text":"Hammers Installed","color":"green"}