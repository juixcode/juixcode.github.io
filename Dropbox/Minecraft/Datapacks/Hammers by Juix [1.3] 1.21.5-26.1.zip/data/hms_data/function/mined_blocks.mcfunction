execute as @s[scores={use_iron_hammer=1..}] run scoreboard players add @s mined_blocks 1
execute as @s[scores={use_golden_hammer=1..}] run scoreboard players add @s mined_blocks 1
execute as @s[scores={use_diamond_hammer=1..}] run scoreboard players add @s mined_blocks 1
execute as @s[scores={use_netherite_hammer=1..}] run scoreboard players add @s mined_blocks 1