# UP DOWN / LEFT RIGHT / FRONT BACK

execute as @s[x_rotation=45..90] run function hms_data:mine/type1
execute as @s[x_rotation=-90..-45] run function hms_data:mine/type1
execute as @s[x_rotation=-45..45,y_rotation=135..-135] run function hms_data:mine/type2
execute as @s[x_rotation=-45..45,y_rotation=-45..45] run function hms_data:mine/type2
execute as @s[x_rotation=-45..45,y_rotation=45..135] run function hms_data:mine/type3
execute as @s[x_rotation=-45..45,y_rotation=-135..-45] run function hms_data:mine/type3