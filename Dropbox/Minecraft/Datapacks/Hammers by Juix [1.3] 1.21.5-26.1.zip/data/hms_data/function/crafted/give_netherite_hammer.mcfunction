recipe take @s minecraft:netherite_pickaxe_smithing
advancement revoke @s only hms_data:netherite_hammer_adv

execute as @s store result score @s hms_smithing_test run clear @s minecraft:netherite_pickaxe[minecraft:custom_model_data={floats:[100]},minecraft:item_name={"text":"Diamond Hammer","italic":false}] 0
execute as @s[scores={hms_smithing_test=1..}] run tag @s add hms_smithing