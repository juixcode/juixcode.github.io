
scoreboard objectives remove mined_blocks
scoreboard objectives remove use_iron_hammer
scoreboard objectives remove use_golden_hammer
scoreboard objectives remove use_diamond_hammer
scoreboard objectives remove use_netherite_hammer
scoreboard objectives remove hms_smithing_test

scoreboard objectives remove hammers_installation_test

tellraw @a {"text":"Uninstalled Hammers","color":"red"}
datapack disable "file/Hammers by Juix [1.3] 1.21.5-26.1"
datapack disable "file/Hammers by Juix [1.3] 1.21.5-26.1.zip"