
#
#	DEFAULT
#

scoreboard objectives add excavators_installation_test dummy
execute if score world excavators_installation_test matches 1.. run tellraw @a {"text":"Excavators Reloaded","color":"green"}
execute unless score world excavators_installation_test matches 1.. run function xrs_data:setup

#   RECIPES WARNING

execute unless data storage juix:warning {loaded:true} run schedule function juix:warning 1t replace
data modify storage juix:warning loaded set value true