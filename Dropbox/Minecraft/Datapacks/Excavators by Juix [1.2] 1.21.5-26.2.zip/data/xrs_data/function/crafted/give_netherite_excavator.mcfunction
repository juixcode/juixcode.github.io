advancement revoke @s only xrs_data:netherite_excavator_adv

execute as @s store result score @s xrs_smithing_test run clear @s minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] 0
execute as @s[scores={xrs_smithing_test=1..}] run tag @s add xrs_smithing
execute as @s[tag=xrs_smithing] run function xrs_data:netherite_tool_name_replace