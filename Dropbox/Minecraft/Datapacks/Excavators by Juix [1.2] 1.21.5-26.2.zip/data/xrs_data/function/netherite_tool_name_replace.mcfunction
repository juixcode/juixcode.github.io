execute if items entity @s hotbar.0 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.0 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.1 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.1 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.2 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.2 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.3 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.3 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.4 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.4 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.5 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.5 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.6 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.6 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.7 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.7 xrs_data:netherite_shovel_modifier
execute if items entity @s hotbar.8 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s hotbar.8 xrs_data:netherite_shovel_modifier

execute if items entity @s inventory.0 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.0 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.1 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.1 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.2 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.2 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.3 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.3 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.4 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.4 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.5 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.5 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.6 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.6 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.7 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.7 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.8 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.8 xrs_data:netherite_shovel_modifier

execute if items entity @s inventory.9 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.9 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.10 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.10 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.11 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.11 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.12 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.12 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.13 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.13 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.14 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.14 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.15 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.15 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.16 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.16 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.17 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.17 xrs_data:netherite_shovel_modifier

execute if items entity @s inventory.18 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.18 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.19 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.19 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.20 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.20 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.21 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.21 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.22 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.22 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.23 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.23 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.24 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.24 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.25 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.25 xrs_data:netherite_shovel_modifier
execute if items entity @s inventory.26 minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s inventory.26 xrs_data:netherite_shovel_modifier

execute if items entity @s weapon.offhand minecraft:netherite_shovel[minecraft:custom_data~{xrs_diamond_excavator:true}] run item modify entity @s weapon.offhand xrs_data:netherite_shovel_modifier

tag @s remove xrs_smithing