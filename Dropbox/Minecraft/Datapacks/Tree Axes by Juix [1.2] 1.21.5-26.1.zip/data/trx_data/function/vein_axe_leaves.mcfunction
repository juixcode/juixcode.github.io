# BOTTOM LAYER
execute positioned ~-1 ~-1 ~-1 run function trx_data:mine/leaves
execute positioned ~ ~-1 ~-1 run function trx_data:mine/leaves
execute positioned ~1 ~-1 ~-1 run function trx_data:mine/leaves
execute positioned ~-1 ~-1 ~ run function trx_data:mine/leaves
execute positioned ~ ~-1 ~ run function trx_data:mine/leaves
execute positioned ~1 ~-1 ~ run function trx_data:mine/leaves
execute positioned ~-1 ~-1 ~1 run function trx_data:mine/leaves
execute positioned ~ ~-1 ~1 run function trx_data:mine/leaves
execute positioned ~1 ~-1 ~1 run function trx_data:mine/leaves

# MIDDLE LAYER
execute positioned ~-1 ~ ~-1 run function trx_data:mine/leaves
execute positioned ~ ~ ~-1 run function trx_data:mine/leaves
execute positioned ~1 ~ ~-1 run function trx_data:mine/leaves
execute positioned ~-1 ~ ~ run function trx_data:mine/leaves
execute positioned ~1 ~ ~ run function trx_data:mine/leaves
execute positioned ~-1 ~ ~1 run function trx_data:mine/leaves
execute positioned ~ ~ ~1 run function trx_data:mine/leaves
execute positioned ~1 ~ ~1 run function trx_data:mine/leaves

# TOP LAYER
execute positioned ~-1 ~1 ~-1 run function trx_data:mine/leaves
execute positioned ~ ~1 ~-1 run function trx_data:mine/leaves
execute positioned ~1 ~1 ~-1 run function trx_data:mine/leaves
execute positioned ~-1 ~1 ~ run function trx_data:mine/leaves
execute positioned ~ ~1 ~ run function trx_data:mine/leaves
execute positioned ~1 ~1 ~ run function trx_data:mine/leaves
execute positioned ~-1 ~1 ~1 run function trx_data:mine/leaves
execute positioned ~ ~1 ~1 run function trx_data:mine/leaves
execute positioned ~1 ~1 ~1 run function trx_data:mine/leaves