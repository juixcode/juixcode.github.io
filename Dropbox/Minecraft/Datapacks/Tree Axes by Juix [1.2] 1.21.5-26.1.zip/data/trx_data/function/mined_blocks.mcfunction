execute as @s[scores={trx_use_iron_axe=1..}] run scoreboard players add @s trx_mined_blocks 1
execute as @s[scores={trx_use_golden_axe=1..}] run scoreboard players add @s trx_mined_blocks 1
execute as @s[scores={trx_use_diamond_axe=1..}] run scoreboard players add @s trx_mined_blocks 1
execute as @s[scores={trx_use_netherite_axe=1..}] run scoreboard players add @s trx_mined_blocks 1
