
#
#	DEFAULT
#

scoreboard objectives add tree_axes_installation_test dummy
execute if score world tree_axes_installation_test matches 2.. run tellraw @a {"text":"Tree Axes Reloaded","color":"green"}
execute unless score world tree_axes_installation_test matches 2.. run function trx_data:setup