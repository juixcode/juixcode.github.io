# BOTTOM LAYER
execute positioned ~ ~-1 ~ run function trx_data:mine/block
execute positioned ~-1 ~-1 ~ run function trx_data:mine/block
execute positioned ~ ~-1 ~-1 run function trx_data:mine/block
execute positioned ~1 ~-1 ~ run function trx_data:mine/block
execute positioned ~ ~-1 ~1 run function trx_data:mine/block

# MIDDLE LAYER
execute positioned ~-1 ~ ~ run function trx_data:mine/block
execute positioned ~-1 ~ ~-1 run function trx_data:mine/block
execute positioned ~ ~ ~-1 run function trx_data:mine/block
execute positioned ~1 ~ ~-1 run function trx_data:mine/block
execute positioned ~1 ~ ~ run function trx_data:mine/block
execute positioned ~1 ~ ~1 run function trx_data:mine/block
execute positioned ~ ~ ~1 run function trx_data:mine/block
execute positioned ~-1 ~ ~1 run function trx_data:mine/block

# TOP LAYER
execute positioned ~ ~1 ~ run function trx_data:mine/block
execute positioned ~-1 ~1 ~ run function trx_data:mine/block
execute positioned ~ ~1 ~-1 run function trx_data:mine/block
execute positioned ~1 ~1 ~ run function trx_data:mine/block
execute positioned ~ ~1 ~1 run function trx_data:mine/block