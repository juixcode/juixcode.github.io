execute as @p[tag=trx_holding_tree_axe,scores={trx_mined_blocks=1..}] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air

playsound minecraft:block.stone.break block @a ~ ~ ~ 1 1

function trx_data:vein_axe