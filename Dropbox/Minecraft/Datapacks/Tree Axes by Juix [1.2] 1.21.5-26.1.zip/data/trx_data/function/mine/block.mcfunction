#   ORES

execute if block ~ ~ ~ #minecraft:logs run function trx_data:mine/loot_block

execute if score world trx_option_leaves_breaking matches 1.. run function trx_data:mine/leaves