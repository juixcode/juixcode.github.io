execute if score world trx_leaf_count matches 5.. run return 0

#   LEAVES

execute if block ~ ~ ~ #minecraft:leaves run function trx_data:mine/loot_leaves