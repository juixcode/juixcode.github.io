execute as @p[tag=trx_holding_tree_axe,scores={trx_mined_blocks=1..}] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air

playsound minecraft:block.leaf_litter.break block @a ~ ~ ~ 1 1

scoreboard players add world trx_leaf_count 1
function trx_data:vein_axe_leaves
scoreboard players remove world trx_leaf_count 1