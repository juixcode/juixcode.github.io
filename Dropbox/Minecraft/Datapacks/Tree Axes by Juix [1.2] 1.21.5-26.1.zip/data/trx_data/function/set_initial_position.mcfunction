# Validation du drop pour les arbres
execute unless items entity @e[type=item,distance=..1,limit=1,sort=nearest] contents #trx_data:valid_tree_drops run return 0

# Création de l'ancre pour la récursion
scoreboard players set world trx_leaf_count 0
execute align xyz positioned ~0.5 ~0.5 ~0.5 run function trx_data:vein_axe
