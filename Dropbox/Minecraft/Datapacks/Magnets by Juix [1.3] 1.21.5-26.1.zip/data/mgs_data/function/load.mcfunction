#Created in Minecraft version 1.20.2
#By Juju

#
#	DEFAULT
#

scoreboard objectives add magnets_installation_test dummy
execute if score world magnets_installation_test matches 1.. run tellraw @a {"text":"Magnets Reloaded","color":"green"}
execute unless score world magnets_installation_test matches 1.. run function mgs_data:setup