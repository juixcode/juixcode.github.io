#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=6}] run function mgs_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function mgs_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function mgs_data:recipes/show_links

#   TREE AXE & HAMMER PROTECTION

tag @a[tag=vh_hammer] add restricted_tool
tag @a[tag=tree_axe] add restricted_tool
tag @a[tag=juix_restricted_tool] add restricted_tool

tag @a[tag=!juix_restricted_tool,tag=!tree_axe,tag=!vh_hammer] remove restricted_tool

tag @e[type=item,tag=vh_mined,tag=!teleportable_item] add teleportable_item
tag @e[type=item,tag=tree_axe_innocent,tag=!teleportable_item] add teleportable_item
tag @e[type=item,tag=juix_teleportable_item,tag=!teleportable_item] add teleportable_item

#	MAGNET

execute as @a[tag=!restricted_tool] if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[100]}] at @s run tp @e[type=item,distance=..4] ~ ~ ~
execute as @a[tag=restricted_tool] if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[100]}] at @s run tp @e[type=item,distance=..4,tag=teleportable_item] ~ ~ ~

execute as @a if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[100]}] at @s run tp @e[type=experience_orb,distance=..4] ~ ~ ~

#	SUPER MAGNET

execute as @a[tag=!restricted_tool] if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[101]}] at @s run tp @e[type=item,distance=..8] ~ ~ ~
execute as @a[tag=restricted_tool] if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[101]}] at @s run tp @e[type=item,distance=..6,tag=teleportable_item] ~ ~ ~

execute as @a if items entity @s weapon.* minecraft:paper[custom_model_data={floats:[101]}] at @s run tp @e[type=experience_orb,distance=..8] ~ ~ ~