scoreboard objectives add show_recipes trigger
scoreboard objectives add show_recipes_weblinks trigger
scoreboard objectives add juix_recipes_tellraw_id dummy

#
#	DEFAULT
#

scoreboard players set world magnets_installation_test 1
tellraw @a {"text":"Magnets Installed","color":"green"}