# Force la réapplication du modifier de vitesse sur TOUS les items au sol simple_food
# Utilisé uniquement quand la vitesse de consommation change.
# Cible tous les items simple_food même déjà marqués.

# On utilise le prédicat is_food (tous les simple_food, marqués ou non)
execute if score world fse_option_eating_time matches 0 as @e[type=item,distance=..64,predicate=fse_data:is_food] run item modify entity @s contents fse_data:speed_0
execute if score world fse_option_eating_time matches 1 as @e[type=item,distance=..64,predicate=fse_data:is_food] run item modify entity @s contents fse_data:speed_1
execute if score world fse_option_eating_time matches 2 as @e[type=item,distance=..64,predicate=fse_data:is_food] run item modify entity @s contents fse_data:speed_2
execute if score world fse_option_eating_time matches 3 as @e[type=item,distance=..64,predicate=fse_data:is_food] run item modify entity @s contents fse_data:speed_3
