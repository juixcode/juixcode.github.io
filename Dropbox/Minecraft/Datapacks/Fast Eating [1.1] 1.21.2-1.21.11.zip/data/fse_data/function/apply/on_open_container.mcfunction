# Révoquer l'advancement immédiatement pour que le trigger se re-déclenche
advancement revoke @s only fse_data:open_container

# Raycast : on exécute le scan à la position du bloc regardé par le joueur (6 blocs maximum (portée d'interaction d'un joueur))
execute anchored eyes positioned ^ ^ ^0 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
execute anchored eyes positioned ^ ^ ^1 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
execute anchored eyes positioned ^ ^ ^2 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
execute anchored eyes positioned ^ ^ ^3 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
execute anchored eyes positioned ^ ^ ^4 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
execute anchored eyes positioned ^ ^ ^5 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
execute anchored eyes positioned ^ ^ ^6 if block ~ ~ ~ #fse_data:containers run function fse_data:apply/container
