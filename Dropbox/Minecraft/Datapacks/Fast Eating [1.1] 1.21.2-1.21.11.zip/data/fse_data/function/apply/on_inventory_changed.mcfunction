# Révoquer pour re-déclencher au prochain changement
advancement revoke @s only fse_data:inventory_changed

# Scanner l'inventaire (ne traite que les items non marqués)
function fse_data:apply/inventory
