# Modifie les items au sol (entités item) autour du joueur
# Ne cible que les items non marqués {fse:1b} correspondant au tag simple_food

# On utilise le prédicat is_unmarked_food pour ne cibler que les items non encore traités
execute if score world fse_option_eating_time matches 0 as @e[type=item,distance=..10,predicate=fse_data:is_unmarked_food] run item modify entity @s contents fse_data:speed_0
execute if score world fse_option_eating_time matches 1 as @e[type=item,distance=..10,predicate=fse_data:is_unmarked_food] run item modify entity @s contents fse_data:speed_1
execute if score world fse_option_eating_time matches 2 as @e[type=item,distance=..10,predicate=fse_data:is_unmarked_food] run item modify entity @s contents fse_data:speed_2
execute if score world fse_option_eating_time matches 3 as @e[type=item,distance=..10,predicate=fse_data:is_unmarked_food] run item modify entity @s contents fse_data:speed_3
