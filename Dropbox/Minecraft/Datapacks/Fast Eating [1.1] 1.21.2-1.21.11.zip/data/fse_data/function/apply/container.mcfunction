# Scanne les 27 slots d'un conteneur simple (coffre, tonneau, etc.)
# Exécuté à la position du conteneur que le joueur regarde
# Chaque slot est vérifié individuellement via container_slot/slot_X

function fse_data:apply/container_slot/slot_0
function fse_data:apply/container_slot/slot_1
function fse_data:apply/container_slot/slot_2
function fse_data:apply/container_slot/slot_3
function fse_data:apply/container_slot/slot_4
function fse_data:apply/container_slot/slot_5
function fse_data:apply/container_slot/slot_6
function fse_data:apply/container_slot/slot_7
function fse_data:apply/container_slot/slot_8
function fse_data:apply/container_slot/slot_9
function fse_data:apply/container_slot/slot_10
function fse_data:apply/container_slot/slot_11
function fse_data:apply/container_slot/slot_12
function fse_data:apply/container_slot/slot_13
function fse_data:apply/container_slot/slot_14
function fse_data:apply/container_slot/slot_15
function fse_data:apply/container_slot/slot_16
function fse_data:apply/container_slot/slot_17
function fse_data:apply/container_slot/slot_18
function fse_data:apply/container_slot/slot_19
function fse_data:apply/container_slot/slot_20
function fse_data:apply/container_slot/slot_21
function fse_data:apply/container_slot/slot_22
function fse_data:apply/container_slot/slot_23
function fse_data:apply/container_slot/slot_24
function fse_data:apply/container_slot/slot_25
function fse_data:apply/container_slot/slot_26
