# Force la réapplication du modifier de vitesse sur TOUS les items simple_food
# dans l'inventaire du joueur, même ceux déjà marqués.
# Utilisé uniquement quand la vitesse de consommation change.

# === HOTBAR (slots 0-8) ===
execute if items entity @s hotbar.0 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_0
execute if items entity @s hotbar.1 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_1
execute if items entity @s hotbar.2 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_2
execute if items entity @s hotbar.3 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_3
execute if items entity @s hotbar.4 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_4
execute if items entity @s hotbar.5 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_5
execute if items entity @s hotbar.6 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_6
execute if items entity @s hotbar.7 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_7
execute if items entity @s hotbar.8 #fse_data:simple_food run function fse_data:apply/inv_slot/hotbar_8

# === INVENTORY (slots 0-26) ===
execute if items entity @s inventory.0 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_0
execute if items entity @s inventory.1 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_1
execute if items entity @s inventory.2 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_2
execute if items entity @s inventory.3 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_3
execute if items entity @s inventory.4 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_4
execute if items entity @s inventory.5 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_5
execute if items entity @s inventory.6 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_6
execute if items entity @s inventory.7 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_7
execute if items entity @s inventory.8 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_8
execute if items entity @s inventory.9 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_9
execute if items entity @s inventory.10 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_10
execute if items entity @s inventory.11 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_11
execute if items entity @s inventory.12 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_12
execute if items entity @s inventory.13 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_13
execute if items entity @s inventory.14 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_14
execute if items entity @s inventory.15 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_15
execute if items entity @s inventory.16 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_16
execute if items entity @s inventory.17 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_17
execute if items entity @s inventory.18 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_18
execute if items entity @s inventory.19 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_19
execute if items entity @s inventory.20 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_20
execute if items entity @s inventory.21 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_21
execute if items entity @s inventory.22 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_22
execute if items entity @s inventory.23 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_23
execute if items entity @s inventory.24 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_24
execute if items entity @s inventory.25 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_25
execute if items entity @s inventory.26 #fse_data:simple_food run function fse_data:apply/inv_slot/inventory_26

# === OFFHAND ===
execute if items entity @s weapon.offhand #fse_data:simple_food run function fse_data:apply/inv_slot/offhand
