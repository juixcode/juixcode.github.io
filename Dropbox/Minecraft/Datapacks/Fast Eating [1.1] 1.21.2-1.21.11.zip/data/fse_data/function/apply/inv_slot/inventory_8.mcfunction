# Applique le modifier de vitesse au slot inventory.8 du joueur
execute if score world fse_option_eating_time matches 0 run item modify entity @s inventory.8 fse_data:speed_0
execute if score world fse_option_eating_time matches 1 run item modify entity @s inventory.8 fse_data:speed_1
execute if score world fse_option_eating_time matches 2 run item modify entity @s inventory.8 fse_data:speed_2
execute if score world fse_option_eating_time matches 3 run item modify entity @s inventory.8 fse_data:speed_3