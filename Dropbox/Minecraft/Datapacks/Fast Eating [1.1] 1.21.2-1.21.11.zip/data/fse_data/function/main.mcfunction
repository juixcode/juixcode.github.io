
# === DETECTEUR D'ITEMS AU SOL (toutes les 4 ticks) ===
scoreboard players add world fse_tick_counter 1

execute if score world fse_tick_counter matches 4.. as @a[gamemode=!spectator] at @s run function fse_data:apply/ground_items
execute if score world fse_tick_counter matches 4.. run scoreboard players set world fse_tick_counter 0
