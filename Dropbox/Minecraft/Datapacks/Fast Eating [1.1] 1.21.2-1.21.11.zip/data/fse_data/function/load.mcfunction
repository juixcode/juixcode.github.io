
scoreboard objectives add fast_eating_installation_test dummy
scoreboard objectives add fse_tick_counter dummy

execute if score world fast_eating_installation_test matches 2.. run tellraw @a {"text":"Fast Eating Reloaded","color":"green"}
execute unless score world fast_eating_installation_test matches 2.. run function fse_data:setup