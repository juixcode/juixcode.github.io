
# Créer les scoreboards
scoreboard objectives add fse_option_eating_time dummy
scoreboard objectives add fse_tick_counter dummy

# Vitesse par défaut : 1 (0.8s)
scoreboard players set world fse_option_eating_time 1

# Initialiser le compteur de ticks
scoreboard players set world fse_tick_counter 0

# Marquer l'installation comme terminée
scoreboard players set world fast_eating_installation_test 2
tellraw @a {"text":"Fast Eating Installed","color":"green"}