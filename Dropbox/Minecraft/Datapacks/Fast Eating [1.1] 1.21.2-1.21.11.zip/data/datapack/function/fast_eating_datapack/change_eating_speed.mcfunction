#
# CHANGE EATING SPEED - Fast Eating
# Cycle entre les 4 vitesses de consommation : 1.6s → 0.8s → 0.4s → 0.0s → 1.6s → ...
# Quand on change de vitesse, on force la réapplication sur tous les items
# dans les inventaires de tous les joueurs
#

# Incrémenter la vitesse (cycle 0-3)
scoreboard players add world fse_option_eating_time 1
execute if score world fse_option_eating_time matches 4.. run scoreboard players set world fse_option_eating_time 0

# Afficher la nouvelle vitesse au joueur qui a exécuté la commande
execute if score world fse_option_eating_time matches 0 run tellraw @s {"text":"Eating time: 1.6s (Default)","color":"red"}
execute if score world fse_option_eating_time matches 1 run tellraw @s {"text":"Eating time: 0.8s (Kelp)","color":"green"}
execute if score world fse_option_eating_time matches 2 run tellraw @s {"text":"Eating time: 0.4s","color":"green"}
execute if score world fse_option_eating_time matches 3 run tellraw @s {"text":"Eating time: 0.0s (Instant)","color":"green"}

# Forcer la réapplication sur tous les inventaires joueurs (sans vérifier le marqueur)
# car les items ont déjà le marqueur fse mais avec l'ancienne vitesse
execute as @a run function fse_data:apply/inventory_force

# Les items au sol seront ré-appliqués au prochain tick car on force aussi les ground items
execute as @a at @s run function fse_data:apply/ground_items_force