
scoreboard objectives remove bridge_eggs_installation_test

scoreboard objectives remove beg_motion_x1
scoreboard objectives remove beg_motion_y1
scoreboard objectives remove beg_motion_z1

tellraw @a {"text":"Uninstalled Bridge Eggs","color":"red"}
datapack disable "file/Bridge Eggs by Juix [1.3] 1.21.5-26.2"
datapack disable "file/Bridge Eggs by Juix [1.3] 1.21.5-26.2.zip"