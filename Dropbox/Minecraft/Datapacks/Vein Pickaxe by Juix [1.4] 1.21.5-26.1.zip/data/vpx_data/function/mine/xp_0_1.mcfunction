execute if predicate vpx_data:has_silk_touch run return run function vpx_data:mine/loot_block

execute store result score #xp vpx_temp_xp run random value 0..1
execute if score #xp vpx_temp_xp matches 1.. run summon experience_orb ~ ~ ~ {Tags:["vpx_xp"]}
execute if score #xp vpx_temp_xp matches 1.. store result entity @e[type=experience_orb,tag=vpx_xp,limit=1] Value short 1 run scoreboard players get #xp vpx_temp_xp
tag @e[type=experience_orb,tag=vpx_xp] remove vpx_xp
function vpx_data:mine/loot_block
