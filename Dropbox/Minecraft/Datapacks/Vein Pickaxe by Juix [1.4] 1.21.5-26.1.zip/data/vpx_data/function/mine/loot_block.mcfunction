execute as @p[tag=vpx_holding_vein_pickaxe,scores={vpx_mined_blocks=1..}] run loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
setblock ~ ~ ~ air

playsound minecraft:block.stone.break block @a ~ ~ ~ 1 1

function vpx_data:vein_pickaxe