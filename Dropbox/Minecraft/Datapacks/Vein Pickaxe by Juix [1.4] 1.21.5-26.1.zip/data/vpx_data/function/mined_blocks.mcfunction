execute as @s[scores={vpx_use_diamond_pickaxe=1..}] run scoreboard players add @s vpx_mined_blocks 1
execute as @s[scores={vpx_use_netherite_pickaxe=1..}] run scoreboard players add @s vpx_mined_blocks 1
