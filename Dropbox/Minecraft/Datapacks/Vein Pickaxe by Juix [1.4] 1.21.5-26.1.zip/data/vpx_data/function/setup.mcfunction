scoreboard objectives add show_recipes_in_chat trigger
scoreboard objectives add show_recipes_in_browser trigger

#
#	DEFAULT
#

scoreboard objectives add vein_pickaxes_mined_blocks dummy
scoreboard objectives add vpx_smithing_test dummy
scoreboard objectives add vpx_temp_xp dummy
scoreboard objectives add vpx_mined_blocks dummy

scoreboard objectives add vpx_use_diamond_pickaxe minecraft.used:minecraft.diamond_pickaxe
scoreboard objectives add vpx_use_netherite_pickaxe minecraft.used:minecraft.netherite_pickaxe

scoreboard objectives add juix_option_sneak_bypass dummy
execute unless score world juix_option_sneak_bypass matches 0.. run scoreboard players set world juix_option_sneak_bypass 0

scoreboard objectives add vpx_player_sneaking minecraft.custom:minecraft.sneak_time

scoreboard players set world vein_pickaxe_installation_test 2
tellraw @a {"text":"Vein Pickaxe Installed","color":"green"}