#By Juju

#
#	DEFAULT
#

scoreboard objectives add vein_pickaxe_installation_test dummy
execute if score world vein_pickaxe_installation_test matches 2.. run tellraw @a {"text":"Vein Pickaxe Reloaded","color":"green"}
execute unless score world vein_pickaxe_installation_test matches 2.. run function vpx_data:setup