# On vérifie que l'item miné fait partie des blocs compatibles avec le Vein mining
execute unless items entity @e[type=item,distance=..1,limit=1,sort=nearest] contents #vpx_data:valid_vein_drops run return 0

execute align xyz positioned ~0.5 ~0.5 ~0.5 run function vpx_data:vein_pickaxe