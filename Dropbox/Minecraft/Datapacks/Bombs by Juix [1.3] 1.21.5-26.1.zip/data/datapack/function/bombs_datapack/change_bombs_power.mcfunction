scoreboard players add world bbs_option_power 1
execute if score world bbs_option_power matches 4.. run scoreboard players set world bbs_option_power 1

execute if score world bbs_option_power matches 1 run tellraw @s {"text":"Bombs power : Normal","color":"green"}
execute if score world bbs_option_power matches 2 run tellraw @s {"text":"Bombs power : Boosted (x1.5)","color":"green"}
execute if score world bbs_option_power matches 3 run tellraw @s {"text":"Bombs power : Hyper boosted (x2)","color":"green"}
