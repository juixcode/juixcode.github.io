# 1️⃣ Stocker le nombre d’items tenus en main
execute store result score @s bbs_itemCount run data get entity @s SelectedItem.count

# 2️⃣ Soustraire 1
scoreboard players remove @s bbs_itemCount 1

# 3️⃣ Si le stack est encore ≥ 1, le placer dans un stockage temporaire (car on ne peut pas modifier le NBT d'un joueur) dans la bonne quantité, puis le remettre en main
execute if score @s bbs_itemCount matches 1.. run item replace block 0 -64 0 container.0 from entity @s weapon.mainhand
execute if score @s bbs_itemCount matches 1.. run execute store result block 0 -64 0 Items[0].count byte 1 run scoreboard players get @s bbs_itemCount
execute if score @s bbs_itemCount matches 1.. run item replace entity @s weapon.mainhand from block 0 -64 0 container.0

# 4️⃣ Sinon, si le stack tombe à 0, vider la main
execute unless score @s bbs_itemCount matches 1.. run item replace entity @s weapon.mainhand with air