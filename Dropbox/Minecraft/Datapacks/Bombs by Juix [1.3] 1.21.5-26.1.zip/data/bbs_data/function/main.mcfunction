#   /trigger show_recipes

scoreboard players enable @a show_recipes
execute as @a[scores={juix_recipes_tellraw_id=7}] run function bbs_data:recipes/stop
execute as @a[scores={show_recipes=1..}] run function bbs_data:recipes/show

scoreboard players enable @a show_recipes_weblinks
execute as @a[scores={show_recipes_weblinks=1..}] run function bbs_data:recipes/show_links

#   MAIN

execute as @a[scores={bbs_item_clicked=1..}] run function bbs_data:item_clicked

#   DYNAMITE
execute as @e[tag=bbs_dynamite] at @s if block ~ ~-0.1 ~ air run function bbs_data:items/dynamite_duration
execute as @e[tag=bbs_dynamite] at @s unless block ~ ~-0.1 ~ air run function bbs_data:items/dynamite_explosion

#   BOMBS
execute as @e[tag=bbs_lit_tnt] at @s run function bbs_data:items/lit_tnt

execute as @e[tag=bbs_bomb,tag=!bbs_update] at @s run function bbs_data:items/bomb_set_cooldown
execute as @e[tag=bbs_bomb] at @s run function bbs_data:items/bomb

#   BOMBS EFFECTS
scoreboard players add @e[tag=bbs_bomb_effects] bbs_effect_duration 1
execute as @e[tag=bbs_bomb_effects] at @s run function bbs_data:items/bomb_effects