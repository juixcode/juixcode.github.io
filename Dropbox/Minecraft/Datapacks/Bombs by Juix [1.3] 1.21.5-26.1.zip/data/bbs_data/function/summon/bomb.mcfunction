summon armor_stand ~ ~ ~ {Marker:1b,Invisible:1b,NoBasePlate:1b,Small:1b,CustomName:'[{"text":"00:00","color":"red"}]',CustomNameVisible:1b,Invulnerable:1b,NoGravity:1b,PersistenceRequired:1b,Tags:["bbs_bomb1","bbs_bomb"],DisabledSlots:4144959}

#   Centrage
execute as @e[tag=bbs_bomb1,sort=nearest,limit=1,distance=..2] at @s align xyz run tp @s ~0.5 ~ ~0.5