#
#	DEFAULT
#

scoreboard objectives add bombs_installation_test dummy
execute if score world bombs_installation_test matches 2.. run tellraw @a {"text":"Bombs Reloaded","color":"green"}
execute unless score world bombs_installation_test matches 2.. run function bbs_data:setup