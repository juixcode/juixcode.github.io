playsound minecraft:block.basalt.place neutral @a ~ ~ ~ 1 1
summon tnt ~ ~ ~ {fuse:80}
playsound minecraft:entity.tnt.primed neutral @a ~ ~ ~ 1 1
kill @s