execute as @s[tag=bbs_atomic_bomb_effects] run particle minecraft:trial_spawner_detection ~ ~ ~ 6 6 6 0.01 3 normal @a
execute as @s[tag=bbs_atomic_bomb_effects] unless score world bbs_option_power matches 3 run effect give @e[distance=..12,nbt=!{active_effects:[{id:"minecraft:wither"}]}] minecraft:wither 5 0 true
execute as @s[tag=bbs_atomic_bomb_effects] if score world bbs_option_power matches 3 run effect give @e[distance=..12,nbt=!{active_effects:[{id:"minecraft:wither"}]}] minecraft:wither 8 0 true

execute as @s[tag=bbs_toxic_bomb_effects] run particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 3 3 3 0.01 1 normal @a
execute as @s[tag=bbs_toxic_bomb_effects] run particle minecraft:trial_omen ~ ~ ~ 3 3 3 0.01 2 normal @a
execute as @s[tag=bbs_toxic_bomb_effects] unless score world bbs_option_power matches 3 run effect give @e[distance=..8,nbt=!{active_effects:[{id:"minecraft:poison"}]}] minecraft:poison 5 3 true
execute as @s[tag=bbs_toxic_bomb_effects] if score world bbs_option_power matches 3 run effect give @e[distance=..8,nbt=!{active_effects:[{id:"minecraft:poison"}]}] minecraft:poison 8 3 true
execute as @s[tag=bbs_toxic_bomb_effects] run effect give @e[distance=..10,nbt=!{active_effects:[{id:"minecraft:hunger"}]}] minecraft:hunger 5 2 true
execute as @s[tag=bbs_toxic_bomb_effects] run effect give @e[distance=..8,nbt=!{active_effects:[{id:"minecraft:slowness"}]}] minecraft:slowness 5 0 true

execute unless score world bbs_option_power matches 2.. run kill @s[scores={bbs_effect_duration=1200..}]
execute if score world bbs_option_power matches 2.. run kill @s[scores={bbs_effect_duration=1800..}]