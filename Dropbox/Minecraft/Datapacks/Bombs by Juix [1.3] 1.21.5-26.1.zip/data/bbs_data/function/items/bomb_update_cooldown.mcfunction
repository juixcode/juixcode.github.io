scoreboard players remove @s bbs_duration_cooldown 1
playsound minecraft:block.note_block.cow_bell neutral @a ~ ~ ~ 1 1

#   Display
execute store result storage bbs_data:data time int 1 run scoreboard players get @s bbs_duration_cooldown
function bbs_data:items/bomb_update_cooldown_display with storage bbs_data:data
data remove storage bbs_data:data time

#   Explosion
execute if entity @s[scores={bbs_duration_cooldown=4}] run playsound minecraft:entity.tnt.primed neutral @a ~ ~ ~ 1 1

execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb1] run function bbs_data:items/bomb_explosion
execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb2] run function bbs_data:items/dangerous_bomb_explosion
execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb3] run function bbs_data:items/atomic_bomb_explosion
execute if entity @s[scores={bbs_duration_cooldown=0},tag=bbs_bomb4] run function bbs_data:items/toxic_bomb_explosion

execute if entity @s[scores={bbs_duration_cooldown=0}] run setblock ~ ~ ~ glass replace
execute if entity @s[scores={bbs_duration_cooldown=0}] run kill @e[tag=bbs_bomb_texture,distance=..3,limit=1,sort=nearest]
execute if entity @s[scores={bbs_duration_cooldown=0}] run kill @s

scoreboard players reset @s bbs_duration_timer