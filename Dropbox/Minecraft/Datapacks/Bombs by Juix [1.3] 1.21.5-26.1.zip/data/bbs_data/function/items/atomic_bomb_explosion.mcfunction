execute if score world bbs_option_power matches 1 run summon fireball ~ ~1 ~ {ExplosionPower:20,Motion:[0.0,-1.0,0.0]}
execute if score world bbs_option_power matches 2 run summon fireball ~ ~1 ~ {ExplosionPower:30,Motion:[0.0,-1.0,0.0]}
execute if score world bbs_option_power matches 3 run summon fireball ~ ~1 ~ {ExplosionPower:40,Motion:[0.0,-1.0,0.0]}

summon armor_stand ~ ~ ~ {Tags:[bbs_bomb_effects,bbs_atomic_bomb_effects],Marker:1b,Invisible:1b,NoBasePlate:1b,Invulnerable:1b,NoGravity:1b,PersistenceRequired:1b,DisabledSlots:4144959}

summon tnt ~-1 ~ ~ {fuse:3}
summon tnt ~ ~ ~-1 {fuse:3}
summon tnt ~1 ~ ~ {fuse:3}
summon tnt ~ ~ ~1 {fuse:3}
summon tnt ~ ~-1 ~ {fuse:3}

summon tnt ~ ~ ~ {fuse:0}
summon tnt ~ ~ ~ {fuse:0}
summon tnt ~ ~ ~ {fuse:0}
summon tnt ~ ~ ~ {fuse:0}
summon tnt ~ ~ ~ {fuse:0}

particle minecraft:gust_emitter_large ~ ~ ~ 6 6 6 0.1 20 normal @a
particle minecraft:gust_emitter_large ~ ~ ~ 3 3 3 0.1 5 force @a