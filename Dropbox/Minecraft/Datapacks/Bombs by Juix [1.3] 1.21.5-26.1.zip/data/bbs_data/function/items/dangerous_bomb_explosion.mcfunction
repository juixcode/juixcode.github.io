execute if score world bbs_option_power matches 1 run summon fireball ~ ~1 ~ {ExplosionPower:7,Motion:[0.0,-1.0,0.0]}
execute if score world bbs_option_power matches 2 run summon fireball ~ ~1 ~ {ExplosionPower:10,Motion:[0.0,-1.0,0.0]}
execute if score world bbs_option_power matches 3 run summon fireball ~ ~1 ~ {ExplosionPower:12,Motion:[0.0,-1.0,0.0]}
summon tnt ~ ~ ~ {fuse:0}
execute if score world bbs_option_power matches 3 run summon tnt ~ ~ ~ {fuse:0}