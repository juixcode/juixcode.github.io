scoreboard players add @s bbs_bomb_timer 1
execute at @s run playsound minecraft:block.note_block.bell neutral @a ~ ~ ~ 0.8 1.5

execute if entity @s[scores={bbs_bomb_timer=20..}] at @s run summon tnt ~ ~ ~ {fuse:0}
execute if score world bbs_option_power matches 3 if entity @s[scores={bbs_bomb_timer=20..}] at @s run summon tnt ~ ~ ~ {fuse:0}

execute if entity @s[scores={bbs_bomb_timer=20..}] run kill @s