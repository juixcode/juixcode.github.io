execute store result score @s bbs_motion_x1 run data get entity @s Pos[0] 1000
execute store result score @s bbs_motion_y1 run data get entity @s Pos[1] 1000
execute store result score @s bbs_motion_z1 run data get entity @s Pos[2] 1000

tp @s ^ ^ ^0.1

execute store result score @s bbs_motion_x2 run data get entity @s Pos[0] 1000
execute store result score @s bbs_motion_y2 run data get entity @s Pos[1] 1000
execute store result score @s bbs_motion_z2 run data get entity @s Pos[2] 1000

execute store result entity @s Motion[0] double 0.018 run scoreboard players operation @s bbs_motion_x2 -= @s bbs_motion_x1
execute store result entity @s Motion[1] double 0.007 run scoreboard players operation @s bbs_motion_y2 -= @s bbs_motion_y1
execute store result entity @s Motion[2] double 0.018 run scoreboard players operation @s bbs_motion_z2 -= @s bbs_motion_z1

# Ajout d'une constante de lancer
execute store result score @s bbs_motion_y1 run data get entity @s Motion[1] 100
scoreboard players add @s bbs_motion_y1 40
execute store result entity @s Motion[1] double 0.01 run scoreboard players get @s bbs_motion_y1