execute if score world bbs_option_power matches 1 run summon fireball ~ ~1 ~ {ExplosionPower:3,Motion:[0.0,-1.0,0.0]}
execute if score world bbs_option_power matches 2 run summon fireball ~ ~1 ~ {ExplosionPower:4,Motion:[0.0,-1.0,0.0]}
execute if score world bbs_option_power matches 3 run summon fireball ~ ~1 ~ {ExplosionPower:6,Motion:[0.0,-1.0,0.0]}